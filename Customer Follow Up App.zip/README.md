
  # Customer Follow Up App

  This is a code bundle for Customer Follow Up App. The original project is available at https://www.figma.com/design/ZqHJgo1CYoKVAXqptkZPiC/Customer-Follow-Up-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  