# BizFollow Backend Data Flow Documentation

## ✅ All Data is Stored in Supabase Backend

This document confirms that **ALL** customer and follow-up data in BizFollow is stored in the Supabase backend (KV Store) and **NO** data is stored locally in the browser.

---

## 🔐 Authentication Flow

### 1. User Signup
```
User Input → LoginForm.tsx → apiClient.signup() 
  → Backend API (/signup) → Supabase Auth (creates user) 
  → User stored in Supabase Auth database
```

**Backend File:** `/supabase/functions/server/index.tsx` (lines 76-103)
- Creates user via `supabase.auth.admin.createUser()`
- Stores user metadata (name, email) in Supabase Auth
- Auto-confirms email

### 2. User Login
```
User Input → LoginForm.tsx → supabase.auth.signInWithPassword() 
  → Supabase Auth → Returns access_token
  → Token stored in App state and apiClient
```

**Files Involved:**
- `/components/LoginForm.tsx` (login handler)
- `/utils/supabase.ts` (Supabase client)
- Access token is used for ALL subsequent API calls

---

## 📊 Customer Data Flow

### Create Customer (Add Lead)
```
AddCustomer Form → handleAddCustomer() → apiClient.addCustomer()
  → Backend API POST /customers → KV Store
  → Data saved with key: customers:{userId}:{customerId}
```

**Backend Storage Location:**
- Supabase KV Store
- Key format: `customers:{userId}:{customerId}`
- Example: `customers:abc123:1730000000-xyz456`

**Backend Code:** `/supabase/functions/server/index.tsx` (lines 140-179)

**What's Stored:**
- All customer/lead fields (name, email, phone, company, etc.)
- Lead-specific fields (leadSource, interestArea, followUpStatus)
- Wellness fields (if applicable)
- User ID (for data isolation)
- Timestamps (createdAt, updatedAt)

### Read Customers (Load Dashboard)
```
Dashboard.useEffect() → apiClient.getCustomers()
  → Backend API GET /customers → KV Store
  → Returns all customers for authenticated user
```

**Backend Code:** `/supabase/functions/server/index.tsx` (lines 106-137)

**Data Flow:**
1. Frontend sends access token in Authorization header
2. Backend validates token with Supabase Auth
3. Backend queries KV store with prefix: `customers:{userId}:`
4. Returns ONLY customers belonging to authenticated user

### Update Customer
```
CustomerDetail → handleUpdateCustomer() → apiClient.updateCustomer()
  → Backend API PUT /customers/:id → KV Store
  → Updates existing customer record
```

**Backend Code:** `/supabase/functions/server/index.tsx` (lines 182-227)

### Delete Customer
```
CustomerDetail → handleDeleteCustomer() → apiClient.deleteCustomer()
  → Backend API DELETE /customers/:id → KV Store
  → Deletes customer AND all associated follow-ups
```

**Backend Code:** `/supabase/functions/server/index.tsx` (lines 230-272)

**Important:** Delete is cascading - removes:
1. All follow-ups for the customer
2. The customer record itself

---

## 📅 Follow-Up Data Flow

### Create Follow-Up
```
AddFollowUp Form → handleAddFollowUp() → apiClient.addFollowUp()
  → Backend API POST /followups → KV Store
  → Data saved with key: followups:{userId}:{customerId}:{followUpId}
```

**Backend Storage Location:**
- Supabase KV Store
- Key format: `followups:{userId}:{customerId}:{followUpId}`
- Example: `followups:abc123:1730000000-xyz456:1730000100-abc789`

**Backend Code:** `/supabase/functions/server/index.tsx` (lines 307-374)

**What's Stored:**
- Follow-up details (type, subject, description)
- Date and status (pending/completed/overdue)
- Priority level
- Outcomes data
- Linked customer ID
- User ID (for data isolation)
- Timestamps

**Side Effect:** Also updates customer's `lastContact` date

### Read Follow-Ups
```
Dashboard.useEffect() → apiClient.getAllFollowUps()
  → Backend API GET /followups → KV Store
  → Returns all follow-ups for authenticated user
```

**Backend Code:** `/supabase/functions/server/index.tsx` (lines 410-441)

### Update Follow-Up
```
FollowUpManager → handleUpdateFollowUp() → apiClient.updateFollowUp()
  → Backend API PUT /followups/:customerId/:id → KV Store
  → Updates existing follow-up record
```

**Backend Code:** `/supabase/functions/server/index.tsx` (lines 377-407)

---

## 🔒 Data Security & Isolation

### User Data Isolation
Every data operation includes the user ID in the storage key:
- `customers:{userId}:*` - Only user's customers
- `followups:{userId}:*` - Only user's follow-ups

This ensures:
✅ Users can ONLY access their own data
✅ No data leakage between users
✅ Multi-tenant architecture

### Authentication Required
ALL API endpoints (except `/health` and `/signup`) require:
1. Valid access token in Authorization header
2. Token verification via Supabase Auth
3. User ID extraction from verified token

**See:** `/utils/api.ts` (lines 12-19)

---

## 📡 API Client Architecture

### Access Token Management
```typescript
// File: /utils/api.ts
class ApiClient {
  private accessToken: string | null = null;
  
  setAccessToken(token: string | null) {
    this.accessToken = token;
  }
  
  private async request(endpoint: string) {
    // Requires access token for authenticated endpoints
    if (isAuthRequired && !this.accessToken) {
      throw new Error('Authentication required');
    }
    
    // Sends token in Authorization header
    headers: {
      'Authorization': `Bearer ${this.accessToken}`
    }
  }
}
```

### All API Methods
- ✅ `getCustomers()` - Fetches from backend
- ✅ `addCustomer()` - Saves to backend
- ✅ `updateCustomer()` - Updates in backend
- ✅ `deleteCustomer()` - Deletes from backend
- ✅ `getAllFollowUps()` - Fetches from backend
- ✅ `addFollowUp()` - Saves to backend
- ✅ `updateFollowUp()` - Updates in backend

**NO local storage operations** - everything goes through the backend API.

---

## 🚀 Backend API Endpoints

| Endpoint | Method | Purpose | Data Location |
|----------|--------|---------|---------------|
| `/health` | GET | Health check | N/A |
| `/signup` | POST | Create user account | Supabase Auth |
| `/customers` | GET | Get all customers | KV Store |
| `/customers` | POST | Create customer | KV Store |
| `/customers/:id` | PUT | Update customer | KV Store |
| `/customers/:id` | DELETE | Delete customer | KV Store |
| `/followups` | GET | Get all follow-ups | KV Store |
| `/followups` | POST | Create follow-up | KV Store |
| `/followups/:customerId/:id` | PUT | Update follow-up | KV Store |

**Base URL:** `https://tfrtakkvnkwxmervjozd.supabase.co/functions/v1/make-server-b8fc68da`

---

## 💾 Storage Technology

### Supabase KV Store
The backend uses Supabase's Key-Value store (Deno KV) for data persistence:

**File:** `/supabase/functions/server/kv_store.tsx`

**Operations:**
- `set(key, value)` - Store data
- `get(key)` - Retrieve data
- `del(key)` - Delete data
- `getByPrefix(prefix)` - Query by prefix (for user data)

**Benefits:**
- ✅ Serverless (no database management)
- ✅ Automatic scaling
- ✅ Low latency
- ✅ Persistent storage
- ✅ Built into Supabase

---

## 🎯 Data Persistence Verification

### When You Add a Customer:
1. ✅ Data sent to backend API
2. ✅ Stored in Supabase KV Store with user-specific key
3. ✅ Dashboard refreshes and loads data from backend
4. ✅ **Close browser, reopen → Data still there (loaded from backend)**

### When You Add a Follow-Up:
1. ✅ Data sent to backend API
2. ✅ Stored in Supabase KV Store
3. ✅ Customer's lastContact updated in backend
4. ✅ Dashboard refreshes and loads data from backend

### When You Update/Delete:
1. ✅ Changes sent to backend API
2. ✅ Backend updates/deletes in KV Store
3. ✅ Frontend reloads fresh data from backend
4. ✅ **Changes persist across sessions**

---

## 🔍 How to Verify Backend Storage

### Method 1: Check Browser Console
1. Open DevTools (F12)
2. Go to Network tab
3. Perform any action (add/edit/delete customer)
4. See API calls to Supabase backend
5. Check request/response payloads

### Method 2: Check Application Logs
Every operation logs to console:
```
📡 Making API request to: https://tfrtakkvnkwxmervjozd.supabase.co/...
Using authorization: User token
API Response status: 200
API Response data: {...}
```

### Method 3: Test Persistence
1. Add a customer
2. Close browser completely
3. Reopen and login
4. Customer is still there ✅ (because it's in backend)

### Method 4: Backend Status Indicator
- Look at the Dashboard header
- Green badge = "Backend Connected" ✅
- All data operations go through connected backend

---

## 📝 Summary

### ✅ What's Stored in Backend:
- User accounts (Supabase Auth)
- All customers/leads (KV Store)
- All follow-ups (KV Store)
- User metadata
- Timestamps
- Everything!

### ❌ What's NOT Stored Locally:
- No localStorage
- No sessionStorage
- No IndexedDB
- No cookies (except session)
- No local state persistence

### 🎯 Conclusion:
**100% of user data is stored in the Supabase backend.** The frontend is purely a view layer that:
1. Authenticates users
2. Sends/receives data via API
3. Displays data
4. Does NOT persist any business data locally

All data operations require authentication and go through the secure backend API.

---

## 🆘 Troubleshooting

If data seems to disappear:
1. Check if you're logged in with the same account
2. Check backend status indicator (should be green)
3. Check browser console for API errors
4. Verify internet connection
5. Check Supabase Edge Function deployment status

**Note:** Demo Mode uses temporary in-memory data (not backend). Always use real login for persistent data.
