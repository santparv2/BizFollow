import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { 
  CheckCircle, 
  TrendingUp, 
  TrendingDown, 
  Minus,
  Heart,
  Brain,
  Activity,
  Moon,
  Apple,
  Target,
  MessageCircle
} from 'lucide-react';

interface Customer {
  id: string;
  name: string;
  email: string;
  goals?: string;
  challenges?: string;
  stressLevel?: string;
  commitmentLevel?: string;
}

interface FollowUp {
  id: string;
  customerId: string;
  type: 'call' | 'email' | 'meeting' | 'task';
  subject: string;
  description: string;
  date: string;
  status: 'pending' | 'completed' | 'overdue';
  priority: 'low' | 'medium' | 'high';
  outcomes?: {
    goalProgress?: string;
    stressChange?: string;
    energyLevel?: string;
    sleepQuality?: string;
    nutritionCompliance?: string;
    nextSteps?: string;
    clientMood?: string;
    challenges?: string;
    wins?: string;
    actionItems?: string;
  };
}

interface FollowUpOutcomesProps {
  followUp: FollowUp;
  customer: Customer;
  onUpdateOutcomes: (followUpId: string, outcomes: any) => void;
  onClose: () => void;
}

export function FollowUpOutcomes({ followUp, customer, onUpdateOutcomes, onClose }: FollowUpOutcomesProps) {
  const [outcomes, setOutcomes] = useState({
    goalProgress: followUp.outcomes?.goalProgress || '',
    stressChange: followUp.outcomes?.stressChange || '',
    energyLevel: followUp.outcomes?.energyLevel || '',
    sleepQuality: followUp.outcomes?.sleepQuality || '',
    nutritionCompliance: followUp.outcomes?.nutritionCompliance || '',
    clientMood: followUp.outcomes?.clientMood || '',
    challenges: followUp.outcomes?.challenges || '',
    wins: followUp.outcomes?.wins || '',
    actionItems: followUp.outcomes?.actionItems || '',
    nextSteps: followUp.outcomes?.nextSteps || ''
  });

  const handleChange = (field: string, value: string) => {
    setOutcomes(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    onUpdateOutcomes(followUp.id, { 
      status: 'completed',
      outcomes 
    });
    onClose();
  };

  const getChangeIcon = (change: string) => {
    switch (change) {
      case 'improved': return <TrendingUp className="w-4 h-4 text-green-500" />;
      case 'declined': return <TrendingDown className="w-4 h-4 text-red-500" />;
      case 'same': return <Minus className="w-4 h-4 text-gray-500" />;
      default: return null;
    }
  };

  const getChangeColor = (change: string) => {
    switch (change) {
      case 'improved': return 'text-green-600 bg-green-50';
      case 'declined': return 'text-red-600 bg-red-50';
      case 'same': return 'text-gray-600 bg-gray-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <CheckCircle className="w-6 h-6 text-green-500" />
          <h1>🌿 Complete Follow-up Session</h1>
        </div>
        <p className="text-gray-600">
          Record outcomes and insights from your wellness coaching session with {customer.name}
        </p>
      </div>

      <div className="max-w-4xl mx-auto space-y-6">
        {/* Session Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              Session Summary
            </CardTitle>
            <CardDescription>
              {followUp.type} • {followUp.date} • {followUp.subject}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-blue-50 rounded-lg p-4 mb-4">
              <p><strong>Session Focus:</strong> {followUp.description}</p>
              {customer.goals && (
                <p className="mt-2"><strong>Client's Goals:</strong> {customer.goals.substring(0, 200)}...</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Wellness Metrics */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5" />
              🌿 Wellness Metrics & Progress
            </CardTitle>
            <CardDescription>
              Track changes in key wellness areas since the last session
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Goal Progress */}
              <div className="space-y-3">
                <Label className="flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Goal Progress
                </Label>
                <Select value={outcomes.goalProgress} onValueChange={(value) => handleChange('goalProgress', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="How did they progress toward their goals?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="excellent">🎯 Excellent - Exceeded expectations</SelectItem>
                    <SelectItem value="good">✅ Good - On track with goals</SelectItem>
                    <SelectItem value="fair">⚠️ Fair - Some progress made</SelectItem>
                    <SelectItem value="poor">❌ Poor - Little to no progress</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Stress Level Change */}
              <div className="space-y-3">
                <Label className="flex items-center gap-2">
                  <Brain className="w-4 h-4" />
                  Stress Level Change
                </Label>
                <Select value={outcomes.stressChange} onValueChange={(value) => handleChange('stressChange', value)}>
                  <SelectTrigger>
                    <div className="flex items-center gap-2">
                      {getChangeIcon(outcomes.stressChange)}
                      <SelectValue placeholder="How did stress levels change?" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="improved">📉 Improved - Lower stress</SelectItem>
                    <SelectItem value="same">➡️ Same - No change</SelectItem>
                    <SelectItem value="declined">📈 Declined - Higher stress</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Energy Level */}
              <div className="space-y-3">
                <Label className="flex items-center gap-2">
                  <Heart className="w-4 h-4" />
                  Energy Level
                </Label>
                <Select value={outcomes.energyLevel} onValueChange={(value) => handleChange('energyLevel', value)}>
                  <SelectTrigger>
                    <div className="flex items-center gap-2">
                      {getChangeIcon(outcomes.energyLevel)}
                      <SelectValue placeholder="How are their energy levels?" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="improved">⚡ Improved - More energetic</SelectItem>
                    <SelectItem value="same">🔋 Same - Consistent energy</SelectItem>
                    <SelectItem value="declined">🪫 Declined - Lower energy</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Sleep Quality */}
              <div className="space-y-3">
                <Label className="flex items-center gap-2">
                  <Moon className="w-4 h-4" />
                  Sleep Quality
                </Label>
                <Select value={outcomes.sleepQuality} onValueChange={(value) => handleChange('sleepQuality', value)}>
                  <SelectTrigger>
                    <div className="flex items-center gap-2">
                      {getChangeIcon(outcomes.sleepQuality)}
                      <SelectValue placeholder="How is their sleep quality?" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="improved">😴 Improved - Better sleep</SelectItem>
                    <SelectItem value="same">🌙 Same - Consistent sleep</SelectItem>
                    <SelectItem value="declined">😵 Declined - Worse sleep</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Nutrition Compliance */}
              <div className="space-y-3">
                <Label className="flex items-center gap-2">
                  <Apple className="w-4 h-4" />
                  Nutrition Compliance
                </Label>
                <Select value={outcomes.nutritionCompliance} onValueChange={(value) => handleChange('nutritionCompliance', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="How well are they following nutrition plan?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="excellent">🥗 Excellent - 90%+ compliance</SelectItem>
                    <SelectItem value="good">🍎 Good - 70-89% compliance</SelectItem>
                    <SelectItem value="fair">🥪 Fair - 50-69% compliance</SelectItem>
                    <SelectItem value="poor">🍕 Poor - Below 50% compliance</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Client Mood */}
              <div className="space-y-3">
                <Label className="flex items-center gap-2">
                  <Heart className="w-4 h-4" />
                  Client Mood & Motivation
                </Label>
                <Select value={outcomes.clientMood} onValueChange={(value) => handleChange('clientMood', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="What was their overall mood?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="very-positive">😊 Very Positive - Highly motivated</SelectItem>
                    <SelectItem value="positive">🙂 Positive - Good attitude</SelectItem>
                    <SelectItem value="neutral">😐 Neutral - Neither positive nor negative</SelectItem>
                    <SelectItem value="concerned">😟 Concerned - Some worries</SelectItem>
                    <SelectItem value="frustrated">😤 Frustrated - Facing challenges</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Session Notes */}
        <Card>
          <CardHeader>
            <CardTitle>📝 Session Notes & Insights</CardTitle>
            <CardDescription>
              Capture detailed observations and plan next steps
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="wins">🏆 Wins & Achievements</Label>
                <Textarea
                  id="wins"
                  placeholder="What went well? What victories should we celebrate?"
                  value={outcomes.wins}
                  onChange={(e) => handleChange('wins', e.target.value)}
                  rows={4}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="challenges">⚠️ Challenges & Obstacles</Label>
                <Textarea
                  id="challenges"
                  placeholder="What challenges did they face? What barriers need addressing?"
                  value={outcomes.challenges}
                  onChange={(e) => handleChange('challenges', e.target.value)}
                  rows={4}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="actionItems">✅ Action Items & Homework</Label>
                <Textarea
                  id="actionItems"
                  placeholder="What specific actions should they take before the next session?"
                  value={outcomes.actionItems}
                  onChange={(e) => handleChange('actionItems', e.target.value)}
                  rows={4}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="nextSteps">🎯 Next Session Focus</Label>
                <Textarea
                  id="nextSteps"
                  placeholder="What should be the focus of the next coaching session?"
                  value={outcomes.nextSteps}
                  onChange={(e) => handleChange('nextSteps', e.target.value)}
                  rows={4}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex gap-3 pb-8">
          <Button onClick={handleSave} className="flex-1">
            <CheckCircle className="w-4 h-4 mr-2" />
            🌿 Complete Session & Save Outcomes
          </Button>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
        </div>
      </div>
    </div>
  );
}

// Component for displaying completed outcomes
export function FollowUpOutcomesSummary({ followUp }: { followUp: FollowUp }) {
  if (!followUp.outcomes) return null;

  const getProgressColor = (progress: string) => {
    switch (progress) {
      case 'excellent': return 'bg-green-100 text-green-800';
      case 'good': return 'bg-blue-100 text-blue-800';
      case 'fair': return 'bg-yellow-100 text-yellow-800';
      case 'poor': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getChangeColor = (change: string) => {
    switch (change) {
      case 'improved': return 'bg-green-100 text-green-800';
      case 'same': return 'bg-gray-100 text-gray-800';
      case 'declined': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
      <h5 className="flex items-center gap-2 text-green-800 mb-3">
        <CheckCircle className="w-4 h-4" />
        <strong>Session Outcomes Recorded</strong>
      </h5>
      
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
        {followUp.outcomes.goalProgress && (
          <Badge className={getProgressColor(followUp.outcomes.goalProgress)}>
            Goal: {followUp.outcomes.goalProgress}
          </Badge>
        )}
        {followUp.outcomes.stressChange && (
          <Badge className={getChangeColor(followUp.outcomes.stressChange)}>
            Stress: {followUp.outcomes.stressChange}
          </Badge>
        )}
        {followUp.outcomes.energyLevel && (
          <Badge className={getChangeColor(followUp.outcomes.energyLevel)}>
            Energy: {followUp.outcomes.energyLevel}
          </Badge>
        )}
        {followUp.outcomes.sleepQuality && (
          <Badge className={getChangeColor(followUp.outcomes.sleepQuality)}>
            Sleep: {followUp.outcomes.sleepQuality}
          </Badge>
        )}
        {followUp.outcomes.nutritionCompliance && (
          <Badge className={getProgressColor(followUp.outcomes.nutritionCompliance)}>
            Nutrition: {followUp.outcomes.nutritionCompliance}
          </Badge>
        )}
        {followUp.outcomes.clientMood && (
          <Badge variant="outline">
            Mood: {followUp.outcomes.clientMood.replace('-', ' ')}
          </Badge>
        )}
      </div>

      {(followUp.outcomes.wins || followUp.outcomes.nextSteps) && (
        <div className="text-sm text-green-700 space-y-1">
          {followUp.outcomes.wins && (
            <p><strong>Wins:</strong> {followUp.outcomes.wins.substring(0, 100)}...</p>
          )}
          {followUp.outcomes.nextSteps && (
            <p><strong>Next Focus:</strong> {followUp.outcomes.nextSteps.substring(0, 100)}...</p>
          )}
        </div>
      )}
    </div>
  );
}