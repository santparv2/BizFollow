import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { User, Lock, UserPlus } from 'lucide-react';
import { supabase } from '../utils/supabase';
import { apiClient } from '../utils/api';
import { LoginDiagnostics } from './LoginDiagnostics';

interface LoginFormProps {
  onLogin: (userId: string, accessToken: string) => void;
}

// Helper to check if error is network-related
const isNetworkError = (error: any): boolean => {
  return error?.name === 'OfflineError' ||
         error?.name === 'NetworkError' ||
         error?.name === 'TypeError' ||
         error?.message === 'OFFLINE' ||
         error?.message?.includes('timeout') ||
         error?.message?.includes('Failed to fetch') ||
         error?.message?.includes('fetch') ||
         error?.message?.includes('Network unavailable');
};

// Default test account credentials
const DEFAULT_EMAIL = 'test@bizfollow.com';
const DEFAULT_PASSWORD = 'test123456';
const DEFAULT_NAME = 'Test User';

export function LoginForm({ onLogin }: LoginFormProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('login');
  const [demoMode, setDemoMode] = useState(false);

  const handleDemoMode = () => {
    console.log('✅ Entering Demo Mode - No authentication required');
    // Create a demo session without any network calls
    const demoToken = 'demo-token-' + Date.now();
    const userName = name || (email ? email.split('@')[0] : 'Demo User');
    apiClient.setAccessToken(demoToken);
    onLogin(userName, demoToken);
  };

  const handleQuickLogin = async () => {
    console.log('🚀 Quick Login with default test account');
    setEmail(DEFAULT_EMAIL);
    setPassword(DEFAULT_PASSWORD);
    setError('');
    setLoading(true);

    try {
      console.log('═══════════════════════════════════════════════════');
      console.log('🚀 QUICK LOGIN ATTEMPT');
      console.log('Using default test account:', DEFAULT_EMAIL);
      console.log('═══════════════════════════════════════════════════');

      const { data, error } = await supabase.auth.signInWithPassword({
        email: DEFAULT_EMAIL,
        password: DEFAULT_PASSWORD,
      });

      if (error) {
        // If account doesn't exist, create it
        if (error.message?.includes('Invalid login credentials')) {
          console.log('📝 Test account not found, creating it...');
          
          try {
            await apiClient.signup(DEFAULT_EMAIL, DEFAULT_PASSWORD, DEFAULT_NAME);
            console.log('✅ Test account created, signing in...');
            
            const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({
              email: DEFAULT_EMAIL,
              password: DEFAULT_PASSWORD,
            });

            if (loginError || !loginData.session) {
              throw new Error('Failed to sign in after creating test account');
            }

            apiClient.setAccessToken(loginData.session.access_token);
            onLogin(DEFAULT_NAME, loginData.session.access_token);
            
            console.log('✅ QUICK LOGIN SUCCESSFUL (new account)');
            return;
          } catch (signupError: any) {
            console.error('❌ Failed to create test account:', signupError);
            throw signupError;
          }
        }
        
        throw error;
      }

      if (!data.session || !data.session.access_token) {
        throw new Error('No session received');
      }

      apiClient.setAccessToken(data.session.access_token);
      onLogin(data.user.user_metadata?.name || DEFAULT_NAME, data.session.access_token);
      
      console.log('✅ QUICK LOGIN SUCCESSFUL');
      
    } catch (error: any) {
      console.error('❌ Quick login failed:', error);
      setError('Quick login failed. Please try manual login or demo mode.');
    }

    setLoading(false);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    setDemoMode(false);

    console.log('═══════════════════════════════════════════════════');
    console.log('🔐 LOGIN ATTEMPT STARTED');
    console.log('Email:', email);
    console.log('Timestamp:', new Date().toISOString());
    console.log('═══════════════════════════════════════════════════');

    try {
      // Step 1: Check internet connectivity
      if (typeof navigator !== 'undefined' && !navigator.onLine) {
        console.log('❌ STEP 1 FAILED: Browser is offline');
        setDemoMode(true);
        setError('⚠️ No internet connection. You can continue in Demo Mode to explore the app.');
        setLoading(false);
        return;
      }
      console.log('✅ STEP 1 PASSED: Browser is online');

      // Step 2: Attempt Supabase authentication
      console.log('📡 STEP 2: Calling Supabase signInWithPassword...');
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password: password,
      });

      console.log('📊 STEP 2 RESPONSE:');
      console.log('  - Error:', error ? error.message : 'None');
      console.log('  - Has User:', !!data?.user);
      console.log('  - Has Session:', !!data?.session);
      console.log('  - Has Access Token:', !!data?.session?.access_token);

      // Step 3: Handle authentication errors
      if (error) {
        console.log('❌ STEP 3: Authentication error detected');
        console.log('Error details:', {
          message: error.message,
          name: error.name,
          status: error.status
        });

        if (error.message?.includes('Invalid login credentials')) {
          throw new Error('❌ Invalid email or password. Please check your credentials.');
        }
        
        if (error.message?.includes('Email not confirmed')) {
          throw new Error('❌ Please confirm your email address before logging in.');
        }
        
        throw new Error(error.message || 'Authentication failed');
      }

      // Step 4: Validate session data
      if (!data.session || !data.session.access_token) {
        console.log('❌ STEP 4 FAILED: No session or access token received');
        throw new Error('❌ Authentication failed - no session created');
      }
      console.log('✅ STEP 4 PASSED: Valid session and access token received');

      // Step 5: Set access token and complete login
      console.log('✅ STEP 5: Setting access token and calling onLogin...');
      apiClient.setAccessToken(data.session.access_token);
      
      const userName = data.user.user_metadata?.name || data.user.email || 'User';
      console.log('User Name:', userName);
      console.log('User ID:', data.user.id);
      
      onLogin(userName, data.session.access_token);
      
      console.log('═══════════════════════════════════════════════════');
      console.log('✅ LOGIN SUCCESSFUL');
      console.log('═══════════════════════════════════════════════════');
      
    } catch (error: any) {
      console.log('═══════════════════════════════════════════════════');
      console.log('❌ LOGIN FAILED');
      console.log('Error:', error.message || error);
      console.log('Error Type:', error.name);
      console.log('═══════════════════════════════════════════════════');
      
      const errorMsg = error.message || 'Login failed. Please try again.';
      setError(errorMsg);
    }

    setLoading(false);
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    setDemoMode(false);

    console.log('═══════════════════════════════════════════════════');
    console.log('📝 SIGNUP ATTEMPT STARTED');
    console.log('Name:', name);
    console.log('Email:', email);
    console.log('Timestamp:', new Date().toISOString());
    console.log('═══════════════════════════════════════════════════');

    try {
      // Step 1: Validate inputs
      if (password.length < 6) {
        throw new Error('❌ Password must be at least 6 characters long');
      }
      console.log('✅ STEP 1 PASSED: Password validation');

      // Step 2: Create user account via backend
      console.log('📡 STEP 2: Creating user account via backend API...');
      const signupResponse = await apiClient.signup(email.trim(), password, name.trim());
      console.log('✅ STEP 2 PASSED: User account created:', signupResponse);
      
      // Step 3: Sign in with the new account
      console.log('📡 STEP 3: Signing in with new account...');
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password: password,
      });

      console.log('📊 STEP 3 RESPONSE:');
      console.log('  - Error:', error ? error.message : 'None');
      console.log('  - Has User:', !!data?.user);
      console.log('  - Has Session:', !!data?.session);
      console.log('  - Has Access Token:', !!data?.session?.access_token);

      // Step 4: Handle authentication errors
      if (error) {
        console.log('❌ STEP 4: Sign-in error after signup');
        throw new Error(error.message || 'Failed to sign in after creating account');
      }

      // Step 5: Validate session
      if (!data.session || !data.session.access_token) {
        console.log('❌ STEP 5 FAILED: No session received after signup');
        throw new Error('❌ Account created but failed to sign in. Please try logging in.');
      }
      console.log('✅ STEP 5 PASSED: Valid session received');

      // Step 6: Complete signup
      console.log('✅ STEP 6: Setting access token and calling onLogin...');
      apiClient.setAccessToken(data.session.access_token);
      onLogin(name || data.user.email || 'User', data.session.access_token);
      
      console.log('═══════════════════════════════════════════════════');
      console.log('✅ SIGNUP SUCCESSFUL');
      console.log('═══════════════════════════════════════════════════');
      
    } catch (error: any) {
      console.log('═══════════════════════════════════════════════════');
      console.log('❌ SIGNUP FAILED');
      console.log('Error:', error.message || error);
      console.log('Error Type:', error.name);
      console.log('═══════════════════════════════════════════════════');
      
      let errorMsg = error.message || 'Signup failed. Please try again.';
      
      // Provide helpful error messages
      if (errorMsg.includes('already registered') || errorMsg.includes('already exists') || errorMsg.includes('User already registered')) {
        errorMsg = '❌ This email is already registered. Please try logging in instead.';
      } else if (errorMsg.includes('invalid email')) {
        errorMsg = '❌ Please enter a valid email address.';
      }
      
      setError(errorMsg);
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center wellness-gradient py-12 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md space-y-6">
        {/* Welcome Header */}
        <div className="text-center space-y-2">
          <div className="mx-auto w-20 h-20 bg-white rounded-full flex items-center justify-center wellness-shadow-lg">
            <span className="text-3xl">📋</span>
          </div>
          <h1 className="text-3xl wellness-text-primary">BizFollow</h1>
          <p className="text-[var(--wellness-text-muted)]">
            Your comprehensive business follow-up platform
          </p>
          <div className="flex items-center justify-center gap-2 text-xs text-green-700 bg-green-50 border border-green-200 rounded-lg px-3 py-2 mx-auto max-w-fit">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
            <span>All data securely stored in Supabase Backend</span>
          </div>
        </div>

        <Card className="wellness-card">
          <CardHeader className="space-y-1 text-center">
            <CardTitle className="wellness-text-primary">Welcome Back</CardTitle>
            <CardDescription>
              Sign in to manage your business clients and follow-up activities
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 wellness-bg-light">
                <TabsTrigger value="login" className="wellness-focus">🔑 Login</TabsTrigger>
                <TabsTrigger value="signup" className="wellness-focus">📊 Sign Up</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login" className="space-y-4">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 wellness-text-primary" />
                      <Input
                        id="email"
                        type="email"
                        placeholder="Enter your email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="pl-10 wellness-focus"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 wellness-text-primary" />
                      <Input
                        id="password"
                        type="password"
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="pl-10 wellness-focus"
                        required
                      />
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full wellness-button" 
                    disabled={loading}
                  >
                    {loading ? '🔄 Signing in...' : '🔑 Sign In'}
                  </Button>

                  {/* Quick Login Button */}
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t border-gray-300" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-white px-2 text-gray-500">Or</span>
                    </div>
                  </div>

                  <Button 
                    type="button"
                    onClick={handleQuickLogin}
                    className="w-full wellness-button-secondary" 
                    disabled={loading}
                    variant="outline"
                  >
                    {loading ? '🔄 Logging in...' : '⚡ Quick Login (Test Account)'}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup" className="space-y-4">
                <form onSubmit={handleSignup} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <div className="relative">
                      <UserPlus className="absolute left-3 top-3 h-4 w-4 wellness-text-primary" />
                      <Input
                        id="name"
                        type="text"
                        placeholder="Enter your full name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="pl-10 wellness-focus"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-email">Email</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 wellness-text-primary" />
                      <Input
                        id="signup-email"
                        type="email"
                        placeholder="Enter your email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="pl-10 wellness-focus"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-password">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 wellness-text-primary" />
                      <Input
                        id="signup-password"
                        type="password"
                        placeholder="Create a password (min 6 characters)"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="pl-10 wellness-focus"
                        required
                        minLength={6}
                      />
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full wellness-button" 
                    disabled={loading}
                  >
                    {loading ? '📊 Creating account...' : '📊 Create Account'}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>

            {error && (
              <Alert 
                variant={demoMode ? "default" : "destructive"} 
                className={`mt-4 border-2 ${demoMode ? 'border-yellow-500 bg-yellow-50' : 'border-red-500 bg-red-50'}`}
              >
                <AlertDescription className={demoMode ? 'text-yellow-800' : 'text-red-800'}>
                  <div className="space-y-2">
                    <div>{error}</div>
                    {!demoMode && (
                      <div className="text-sm opacity-80">
                        💡 Tip: Double-check your email and password, or try Demo Mode to explore the app.
                      </div>
                    )}
                  </div>
                  {demoMode && (
                    <div className="mt-3 flex gap-2 flex-wrap">
                      <Button
                        onClick={handleDemoMode}
                        variant="outline"
                        size="sm"
                        className="wellness-button"
                      >
                        🚀 Continue in Demo Mode
                      </Button>
                      <Button
                        onClick={() => {
                          setDemoMode(false);
                          setError('');
                        }}
                        variant="outline"
                        size="sm"
                      >
                        ✕ Cancel
                      </Button>
                    </div>
                  )}
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Test Account Credentials Card */}
        <Card className="wellness-card border-green-200 bg-green-50">
          <CardContent className="pt-6">
            <div className="space-y-3">
              <div className="text-center">
                <p className="text-sm text-green-800">
                  <strong>⚡ Quick Access Test Account</strong>
                </p>
              </div>
              <div className="bg-white rounded-lg p-4 text-sm space-y-2 border border-green-200">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Email:</span>
                  <code className="bg-gray-100 px-3 py-1 rounded text-xs font-mono">{DEFAULT_EMAIL}</code>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Password:</span>
                  <code className="bg-gray-100 px-3 py-1 rounded text-xs font-mono">{DEFAULT_PASSWORD}</code>
                </div>
              </div>
              <p className="text-xs text-green-700 text-center">
                💡 Use "Quick Login" button above or enter these credentials manually
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Demo Mode Access */}
        <Card className="wellness-card border-blue-200 bg-blue-50">
          <CardContent className="pt-6">
            <div className="text-center space-y-3">
              <p className="text-sm text-blue-800">
                Want to explore the app without creating an account?
              </p>
              <Button
                onClick={handleDemoMode}
                variant="outline"
                className="w-full border-blue-300 hover:bg-blue-100 text-blue-800"
              >
                🚀 Try Demo Mode
              </Button>
              <p className="text-xs text-blue-600">
                Demo mode lets you explore all features without authentication
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Diagnostics Tool */}
        <LoginDiagnostics />

        {/* Debug Info */}
        <Card className="wellness-card border-gray-200 bg-gray-50">
          <CardContent className="pt-6">
            <div className="text-center space-y-2">
              <p className="text-xs text-gray-600">
                <strong>Troubleshooting Login Issues:</strong>
              </p>
              <div className="text-xs text-gray-600 space-y-1 text-left px-4">
                <div>• <strong>Try "Quick Login"</strong> button for instant access</div>
                <div>• Use test credentials: {DEFAULT_EMAIL} / {DEFAULT_PASSWORD}</div>
                <div>• Check browser console (F12) for detailed error logs</div>
                <div>• Ensure you're using a valid email format</div>
                <div>• Password must be at least 6 characters</div>
                <div>• If signup fails, the account may already exist - try logging in</div>
                <div>• <strong>Use the Diagnostics tool above</strong> to test your connection</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-2 text-sm text-[var(--wellness-text-muted)]">
            <span>🔒 Secure</span>
            <span>•</span>
            <span>📊 Professional</span>
            <span>•</span>
            <span>💼 Business Focused</span>
          </div>
        </div>
      </div>
    </div>
  );
}
