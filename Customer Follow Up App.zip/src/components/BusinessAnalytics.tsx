import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { 
  LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';
import {
  TrendingUp, TrendingDown, Users, Calendar, CheckCircle, AlertTriangle,
  Target, DollarSign, Clock, PhoneCall, Mail, Video, MessageSquare,
  BarChart3, PieChart as PieChartIcon, Activity, Award, Zap, Eye
} from 'lucide-react';

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  status: 'active' | 'inactive' | 'prospect';
  lastContact: string;
  followUps: FollowUp[];
  templateType?: string;
  commitmentLevel?: string;
  age?: string;
  weight?: string;
  height?: string;
  activityLevel?: string;
  stressLevel?: string;
  goals?: string;
  challenges?: string;
  supportNeeded?: string;
  communicationPreference?: string;
  medicalConditions?: string;
}

interface FollowUp {
  id: string;
  customerId: string;
  type: 'call' | 'email' | 'meeting' | 'task';
  subject: string;
  description: string;
  date: string;
  status: 'pending' | 'completed' | 'overdue';
  priority: 'low' | 'medium' | 'high';
  outcomes?: {
    goalProgress?: string;
    stressChange?: string;
    energyLevel?: string;
    sleepQuality?: string;
    nutritionCompliance?: string;
    nextSteps?: string;
  };
  createdAt?: string;
  updatedAt?: string;
}

interface BusinessAnalyticsProps {
  customers: Customer[];
  followUps: FollowUp[];
  onUpdateFollowUp: (followUpId: string, updates: Partial<FollowUp>) => void;
  pdfMode?: boolean; // Optional prop to disable complex elements for PDF export
}

export function BusinessAnalytics({ customers, followUps, onUpdateFollowUp, pdfMode = false }: BusinessAnalyticsProps) {
  const [selectedPeriod, setSelectedPeriod] = useState<string>('30');
  const [selectedMetric, setSelectedMetric] = useState<string>('overview');

  // Date filtering helper
  const getDateRange = (days: number) => {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    return { startDate, endDate };
  };

  // Filter data by selected period
  const filterByPeriod = (items: any[], dateField: string) => {
    const { startDate } = getDateRange(parseInt(selectedPeriod));
    return items.filter(item => {
      const itemDate = new Date(item[dateField]);
      return itemDate >= startDate;
    });
  };

  // Key Performance Indicators
  const calculateKPIs = () => {
    const totalClients = customers.length;
    const activeClients = customers.filter(c => c.status === 'active').length;
    const prospectClients = customers.filter(c => c.status === 'prospect').length;
    const inactiveClients = customers.filter(c => c.status === 'inactive').length;

    const allFollowUps = followUps;
    const completedFollowUps = allFollowUps.filter(f => f.status === 'completed').length;
    const pendingFollowUps = allFollowUps.filter(f => f.status === 'pending').length;
    const overdueFollowUps = allFollowUps.filter(f => f.status === 'overdue').length;

    const completionRate = allFollowUps.length > 0 ? (completedFollowUps / allFollowUps.length) * 100 : 0;
    const activeRate = totalClients > 0 ? (activeClients / totalClients) * 100 : 0;

    // Time-based metrics
    const recentFollowUps = filterByPeriod(allFollowUps, 'date');
    const recentCompleted = recentFollowUps.filter(f => f.status === 'completed').length;
    const recentCompletionRate = recentFollowUps.length > 0 ? (recentCompleted / recentFollowUps.length) * 100 : 0;

    // Client engagement metrics
    const highEngagement = customers.filter(c => {
      const clientFollowUps = c.followUps || [];
      const recentClientFollowUps = filterByPeriod(clientFollowUps, 'date');
      return recentClientFollowUps.length >= 3;
    }).length;

    // Response rate (completed vs total)
    const responseRate = pendingFollowUps + completedFollowUps > 0 ? 
      (completedFollowUps / (pendingFollowUps + completedFollowUps)) * 100 : 0;

    return {
      totalClients,
      activeClients,
      prospectClients,
      inactiveClients,
      completedFollowUps,
      pendingFollowUps,
      overdueFollowUps,
      completionRate,
      activeRate,
      recentCompletionRate,
      highEngagement,
      responseRate
    };
  };

  // Generate trend data for charts
  const generateTrendData = () => {
    const days = parseInt(selectedPeriod);
    const data = [];
    
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const dayFollowUps = followUps.filter(f => f.date === dateStr);
      const completed = dayFollowUps.filter(f => f.status === 'completed').length;
      const pending = dayFollowUps.filter(f => f.status === 'pending').length;
      const overdue = dayFollowUps.filter(f => f.status === 'overdue').length;
      
      data.push({
        date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        completed,
        pending,
        overdue,
        total: completed + pending + overdue
      });
    }
    
    return data;
  };

  // Client status distribution for pie chart
  const getClientStatusData = () => {
    const kpis = calculateKPIs();
    return [
      { name: 'Active', value: kpis.activeClients, color: '#16a085' },
      { name: 'Prospects', value: kpis.prospectClients, color: '#f39c12' },
      { name: 'Inactive', value: kpis.inactiveClients, color: '#95a5a6' }
    ];
  };

  // Follow-up type distribution
  const getFollowUpTypeData = () => {
    const types = ['call', 'email', 'meeting', 'task'];
    return types.map(type => ({
      name: type.charAt(0).toUpperCase() + type.slice(1),
      value: followUps.filter(f => f.type === type).length,
      completed: followUps.filter(f => f.type === type && f.status === 'completed').length
    }));
  };

  // Client engagement levels
  const getEngagementData = () => {
    const engagementLevels = customers.map(client => {
      const clientFollowUps = client.followUps || [];
      const recentFollowUps = filterByPeriod(clientFollowUps, 'date');
      const completedRecent = recentFollowUps.filter(f => f.status === 'completed').length;
      
      let level = 'Low';
      if (completedRecent >= 5) level = 'High';
      else if (completedRecent >= 2) level = 'Medium';
      
      return { client: client.name, level, count: completedRecent };
    });

    const high = engagementLevels.filter(e => e.level === 'High').length;
    const medium = engagementLevels.filter(e => e.level === 'Medium').length;
    const low = engagementLevels.filter(e => e.level === 'Low').length;

    return [
      { name: 'High Engagement', value: high, color: '#27ae60' },
      { name: 'Medium Engagement', value: medium, color: '#f39c12' },
      { name: 'Low Engagement', value: low, color: '#e74c3c' }
    ];
  };

  // Performance insights
  const getPerformanceInsights = () => {
    const kpis = calculateKPIs();
    const insights = [];

    if (kpis.completionRate > 80) {
      insights.push({ 
        type: 'success', 
        title: 'Excellent Follow-up Rate', 
        description: `${kpis.completionRate.toFixed(1)}% completion rate is outstanding!`,
        icon: <Award className="w-5 h-5" />
      });
    } else if (kpis.completionRate < 50) {
      insights.push({ 
        type: 'warning', 
        title: 'Low Completion Rate', 
        description: `${kpis.completionRate.toFixed(1)}% completion rate needs improvement`,
        icon: <AlertTriangle className="w-5 h-5" />
      });
    }

    if (kpis.activeRate > 70) {
      insights.push({ 
        type: 'success', 
        title: 'Strong Client Base', 
        description: `${kpis.activeRate.toFixed(1)}% of clients are active`,
        icon: <TrendingUp className="w-5 h-5" />
      });
    }

    if (kpis.overdueFollowUps > 5) {
      insights.push({ 
        type: 'error', 
        title: 'Overdue Actions', 
        description: `${kpis.overdueFollowUps} follow-ups are overdue`,
        icon: <Clock className="w-5 h-5" />
      });
    }

    if (kpis.highEngagement > kpis.totalClients * 0.3) {
      insights.push({ 
        type: 'success', 
        title: 'High Engagement', 
        description: `${kpis.highEngagement} clients are highly engaged`,
        icon: <Zap className="w-5 h-5" />
      });
    }

    return insights;
  };

  const kpis = calculateKPIs();
  const trendData = generateTrendData();
  const clientStatusData = getClientStatusData();
  const followUpTypeData = getFollowUpTypeData();
  const engagementData = getEngagementData();
  const insights = getPerformanceInsights();

  const COLORS = ['#16a085', '#2dd4bf', '#10b981', '#f39c12', '#e74c3c'];

  return (
    <div className="space-y-6">
      {/* Header with Period Selection */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl wellness-text-primary">📊 Lead Analytics & Tracking</h1>
          <p className="text-[var(--wellness-text-muted)]">Comprehensive insights into your lead follow-up performance</p>
        </div>
        <div className="flex gap-3">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-40 wellness-focus">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="wellness-card">
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 90 days</SelectItem>
              <SelectItem value="365">Last year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Key Performance Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="wellness-card wellness-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">Total Leads</p>
                <p className="text-3xl wellness-text-primary">{kpis.totalClients}</p>
                <p className="text-xs text-[var(--wellness-text-muted)]">
                  {kpis.activeRate.toFixed(1)}% active
                </p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="wellness-card wellness-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">Completion Rate</p>
                <p className="text-3xl wellness-text-secondary">{kpis.completionRate.toFixed(1)}%</p>
                <p className="text-xs text-[var(--wellness-text-muted)]">
                  {kpis.completedFollowUps} of {followUps.length} completed
                </p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-secondary)] to-[var(--wellness-accent)] rounded-xl flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="wellness-card wellness-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">Response Rate</p>
                <p className="text-3xl text-purple-600">{kpis.responseRate.toFixed(1)}%</p>
                <p className="text-xs text-[var(--wellness-text-muted)]">
                  Lead responsiveness
                </p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-purple-500 rounded-xl flex items-center justify-center">
                <Activity className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="wellness-card wellness-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">High Engagement</p>
                <p className="text-3xl text-amber-600">{kpis.highEngagement}</p>
                <p className="text-xs text-[var(--wellness-text-muted)]">
                  Active leads
                </p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-500 rounded-xl flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Insights */}
      {insights.length > 0 && (
        <Card className="wellness-card">
          <CardHeader>
            <CardTitle className="wellness-text-primary flex items-center gap-2">
              <Eye className="w-5 h-5" />
              Performance Insights
            </CardTitle>
            <CardDescription>Key observations about your lead tracking performance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {insights.map((insight, index) => (
                <div 
                  key={index}
                  className={`p-4 rounded-lg border ${
                    insight.type === 'success' ? 'bg-green-50 border-green-200' :
                    insight.type === 'warning' ? 'bg-yellow-50 border-yellow-200' :
                    'bg-red-50 border-red-200'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-lg ${
                      insight.type === 'success' ? 'bg-green-100 text-green-600' :
                      insight.type === 'warning' ? 'bg-yellow-100 text-yellow-600' :
                      'bg-red-100 text-red-600'
                    }`}>
                      {insight.icon}
                    </div>
                    <div>
                      <h4 className="font-medium mb-1">{insight.title}</h4>
                      <p className="text-sm text-[var(--wellness-text-muted)]">{insight.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="trends" className="space-y-4">
        <TabsList className="wellness-bg-light">
          <TabsTrigger value="trends" className="wellness-focus">📈 Trends</TabsTrigger>
          <TabsTrigger value="distribution" className="wellness-focus">📊 Distribution</TabsTrigger>
          <TabsTrigger value="performance" className="wellness-focus">🎯 Performance</TabsTrigger>
          <TabsTrigger value="engagement" className="wellness-focus">⚡ Engagement</TabsTrigger>
        </TabsList>

        <TabsContent value="trends" className="space-y-4">
          <Card className="wellness-card">
            <CardHeader>
              <CardTitle className="wellness-text-primary">Follow-up Activity Trends</CardTitle>
              <CardDescription>Track your follow-up patterns over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                {pdfMode ? (
                  <div className="w-full h-full flex items-center justify-center bg-gray-50 rounded-lg">
                    <div className="text-center space-y-2">
                      <BarChart3 className="w-16 h-16 mx-auto text-gray-400" />
                      <p className="text-gray-600">Interactive Chart</p>
                      <p className="text-sm text-gray-500">Data trends available in web version</p>
                    </div>
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e0e7ff" />
                      <XAxis dataKey="date" stroke="#6b7280" />
                      <YAxis stroke="#6b7280" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#ffffff', 
                          border: '1px solid #d1d5db',
                          borderRadius: '8px'
                        }} 
                      />
                      <Legend />
                      <Area 
                        type="monotone" 
                        dataKey="completed" 
                        stackId="1" 
                        stroke="#16a085" 
                        fill="#16a085" 
                        name="Completed"
                      />
                      <Area 
                        type="monotone" 
                        dataKey="pending" 
                        stackId="1" 
                        stroke="#f39c12" 
                        fill="#f39c12" 
                        name="Pending"
                      />
                      <Area 
                        type="monotone" 
                        dataKey="overdue" 
                        stackId="1" 
                        stroke="#e74c3c" 
                        fill="#e74c3c" 
                        name="Overdue"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="distribution" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="wellness-card">
              <CardHeader>
                <CardTitle className="wellness-text-primary">Lead Status Distribution</CardTitle>
                <CardDescription>Overview of your lead pipeline</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  {pdfMode ? (
                    <div className="space-y-3 p-4">
                      {clientStatusData.map((item, index) => (
                        <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <span className="flex items-center gap-2">
                            <div 
                              className="w-4 h-4 rounded-full" 
                              style={{ backgroundColor: item.color }}
                            />
                            {item.name}
                          </span>
                          <Badge>{item.value}</Badge>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={clientStatusData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {clientStatusData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="wellness-card">
              <CardHeader>
                <CardTitle className="wellness-text-primary">Follow-up Types</CardTitle>
                <CardDescription>Distribution of follow-up activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  {pdfMode ? (
                    <div className="space-y-3 p-4">
                      {followUpTypeData.map((item, index) => (
                        <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <span>{item.name}</span>
                          <div className="flex gap-2">
                            <Badge variant="outline">Total: {item.value}</Badge>
                            <Badge className="bg-[var(--wellness-secondary)] text-white">
                              Completed: {item.completed}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={followUpTypeData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e0e7ff" />
                        <XAxis dataKey="name" stroke="#6b7280" />
                        <YAxis stroke="#6b7280" />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: '#ffffff', 
                            border: '1px solid #d1d5db',
                            borderRadius: '8px'
                          }} 
                        />
                        <Bar dataKey="value" fill="#16a085" name="Total" />
                        <Bar dataKey="completed" fill="#2dd4bf" name="Completed" />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="wellness-card">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg wellness-text-primary">Completion Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Overall Completion</span>
                    <span>{kpis.completionRate.toFixed(1)}%</span>
                  </div>
                  <Progress value={kpis.completionRate} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Recent Period</span>
                    <span>{kpis.recentCompletionRate.toFixed(1)}%</span>
                  </div>
                  <Progress value={kpis.recentCompletionRate} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Response Rate</span>
                    <span>{kpis.responseRate.toFixed(1)}%</span>
                  </div>
                  <Progress value={kpis.responseRate} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card className="wellness-card">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg wellness-text-primary">Client Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Active Clients</span>
                  <Badge className="bg-[var(--wellness-primary)] text-white">
                    {kpis.activeClients}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Prospects</span>
                  <Badge className="bg-amber-100 text-amber-800">
                    {kpis.prospectClients}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">High Engagement</span>
                  <Badge className="bg-purple-100 text-purple-800">
                    {kpis.highEngagement}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Inactive</span>
                  <Badge variant="outline">
                    {kpis.inactiveClients}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="wellness-card">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg wellness-text-primary">Action Items</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Pending Follow-ups</span>
                  <Badge className="bg-amber-100 text-amber-800">
                    {kpis.pendingFollowUps}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Overdue Actions</span>
                  <Badge variant="destructive">
                    {kpis.overdueFollowUps}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Completed</span>
                  <Badge className="bg-[var(--wellness-secondary)] text-white">
                    {kpis.completedFollowUps}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="engagement" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="wellness-card">
              <CardHeader>
                <CardTitle className="wellness-text-primary">Client Engagement Levels</CardTitle>
                <CardDescription>Distribution of client activity levels</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  {pdfMode ? (
                    <div className="space-y-3 p-4">
                      {engagementData.map((item, index) => (
                        <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <span className="flex items-center gap-2">
                            <div 
                              className="w-4 h-4 rounded-full" 
                              style={{ backgroundColor: item.color }}
                            />
                            {item.name}
                          </span>
                          <Badge>{item.value}</Badge>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={engagementData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {engagementData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="wellness-card">
              <CardHeader>
                <CardTitle className="wellness-text-primary">Top Performing Clients</CardTitle>
                <CardDescription>Clients with highest follow-up completion rates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {customers
                    .map(client => {
                      const clientFollowUps = client.followUps || [];
                      const completed = clientFollowUps.filter(f => f.status === 'completed').length;
                      const total = clientFollowUps.length;
                      const rate = total > 0 ? (completed / total) * 100 : 0;
                      return { ...client, completionRate: rate, total };
                    })
                    .filter(client => client.total > 0)
                    .sort((a, b) => b.completionRate - a.completionRate)
                    .slice(0, 5)
                    .map(client => (
                      <div key={client.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">{client.name}</p>
                          <p className="text-sm text-[var(--wellness-text-muted)]">
                            {client.followUps?.filter(f => f.status === 'completed').length || 0} of {client.followUps?.length || 0} completed
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge className="bg-[var(--wellness-primary)] text-white">
                            {client.completionRate.toFixed(0)}%
                          </Badge>
                        </div>
                      </div>
                    ))
                  }
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}