import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Textarea } from './ui/textarea';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Alert, AlertDescription } from './ui/alert';
import { ArrowLeft, Save, AlertCircle, CheckCircle2, Calendar, Phone, User, MapPin, Users, Target, MessageSquare, ClipboardList, X } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { Separator } from './ui/separator';

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  age?: string;
  gender?: string;
  city?: string;
  leadSource?: string;
  interestArea?: string;
  currentConcern?: string;
  followUpDate?: string;
  nextFollowUpDate?: string;
  followUpStatus?: string;
  coachAssignedTo?: string;
  nextActionPlan?: string;
  remarks?: string;
  lastContact: string;
  templateType?: string;
}

interface EditCustomerProps {
  customer: Customer;
  onUpdate: (customerId: string, updates: Partial<Customer>) => void;
  onCancel: () => void;
}

export function EditCustomer({ customer, onUpdate, onCancel }: EditCustomerProps) {
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    fullName: customer.name || '',
    mobileNumber: customer.phone || '',
    age: customer.age || '',
    gender: customer.gender || '',
    city: customer.city || '',
    leadSource: customer.leadSource || '',
    interestArea: customer.interestArea || '',
    currentConcern: customer.currentConcern || '',
    followUpDate: customer.followUpDate || customer.lastContact || '',
    nextFollowUpDate: customer.nextFollowUpDate || '',
    followUpStatus: customer.followUpStatus || 'new-lead',
    coachAssignedTo: customer.coachAssignedTo || '',
    nextActionPlan: customer.nextActionPlan || '',
    remarks: customer.remarks || ''
  });

  // Validation rules
  const validateField = (field: string, value: string): string => {
    switch (field) {
      case 'fullName':
        if (!value.trim()) return 'Full name is required';
        if (value.trim().length < 2) return 'Name must be at least 2 characters';
        return '';
      case 'mobileNumber':
        if (!value.trim()) return 'Mobile number is required';
        // Remove spaces and check if it's 10 digits
        const cleanNumber = value.replace(/\s/g, '');
        if (!/^\d{10}$/.test(cleanNumber)) return 'Please enter a valid 10-digit mobile number';
        return '';
      case 'age':
        if (value && (parseInt(value) < 1 || parseInt(value) > 120)) {
          return 'Please enter a valid age';
        }
        return '';
      case 'gender':
        if (!value) return 'Please select a gender';
        return '';
      default:
        return '';
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear field error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Validate all required fields
    const newErrors: Record<string, string> = {};
    newErrors.fullName = validateField('fullName', formData.fullName);
    newErrors.mobileNumber = validateField('mobileNumber', formData.mobileNumber);
    newErrors.gender = validateField('gender', formData.gender);
    
    // Validate optional fields that have values
    if (formData.age) newErrors.age = validateField('age', formData.age);
    
    // Filter out empty errors
    const filteredErrors = Object.fromEntries(
      Object.entries(newErrors).filter(([_, value]) => value !== '')
    );
    
    setErrors(filteredErrors);
    
    if (Object.keys(filteredErrors).length > 0) {
      setIsSubmitting(false);
      toast.error('Please fix the errors in the form');
      return;
    }

    try {
      // Map followUpStatus to customer status
      let customerStatus: 'active' | 'prospect' | 'inactive' = 'prospect';
      switch (formData.followUpStatus) {
        case 'enrolled':
          customerStatus = 'active';
          break;
        case 'not-interested':
          customerStatus = 'inactive';
          break;
        case 'new-lead':
        case 'contacted':
        case 'interested':
        case 'follow-up-pending':
        default:
          customerStatus = 'prospect';
          break;
      }

      // Prepare updates
      const updates = {
        name: formData.fullName,
        phone: formData.mobileNumber,
        age: formData.age || undefined,
        gender: formData.gender,
        city: formData.city,
        leadSource: formData.leadSource,
        interestArea: formData.interestArea,
        currentConcern: formData.currentConcern,
        followUpDate: formData.followUpDate,
        nextFollowUpDate: formData.nextFollowUpDate,
        status: customerStatus,
        followUpStatus: formData.followUpStatus,
        coachAssignedTo: formData.coachAssignedTo,
        nextActionPlan: formData.nextActionPlan,
        remarks: formData.remarks,
      };
      
      await onUpdate(customer.id, updates);
      toast.success('Lead updated successfully!');
      onCancel(); // Close edit mode after successful update
    } catch (error) {
      console.error('Error updating lead:', error);
      toast.error('Failed to update lead. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen wellness-gradient p-4">
      <form onSubmit={handleSubmit}>
        <Card className="wellness-card max-w-5xl mx-auto">
          <CardHeader className="wellness-bg-light">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-full flex items-center justify-center text-white shadow-md">
                  <User className="w-6 h-6" />
                </div>
                <div>
                  <CardTitle className="wellness-text-primary flex items-center gap-2">
                    📝 Edit Lead
                  </CardTitle>
                  <CardDescription>Update lead information and tracking details</CardDescription>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  disabled={isSubmitting}
                  className="wellness-button-secondary"
                >
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="wellness-button"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {isSubmitting ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-6 space-y-6">
            {/* Basic Information */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-lg flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <h3 className="wellness-text-primary">Basic Information</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Full Name */}
                <div className="space-y-2">
                  <Label htmlFor="fullName" className="flex items-center gap-2">
                    <User className="w-4 h-4 wellness-text-primary" />
                    Full Name <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="fullName"
                    placeholder="Enter full name"
                    value={formData.fullName}
                    onChange={(e) => handleChange('fullName', e.target.value)}
                    className={`wellness-focus ${errors.fullName ? 'border-red-500' : ''}`}
                  />
                  {errors.fullName && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.fullName}
                    </p>
                  )}
                </div>

                {/* Mobile Number */}
                <div className="space-y-2">
                  <Label htmlFor="mobileNumber" className="flex items-center gap-2">
                    <Phone className="w-4 h-4 wellness-text-primary" />
                    Mobile Number <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="mobileNumber"
                    type="tel"
                    placeholder="10-digit mobile number"
                    value={formData.mobileNumber}
                    onChange={(e) => handleChange('mobileNumber', e.target.value)}
                    maxLength={10}
                    className={`wellness-focus ${errors.mobileNumber ? 'border-red-500' : ''}`}
                  />
                  {errors.mobileNumber && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.mobileNumber}
                    </p>
                  )}
                </div>

                {/* Age */}
                <div className="space-y-2">
                  <Label htmlFor="age" className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 wellness-text-primary" />
                    Age
                  </Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Age"
                    value={formData.age}
                    onChange={(e) => handleChange('age', e.target.value)}
                    min="1"
                    max="120"
                    className={`wellness-focus ${errors.age ? 'border-red-500' : ''}`}
                  />
                  {errors.age && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.age}
                    </p>
                  )}
                </div>

                {/* Gender */}
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Users className="w-4 h-4 wellness-text-primary" />
                    Gender <span className="text-red-500">*</span>
                  </Label>
                  <RadioGroup
                    value={formData.gender}
                    onValueChange={(value) => handleChange('gender', value)}
                    className="flex gap-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="male" id="male" />
                      <Label htmlFor="male" className="cursor-pointer">Male</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="female" id="female" />
                      <Label htmlFor="female" className="cursor-pointer">Female</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="other" id="other" />
                      <Label htmlFor="other" className="cursor-pointer">Other</Label>
                    </div>
                  </RadioGroup>
                  {errors.gender && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.gender}
                    </p>
                  )}
                </div>

                {/* City */}
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="city" className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 wellness-text-primary" />
                    City
                  </Label>
                  <Input
                    id="city"
                    placeholder="City"
                    value={formData.city}
                    onChange={(e) => handleChange('city', e.target.value)}
                    className="wellness-focus"
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Lead Tracking Information */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-lg flex items-center justify-center">
                  <Target className="w-4 h-4 text-white" />
                </div>
                <h3 className="wellness-text-primary">Lead Tracking</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Lead Source */}
                <div className="space-y-2">
                  <Label htmlFor="leadSource" className="flex items-center gap-2">
                    📱 Lead Source
                  </Label>
                  <Select value={formData.leadSource} onValueChange={(value) => handleChange('leadSource', value)}>
                    <SelectTrigger className="wellness-focus">
                      <SelectValue placeholder="Select source" />
                    </SelectTrigger>
                    <SelectContent className="wellness-card">
                      <SelectItem value="website">🌐 Website</SelectItem>
                      <SelectItem value="referral">👥 Referral</SelectItem>
                      <SelectItem value="social-media">📱 Social Media</SelectItem>
                      <SelectItem value="advertisement">📺 Advertisement</SelectItem>
                      <SelectItem value="walk-in">🚶 Walk-in</SelectItem>
                      <SelectItem value="event">🎉 Event</SelectItem>
                      <SelectItem value="other">📋 Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Interest Area */}
                <div className="space-y-2">
                  <Label htmlFor="interestArea" className="flex items-center gap-2">
                    💡 Interest Area
                  </Label>
                  <Select value={formData.interestArea} onValueChange={(value) => handleChange('interestArea', value)}>
                    <SelectTrigger className="wellness-focus">
                      <SelectValue placeholder="Select interest" />
                    </SelectTrigger>
                    <SelectContent className="wellness-card">
                      <SelectItem value="weight-loss">🏋️ Weight Loss</SelectItem>
                      <SelectItem value="fitness">💪 Fitness</SelectItem>
                      <SelectItem value="nutrition">🥗 Nutrition</SelectItem>
                      <SelectItem value="wellness">🧘 Wellness</SelectItem>
                      <SelectItem value="disease-management">🏥 Disease Management</SelectItem>
                      <SelectItem value="lifestyle">🌟 Lifestyle</SelectItem>
                      <SelectItem value="other">📋 Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Follow-up Status */}
                <div className="space-y-2">
                  <Label htmlFor="followUpStatus" className="flex items-center gap-2">
                    📊 Lead Status
                  </Label>
                  <Select value={formData.followUpStatus} onValueChange={(value) => handleChange('followUpStatus', value)}>
                    <SelectTrigger className="wellness-focus">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent className="wellness-card">
                      <SelectItem value="new-lead">🆕 New Lead</SelectItem>
                      <SelectItem value="contacted">📞 Contacted</SelectItem>
                      <SelectItem value="interested">⭐ Interested</SelectItem>
                      <SelectItem value="not-interested">❌ Not Interested</SelectItem>
                      <SelectItem value="enrolled">✅ Enrolled</SelectItem>
                      <SelectItem value="follow-up-pending">⏳ Follow-Up Pending</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Coach Assigned To */}
                <div className="space-y-2">
                  <Label htmlFor="coachAssignedTo" className="flex items-center gap-2">
                    👤 Coach Assigned
                  </Label>
                  <Input
                    id="coachAssignedTo"
                    placeholder="Coach name"
                    value={formData.coachAssignedTo}
                    onChange={(e) => handleChange('coachAssignedTo', e.target.value)}
                    className="wellness-focus"
                  />
                </div>

                {/* Follow-up Date */}
                <div className="space-y-2">
                  <Label htmlFor="followUpDate" className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 wellness-text-primary" />
                    Initial Follow-up Date
                  </Label>
                  <Input
                    id="followUpDate"
                    type="date"
                    value={formData.followUpDate}
                    onChange={(e) => handleChange('followUpDate', e.target.value)}
                    className="wellness-focus"
                  />
                </div>

                {/* Next Follow-up Date */}
                <div className="space-y-2">
                  <Label htmlFor="nextFollowUpDate" className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 wellness-text-primary" />
                    Next Follow-up Date
                  </Label>
                  <Input
                    id="nextFollowUpDate"
                    type="date"
                    value={formData.nextFollowUpDate}
                    onChange={(e) => handleChange('nextFollowUpDate', e.target.value)}
                    className="wellness-focus"
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Additional Details */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-lg flex items-center justify-center">
                  <ClipboardList className="w-4 h-4 text-white" />
                </div>
                <h3 className="wellness-text-primary">Additional Details</h3>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {/* Current Concern */}
                <div className="space-y-2">
                  <Label htmlFor="currentConcern" className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 wellness-text-primary" />
                    Current Health Concern
                  </Label>
                  <Textarea
                    id="currentConcern"
                    placeholder="Describe the lead's current health concern or goal..."
                    value={formData.currentConcern}
                    onChange={(e) => handleChange('currentConcern', e.target.value)}
                    rows={3}
                    className="wellness-focus resize-none"
                  />
                </div>

                {/* Next Action Plan */}
                <div className="space-y-2">
                  <Label htmlFor="nextActionPlan" className="flex items-center gap-2">
                    <Target className="w-4 h-4 wellness-text-primary" />
                    Next Action Plan
                  </Label>
                  <Textarea
                    id="nextActionPlan"
                    placeholder="Outline the next steps or action plan..."
                    value={formData.nextActionPlan}
                    onChange={(e) => handleChange('nextActionPlan', e.target.value)}
                    rows={3}
                    className="wellness-focus resize-none"
                  />
                </div>

                {/* Remarks */}
                <div className="space-y-2">
                  <Label htmlFor="remarks" className="flex items-center gap-2">
                    <ClipboardList className="w-4 h-4 wellness-text-primary" />
                    Notes & Remarks
                  </Label>
                  <Textarea
                    id="remarks"
                    placeholder="Any additional notes or remarks..."
                    value={formData.remarks}
                    onChange={(e) => handleChange('remarks', e.target.value)}
                    rows={3}
                    className="wellness-focus resize-none"
                  />
                </div>
              </div>
            </div>

            {/* Submit Section */}
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={onCancel}
                disabled={isSubmitting}
                className="wellness-button-secondary"
              >
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="wellness-button"
              >
                <Save className="w-4 h-4 mr-2" />
                {isSubmitting ? 'Saving...' : 'Save Changes'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}
