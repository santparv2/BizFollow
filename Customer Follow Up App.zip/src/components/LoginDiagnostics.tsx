import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { supabase } from '../utils/supabase';
import { apiClient } from '../utils/api';

export function LoginDiagnostics() {
  const [testResults, setTestResults] = useState<any>(null);
  const [testing, setTesting] = useState(false);

  const runDiagnostics = async () => {
    setTesting(true);
    const results: any = {
      timestamp: new Date().toISOString(),
      tests: {}
    };

    try {
      // Test 1: Check if browser is online
      results.tests.browserOnline = {
        status: navigator.onLine ? '✅ PASS' : '❌ FAIL',
        value: navigator.onLine,
        message: navigator.onLine ? 'Browser is online' : 'Browser is offline'
      };

      // Test 2: Check Supabase connection
      try {
        const { data, error } = await supabase.auth.getSession();
        results.tests.supabaseConnection = {
          status: error ? '❌ FAIL' : '✅ PASS',
          message: error ? `Error: ${error.message}` : 'Supabase connected',
          error: error?.message || null
        };
      } catch (err: any) {
        results.tests.supabaseConnection = {
          status: '❌ FAIL',
          message: 'Failed to connect to Supabase',
          error: err.message || err.toString()
        };
      }

      // Test 3: Try to reach backend API
      try {
        const healthCheck = await apiClient.healthCheck();
        results.tests.backendHealth = {
          status: '✅ PASS',
          message: 'Backend API is reachable',
          response: healthCheck
        };
      } catch (err: any) {
        results.tests.backendHealth = {
          status: '❌ FAIL',
          message: 'Backend API is not reachable',
          error: err.message || err.toString()
        };
      }

      // Test 4: Test signup endpoint (dry run)
      try {
        const testEmail = `test${Date.now()}@example.com`;
        const response = await fetch('https://tfrtakkvnkwxmervjozd.supabase.co/functions/v1/make-server-b8fc68da/signup', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email: testEmail,
            password: 'test123456',
            name: 'Test User'
          })
        });
        
        const data = await response.json();
        results.tests.signupEndpoint = {
          status: response.ok ? '✅ PASS' : '⚠️ WARNING',
          message: response.ok ? 'Signup endpoint is working' : 'Signup endpoint returned error (might be rate limited)',
          statusCode: response.status,
          response: data
        };
      } catch (err: any) {
        results.tests.signupEndpoint = {
          status: '❌ FAIL',
          message: 'Cannot reach signup endpoint',
          error: err.message || err.toString()
        };
      }

      // Test 5: Check Supabase project configuration
      results.tests.supabaseConfig = {
        status: '✅ PASS',
        projectId: 'tfrtakkvnkwxmervjozd',
        url: 'https://tfrtakkvnkwxmervjozd.supabase.co',
        message: 'Supabase configuration loaded'
      };

    } catch (err: any) {
      results.error = err.message || err.toString();
    }

    setTestResults(results);
    setTesting(false);
  };

  return (
    <Card className="wellness-card border-purple-200 bg-purple-50">
      <CardHeader>
        <CardTitle className="text-purple-800 flex items-center gap-2">
          🔧 Login Diagnostics
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-purple-800">
          Run a comprehensive test to identify any login issues
        </p>
        
        <Button
          onClick={runDiagnostics}
          disabled={testing}
          className="w-full"
          variant="outline"
        >
          {testing ? '🔄 Running Tests...' : '🔧 Run Diagnostic Tests'}
        </Button>

        {testResults && (
          <div className="space-y-3 mt-4">
            <div className="text-xs text-purple-800 font-semibold">
              Test Results ({testResults.timestamp})
            </div>
            
            <div className="space-y-2 bg-white p-3 rounded border border-purple-200 max-h-96 overflow-y-auto">
              {Object.entries(testResults.tests).map(([testName, result]: [string, any]) => (
                <div key={testName} className="text-xs border-b border-gray-200 pb-2 last:border-0">
                  <div className="font-semibold text-gray-700">{testName}:</div>
                  <div className="ml-2 space-y-1">
                    <div>{result.status} - {result.message}</div>
                    {result.error && (
                      <div className="text-red-600">Error: {result.error}</div>
                    )}
                    {result.value !== undefined && (
                      <div className="text-gray-600">Value: {String(result.value)}</div>
                    )}
                    {result.response && (
                      <details className="text-gray-500">
                        <summary className="cursor-pointer">View response</summary>
                        <pre className="text-xs mt-1 bg-gray-50 p-2 rounded overflow-x-auto">
                          {JSON.stringify(result.response, null, 2)}
                        </pre>
                      </details>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="text-xs text-purple-700 mt-3">
              📋 Copy these results when reporting the issue:
            </div>
            <Button
              onClick={() => {
                navigator.clipboard.writeText(JSON.stringify(testResults, null, 2));
                alert('Test results copied to clipboard!');
              }}
              variant="outline"
              size="sm"
              className="w-full text-xs"
            >
              📋 Copy Results to Clipboard
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
