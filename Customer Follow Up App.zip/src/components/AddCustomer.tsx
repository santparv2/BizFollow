import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Textarea } from './ui/textarea';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Alert, AlertDescription } from './ui/alert';
import { ArrowLeft, UserPlus, AlertCircle, CheckCircle2, Calendar, Phone, User, MapPin, Users, Target, MessageSquare, ClipboardList, Sparkles } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { Separator } from './ui/separator';

interface AddCustomerProps {
  onAdd: (customer: any) => void;
  onCancel: () => void;
}

export function AddCustomer({ onAdd, onCancel }: AddCustomerProps) {
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Get current date in YYYY-MM-DD format
  const getCurrentDate = () => {
    return new Date().toISOString().split('T')[0];
  };
  
  const [formData, setFormData] = useState({
    date: getCurrentDate(),
    fullName: '',
    mobileNumber: '',
    age: '',
    gender: '',
    city: '',
    leadSource: '',
    interestArea: '',
    currentConcern: '',
    followUpDate: getCurrentDate(),
    nextFollowUpDate: '',
    followUpStatus: 'new-lead',
    coachAssignedTo: '',
    nextActionPlan: '',
    remarks: ''
  });

  // Validation rules
  const validateField = (field: string, value: string): string => {
    switch (field) {
      case 'fullName':
        if (!value.trim()) return 'Full name is required';
        if (value.trim().length < 2) return 'Name must be at least 2 characters';
        return '';
      case 'mobileNumber':
        if (!value.trim()) return 'Mobile number is required';
        // Remove spaces and check if it's 10 digits
        const cleanNumber = value.replace(/\s/g, '');
        if (!/^\d{10}$/.test(cleanNumber)) return 'Please enter a valid 10-digit mobile number';
        return '';
      case 'age':
        if (value && (parseInt(value) < 1 || parseInt(value) > 120)) {
          return 'Please enter a valid age';
        }
        return '';
      case 'gender':
        if (!value) return 'Please select a gender';
        return '';
      default:
        return '';
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear field error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Validate all required fields
    const newErrors: Record<string, string> = {};
    newErrors.fullName = validateField('fullName', formData.fullName);
    newErrors.mobileNumber = validateField('mobileNumber', formData.mobileNumber);
    newErrors.gender = validateField('gender', formData.gender);
    
    // Validate optional fields that have values
    if (formData.age) newErrors.age = validateField('age', formData.age);
    
    // Filter out empty errors
    const filteredErrors = Object.fromEntries(
      Object.entries(newErrors).filter(([_, value]) => value !== '')
    );
    
    setErrors(filteredErrors);
    
    if (Object.keys(filteredErrors).length > 0) {
      setIsSubmitting(false);
      toast.error('Please fix the errors in the form');
      return;
    }

    try {
      // Map followUpStatus to customer status
      let customerStatus: 'active' | 'prospect' | 'inactive' = 'prospect';
      switch (formData.followUpStatus) {
        case 'enrolled':
          customerStatus = 'active';
          break;
        case 'not-interested':
          customerStatus = 'inactive';
          break;
        case 'new-lead':
        case 'contacted':
        case 'interested':
        case 'follow-up-pending':
        default:
          customerStatus = 'prospect';
          break;
      }

      // Prepare data for submission
      const customerData = {
        name: formData.fullName,
        phone: formData.mobileNumber,
        email: `${formData.mobileNumber}@lead.placeholder`, // Placeholder email for leads
        age: formData.age ? parseInt(formData.age) : null,
        gender: formData.gender,
        city: formData.city,
        leadSource: formData.leadSource,
        interestArea: formData.interestArea,
        currentConcern: formData.currentConcern,
        followUpDate: formData.followUpDate,
        nextFollowUpDate: formData.nextFollowUpDate,
        status: customerStatus,
        followUpStatus: formData.followUpStatus,
        coachAssignedTo: formData.coachAssignedTo,
        nextActionPlan: formData.nextActionPlan,
        remarks: formData.remarks,
        lastContact: formData.date,
        templateType: 'lead'
      };
      
      await onAdd(customerData);
      toast.success('Lead added successfully!');
    } catch (error) {
      console.error('Error saving lead:', error);
      toast.error('Failed to save lead');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen wellness-gradient p-4 pb-20">
      {/* Header */}
      <div className="mb-6 max-w-5xl mx-auto">
        <Card className="wellness-card overflow-hidden">
          <div className="bg-gradient-to-r from-[var(--wellness-primary)] to-[var(--wellness-secondary)] p-6">
            <div className="flex items-center gap-4">
              <Button 
                variant="outline" 
                onClick={onCancel} 
                className="bg-white/20 hover:bg-white/30 text-white border-white/40 backdrop-blur-sm"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center gap-4 flex-1">
                <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center text-white shadow-lg border border-white/30">
                  <Sparkles className="w-7 h-7" />
                </div>
                <div className="flex-1">
                  <h1 className="text-white text-2xl">🎯 Add New Lead</h1>
                  <p className="text-white/90 text-sm">Capture and track lead information for follow-up</p>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      <div className="max-w-5xl mx-auto">
        <Card className="wellness-card border-2 border-[var(--wellness-primary)]/20 shadow-2xl">
          <CardHeader className="bg-gradient-to-br from-green-50 to-teal-50 border-b border-green-100">
            <CardTitle className="wellness-text-primary flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-xl flex items-center justify-center shadow-md">
                <ClipboardList className="w-5 h-5 text-white" />
              </div>
              <div>
                Lead Information Form
                <p className="text-sm text-[var(--wellness-text-muted)] font-normal mt-1">
                  Complete the form below to add a new lead to your pipeline. Required fields are marked with *
                </p>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Error summary */}
              {Object.keys(errors).length > 0 && (
                <Alert className="border-2 border-red-300 bg-red-50 shadow-md">
                  <AlertCircle className="h-5 w-5 text-red-600" />
                  <AlertDescription className="text-red-700">
                    <strong>Please fix the errors below to continue</strong>
                  </AlertDescription>
                </Alert>
              )}

              {/* SECTION 1: Basic Information */}
              <div className="space-y-6">
                <div className="flex items-center gap-3 pb-3 border-b-2 border-[var(--wellness-primary)]/30">
                  <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                  <h3 className="text-lg text-purple-700">Basic Information</h3>
                </div>

                {/* Date */}
                <div className="space-y-2 bg-purple-50/50 p-4 rounded-lg border border-purple-100">
                  <Label htmlFor="date" className="flex items-center gap-2 text-purple-900">
                    <Calendar className="w-4 h-4 text-purple-600" />
                    Entry Date
                  </Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => handleChange('date', e.target.value)}
                    className="bg-white border-purple-200"
                  />
                  <p className="text-xs text-purple-600 flex items-center gap-1">
                    ✨ Automatically set to today or select manually
                  </p>
                </div>

                {/* Full Name */}
                <div className="space-y-2">
                  <Label htmlFor="fullName" className="flex items-center gap-2 text-purple-900">
                    👤 Full Name *
                    {errors.fullName && <AlertCircle className="w-4 h-4 text-red-500" />}
                  </Label>
                  <Input
                    id="fullName"
                    type="text"
                    placeholder="Enter full name"
                    value={formData.fullName}
                    onChange={(e) => handleChange('fullName', e.target.value)}
                    className={errors.fullName ? 'border-2 border-red-500 focus:border-red-500 bg-white' : 'bg-white border-purple-200'}
                    required
                  />
                  {errors.fullName && (
                    <p className="text-sm text-red-600 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.fullName}
                    </p>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Mobile Number */}
                  <div className="space-y-2">
                    <Label htmlFor="mobileNumber" className="flex items-center gap-2 text-purple-900">
                      <Phone className="w-4 h-4 text-purple-600" />
                      Mobile Number *
                      {errors.mobileNumber && <AlertCircle className="w-4 h-4 text-red-500" />}
                    </Label>
                    <Input
                      id="mobileNumber"
                      type="tel"
                      placeholder="10-digit mobile number"
                      value={formData.mobileNumber}
                      onChange={(e) => handleChange('mobileNumber', e.target.value)}
                      className={errors.mobileNumber ? 'border-2 border-red-500 focus:border-red-500 bg-white' : 'bg-white border-purple-200'}
                      required
                      maxLength={10}
                    />
                    {errors.mobileNumber && (
                      <p className="text-sm text-red-600 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {errors.mobileNumber}
                      </p>
                    )}
                  </div>

                  {/* Age */}
                  <div className="space-y-2">
                    <Label htmlFor="age" className="text-purple-900">🎂 Age</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="Enter age"
                      value={formData.age}
                      onChange={(e) => handleChange('age', e.target.value)}
                      min="1"
                      max="120"
                      className="bg-white border-purple-200"
                    />
                    {errors.age && (
                      <p className="text-sm text-red-600 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {errors.age}
                      </p>
                    )}
                  </div>
                </div>

                {/* Gender */}
                <div className="space-y-3 bg-purple-50/50 p-4 rounded-lg border border-purple-100">
                  <Label className="flex items-center gap-2 text-purple-900">
                    ⚧️ Gender *
                    {errors.gender && <AlertCircle className="w-4 h-4 text-red-500" />}
                  </Label>
                  <RadioGroup
                    value={formData.gender}
                    onValueChange={(value) => handleChange('gender', value)}
                    className="flex flex-wrap gap-4"
                  >
                    <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-lg border border-purple-200">
                      <RadioGroupItem value="male" id="male" />
                      <Label htmlFor="male" className="cursor-pointer">👨 Male</Label>
                    </div>
                    <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-lg border border-purple-200">
                      <RadioGroupItem value="female" id="female" />
                      <Label htmlFor="female" className="cursor-pointer">👩 Female</Label>
                    </div>
                    <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-lg border border-purple-200">
                      <RadioGroupItem value="other" id="other" />
                      <Label htmlFor="other" className="cursor-pointer">🌟 Other</Label>
                    </div>
                  </RadioGroup>
                  {errors.gender && (
                    <p className="text-sm text-red-600 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.gender}
                    </p>
                  )}
                </div>

                {/* City */}
                <div className="space-y-2">
                  <Label htmlFor="city" className="flex items-center gap-2 text-purple-900">
                    <MapPin className="w-4 h-4 text-purple-600" />
                    City
                  </Label>
                  <Input
                    id="city"
                    type="text"
                    placeholder="Enter city"
                    value={formData.city}
                    onChange={(e) => handleChange('city', e.target.value)}
                    className="bg-white border-purple-200"
                  />
                </div>
              </div>

              {/* SECTION 2: Lead Details */}
              <div className="space-y-6">
                <div className="flex items-center gap-3 pb-3 border-b-2 border-[var(--wellness-primary)]/30">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
                    <Target className="w-4 h-4 text-white" />
                  </div>
                  <h3 className="text-lg text-blue-700">Lead Details</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Lead Source */}
                  <div className="space-y-2">
                    <Label htmlFor="leadSource" className="flex items-center gap-2 text-blue-900">
                      <Users className="w-4 h-4 text-blue-600" />
                      Lead Source
                    </Label>
                    <Select value={formData.leadSource} onValueChange={(value) => handleChange('leadSource', value)}>
                      <SelectTrigger className="bg-white border-blue-200">
                        <SelectValue placeholder="Select lead source" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="facebook-instagram">📱 Facebook / Instagram</SelectItem>
                        <SelectItem value="referral">👥 Referral</SelectItem>
                        <SelectItem value="whatsapp-telegram">💬 WhatsApp / Telegram</SelectItem>
                        <SelectItem value="event-webinar">🎤 Event / Webinar</SelectItem>
                        <SelectItem value="other">🔧 Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Interest Area */}
                  <div className="space-y-2">
                    <Label htmlFor="interestArea" className="flex items-center gap-2 text-blue-900">
                      <Target className="w-4 h-4 text-blue-600" />
                      Interest Area
                    </Label>
                    <Select value={formData.interestArea} onValueChange={(value) => handleChange('interestArea', value)}>
                      <SelectTrigger className="bg-white border-blue-200">
                        <SelectValue placeholder="Select interest area" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="weight-loss">⚖️ Weight Loss</SelectItem>
                        <SelectItem value="fitness">💪 Fitness</SelectItem>
                        <SelectItem value="nutrition">🥗 Nutrition Guidance</SelectItem>
                        <SelectItem value="business-opportunity">💼 Wellness Business Opportunity</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Current Lifestyle / Health Concern */}
                <div className="space-y-2 bg-blue-50/50 p-4 rounded-lg border border-blue-100">
                  <Label htmlFor="currentConcern" className="flex items-center gap-2 text-blue-900">
                    <MessageSquare className="w-4 h-4 text-blue-600" />
                    Current Lifestyle / Health Concern
                  </Label>
                  <Textarea
                    id="currentConcern"
                    placeholder="e.g., sedentary lifestyle, weight gain, low energy, etc."
                    value={formData.currentConcern}
                    onChange={(e) => handleChange('currentConcern', e.target.value)}
                    rows={3}
                    className="bg-white border-blue-200"
                  />
                  <p className="text-xs text-blue-600">💡 Describe their main health or lifestyle concerns</p>
                </div>
              </div>

              {/* Follow-Up Tracking Section */}
              <div className="space-y-4 p-4 rounded-lg bg-gradient-to-br from-green-50 to-teal-50 border border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <Calendar className="w-5 h-5 wellness-text-primary" />
                  <h3 className="wellness-text-primary">Follow-Up Tracking</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Follow-Up Date */}
                  <div className="space-y-2">
                    <Label htmlFor="followUpDate" className="flex items-center gap-2">
                      📅 Follow-Up Date
                    </Label>
                    <Input
                      id="followUpDate"
                      type="date"
                      value={formData.followUpDate}
                      onChange={(e) => handleChange('followUpDate', e.target.value)}
                      className="bg-white"
                    />
                    <p className="text-xs text-[var(--wellness-text-muted)]">
                      Date of current follow-up
                    </p>
                  </div>

                  {/* Next Follow-Up Date */}
                  <div className="space-y-2">
                    <Label htmlFor="nextFollowUpDate" className="flex items-center gap-2">
                      📆 Next Follow-Up Date
                    </Label>
                    <Input
                      id="nextFollowUpDate"
                      type="date"
                      value={formData.nextFollowUpDate}
                      onChange={(e) => handleChange('nextFollowUpDate', e.target.value)}
                      min={formData.followUpDate}
                      className="bg-white border-2 border-[var(--wellness-primary)]"
                    />
                    <p className="text-xs text-green-700">
                      ⭐ Plan your next contact date
                    </p>
                  </div>
                </div>

                {/* Follow-Up Status */}
                <div className="space-y-2">
                  <Label htmlFor="followUpStatus" className="flex items-center gap-2">
                    📊 Follow-Up Status
                  </Label>
                  <Select value={formData.followUpStatus} onValueChange={(value) => handleChange('followUpStatus', value)}>
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new-lead">🆕 New Lead</SelectItem>
                      <SelectItem value="contacted">📞 Contacted</SelectItem>
                      <SelectItem value="interested">⭐ Interested</SelectItem>
                      <SelectItem value="not-interested">❌ Not Interested</SelectItem>
                      <SelectItem value="enrolled">✅ Enrolled</SelectItem>
                      <SelectItem value="follow-up-pending">⏳ Follow-Up Pending</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Assignment & Action Plan Section */}
              <div className="space-y-4 p-4 rounded-lg bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200">
                <div className="flex items-center gap-2 mb-2">
                  <User className="w-5 h-5 text-blue-600" />
                  <h3 className="text-blue-700">Assignment & Next Steps</h3>
                </div>

                {/* Coach / Assigned To */}
                <div className="space-y-2">
                  <Label htmlFor="coachAssignedTo" className="flex items-center gap-2">
                    👤 Coach / Assigned To
                  </Label>
                  <Input
                    id="coachAssignedTo"
                    type="text"
                    placeholder="Enter coach name"
                    value={formData.coachAssignedTo}
                    onChange={(e) => handleChange('coachAssignedTo', e.target.value)}
                    className="bg-white"
                  />
                </div>

                {/* Next Action Plan */}
                <div className="space-y-2">
                  <Label htmlFor="nextActionPlan" className="flex items-center gap-2">
                    🎯 Next Action Plan
                  </Label>
                  <Input
                    id="nextActionPlan"
                    type="text"
                    placeholder="e.g., schedule consultation, send diet plan, invite to webinar"
                    value={formData.nextActionPlan}
                    onChange={(e) => handleChange('nextActionPlan', e.target.value)}
                    className="bg-white"
                  />
                </div>
              </div>

              {/* Remarks / Notes */}
              <div className="space-y-2 bg-gray-50/50 p-4 rounded-lg border border-gray-200">
                <Label htmlFor="remarks" className="flex items-center gap-2 text-gray-900">
                  <MessageSquare className="w-4 h-4 text-gray-600" />
                  Remarks / Notes
                </Label>
                <Textarea
                  id="remarks"
                  placeholder="Add any additional notes or remarks about this lead"
                  value={formData.remarks}
                  onChange={(e) => handleChange('remarks', e.target.value)}
                  rows={4}
                  className="bg-white border-gray-200"
                />
                <p className="text-xs text-gray-600">📝 Add any extra information that might be helpful later</p>
              </div>

              {/* Form Actions */}
              <Separator className="my-6" />
              
              <div className="flex gap-4 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  className="flex-1 wellness-button-secondary h-12 text-base"
                  disabled={isSubmitting}
                >
                  <ArrowLeft className="w-5 h-5 mr-2" />
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="flex-1 wellness-button h-12 text-base shadow-lg hover:shadow-xl"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      Saving Lead...
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-5 h-5 mr-2" />
                      ✨ Add Lead to Pipeline
                    </>
                  )}
                </Button>
              </div>

              <p className="text-center text-sm text-[var(--wellness-text-muted)] pt-4">
                💡 Your lead will be added to the pipeline and ready for follow-up tracking
              </p>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
