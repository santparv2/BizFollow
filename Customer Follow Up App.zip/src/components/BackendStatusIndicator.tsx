import { useEffect, useState } from 'react';
import { Badge } from './ui/badge';
import { apiClient } from '../utils/api';
import { Cloud, CloudOff, Wifi, WifiOff } from 'lucide-react';

export function BackendStatusIndicator() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [backendStatus, setBackendStatus] = useState<'connected' | 'disconnected' | 'checking'>('checking');

  useEffect(() => {
    checkBackendStatus();
    
    const interval = setInterval(checkBackendStatus, 30000); // Check every 30 seconds
    
    const handleOnline = () => {
      setIsOnline(true);
      checkBackendStatus();
    };
    
    const handleOffline = () => {
      setIsOnline(false);
      setBackendStatus('disconnected');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      clearInterval(interval);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const checkBackendStatus = async () => {
    if (!navigator.onLine) {
      setBackendStatus('disconnected');
      return;
    }

    try {
      setBackendStatus('checking');
      await apiClient.healthCheck();
      setBackendStatus('connected');
    } catch (error) {
      setBackendStatus('disconnected');
    }
  };

  if (backendStatus === 'connected' && isOnline) {
    return (
      <Badge variant="outline" className="bg-green-50 border-green-300 text-green-800 gap-1">
        <Cloud className="h-3 w-3" />
        Backend Connected
      </Badge>
    );
  }

  if (backendStatus === 'checking') {
    return (
      <Badge variant="outline" className="bg-yellow-50 border-yellow-300 text-yellow-800 gap-1">
        <Wifi className="h-3 w-3 animate-pulse" />
        Checking...
      </Badge>
    );
  }

  return (
    <Badge variant="outline" className="bg-red-50 border-red-300 text-red-800 gap-1">
      <CloudOff className="h-3 w-3" />
      Offline
    </Badge>
  );
}
