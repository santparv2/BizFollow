import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Calendar, 
  TrendingUp, 
  Target, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  Activity,
  Heart,
  Brain,
  Apple,
  Moon,
  Users,
  MessageCircle,
  Phone,
  Video,
  Mail
} from 'lucide-react';

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  status: 'active' | 'inactive' | 'prospect';
  lastContact: string;
  followUps: FollowUp[];
  templateType?: string;
  // Wellness-specific fields
  age?: string;
  weight?: string;
  height?: string;
  activityLevel?: string;
  stressLevel?: string;
  goals?: string;
  challenges?: string;
  commitmentLevel?: string;
  communicationPreference?: string;
  medicalConditions?: string;
  supportNeeded?: string;
}

interface FollowUp {
  id: string;
  customerId: string;
  type: 'call' | 'email' | 'meeting' | 'task';
  subject: string;
  description: string;
  date: string;
  status: 'pending' | 'completed' | 'overdue';
  priority: 'low' | 'medium' | 'high';
  // Wellness tracking outcomes (optional)
  outcomes?: {
    goalProgress?: string;
    stressChange?: string;
    energyLevel?: string;
    sleepQuality?: string;
    nutritionCompliance?: string;
    nextSteps?: string;
  };
}

interface WellnessTrackerProps {
  customers: Customer[];
  followUps: FollowUp[];
  onUpdateFollowUp: (followUpId: string, updates: Partial<FollowUp>) => void;
}

export function WellnessTracker({ customers, followUps, onUpdateFollowUp }: WellnessTrackerProps) {
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [selectedPeriod, setSelectedPeriod] = useState<string>('week');

  // Calculate wellness metrics with null checks
  const wellnessMetrics = {
    totalClients: (customers || []).filter(c => c && c.templateType === 'wellness').length,
    activeClients: (customers || []).filter(c => c && c.templateType === 'wellness' && c.status === 'active').length,
    highCommitmentClients: (customers || []).filter(c => 
      c && c.templateType === 'wellness' && parseInt(c.commitmentLevel || '0') >= 8
    ).length,
    pendingFollowUps: (followUps || []).filter(f => f && f.status === 'pending').length,
    completedThisWeek: (followUps || []).filter(f => {
      if (!f || !f.date) return false;
      const followUpDate = new Date(f.date);
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      return f.status === 'completed' && followUpDate >= weekAgo;
    }).length
  };

  // Get upcoming follow-ups with client context
  const upcomingFollowUps = (followUps || [])
    .filter(f => f && f.status === 'pending')
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 10)
    .map(followUp => {
      const client = (customers || []).find(c => c && c.id === followUp.customerId);
      return { ...followUp, client };
    });

  // Get overdue follow-ups
  const overdueFollowUps = (followUps || [])
    .filter(f => {
      if (!f || !f.date || !f.status) return false;
      const today = new Date();
      const followUpDate = new Date(f.date);
      return f.status === 'pending' && followUpDate < today;
    })
    .map(followUp => {
      const client = (customers || []).find(c => c && c.id === followUp.customerId);
      return { ...followUp, client };
    });

  const getCommitmentColor = (level: string) => {
    const num = parseInt(level || '0');
    if (num >= 8) return 'text-green-600 bg-green-100';
    if (num >= 6) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getStressColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getActivityColor = (level: string) => {
    switch (level) {
      case 'active': return 'text-green-600 bg-green-100';
      case 'moderate': return 'text-blue-600 bg-blue-100';
      case 'sedentary': return 'text-orange-600 bg-orange-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getCommunicationIcon = (preference: string) => {
    switch (preference) {
      case 'whatsapp': return <MessageCircle className="w-4 h-4" />;
      case 'call': return <Phone className="w-4 h-4" />;
      case 'video-call': return <Video className="w-4 h-4" />;
      case 'email': return <Mail className="w-4 h-4" />;
      default: return <MessageCircle className="w-4 h-4" />;
    }
  };

  const getFollowUpTypeIcon = (type: string) => {
    switch (type) {
      case 'call': return '📞';
      case 'email': return '📧';
      case 'meeting': return '🧘‍♀️';
      case 'task': return '📋';
      default: return '💬';
    }
  };

  return (
    <div className="space-y-6">
      {/* Wellness Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card className="wellness-card wellness-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">🧘‍♀️ Total Wellness Clients</p>
                <p className="text-3xl wellness-text-primary">{wellnessMetrics.totalClients}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="wellness-card wellness-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">🟢 Active Clients</p>
                <p className="text-3xl wellness-text-secondary">{wellnessMetrics.activeClients}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-secondary)] to-[var(--wellness-accent)] rounded-xl flex items-center justify-center">
                <Activity className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="wellness-card wellness-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">💪 High Commitment</p>
                <p className="text-3xl text-purple-600">{wellnessMetrics.highCommitmentClients}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-purple-500 rounded-xl flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="wellness-card wellness-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">⏳ Pending Follow-ups</p>
                <p className="text-3xl text-amber-600">{wellnessMetrics.pendingFollowUps}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-500 rounded-xl flex items-center justify-center">
                <Clock className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="wellness-card wellness-hover">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">✅ Completed This Week</p>
                <p className="text-3xl wellness-text-accent">{wellnessMetrics.completedThisWeek}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-accent)] to-emerald-500 rounded-xl flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="upcoming">
        <TabsList className="wellness-bg-light">
          <TabsTrigger value="upcoming" className="wellness-focus">🌿 Upcoming Follow-ups</TabsTrigger>
          <TabsTrigger value="overdue" className="wellness-focus">⚠️ Overdue Actions</TabsTrigger>
          <TabsTrigger value="clients" className="wellness-focus">👥 Client Wellness Profiles</TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming" className="space-y-4">
          <Card className="wellness-card">
            <CardHeader>
              <CardTitle className="wellness-text-primary flex items-center gap-2">
                <div className="w-6 h-6 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-lg flex items-center justify-center">
                  <span className="text-white text-sm">📅</span>
                </div>
                Upcoming Wellness Follow-ups
              </CardTitle>
              <CardDescription>
                Scheduled wellness interactions with client context and goals
              </CardDescription>
            </CardHeader>
            <CardContent>
              {upcomingFollowUps.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Calendar className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>No upcoming follow-ups scheduled</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {upcomingFollowUps.map(followUp => (
                    <div key={followUp.id} className="border rounded-lg p-4 hover:bg-gray-50">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{getFollowUpTypeIcon(followUp.type)}</span>
                          <div>
                            <h4 className="flex items-center gap-2">
                              {followUp.subject}
                              <Badge variant="outline" className="text-xs">
                                {followUp.client?.name}
                              </Badge>
                            </h4>
                            <p className="text-sm text-gray-600">
                              {followUp.date} • {followUp.type}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={
                            followUp.priority === 'high' ? 'bg-red-100 text-red-800' :
                            followUp.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-gray-100 text-gray-800'
                          }>
                            {followUp.priority} priority
                          </Badge>
                        </div>
                      </div>

                      {followUp.client && (
                        <div className="bg-green-50 rounded-lg p-3 mb-3">
                          <h5 className="text-sm flex items-center gap-2 mb-2">
                            🧘‍♀️ <strong>Client Wellness Context</strong>
                          </h5>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                            {followUp.client.commitmentLevel && (
                              <div className="flex items-center gap-1">
                                <Target className="w-3 h-3" />
                                <span>Commitment: </span>
                                <Badge className={`${getCommitmentColor(followUp.client.commitmentLevel)} text-xs px-1 py-0`}>
                                  {followUp.client.commitmentLevel}/10
                                </Badge>
                              </div>
                            )}
                            {followUp.client.stressLevel && (
                              <div className="flex items-center gap-1">
                                <Brain className="w-3 h-3" />
                                <span>Stress: </span>
                                <Badge className={`${getStressColor(followUp.client.stressLevel)} text-xs px-1 py-0`}>
                                  {followUp.client.stressLevel}
                                </Badge>
                              </div>
                            )}
                            {followUp.client.activityLevel && (
                              <div className="flex items-center gap-1">
                                <Activity className="w-3 h-3" />
                                <span>Activity: </span>
                                <Badge className={`${getActivityColor(followUp.client.activityLevel)} text-xs px-1 py-0`}>
                                  {followUp.client.activityLevel}
                                </Badge>
                              </div>
                            )}
                            {followUp.client.communicationPreference && (
                              <div className="flex items-center gap-1">
                                {getCommunicationIcon(followUp.client.communicationPreference)}
                                <span>Prefers: </span>
                                <Badge variant="outline" className="text-xs px-1 py-0">
                                  {followUp.client.communicationPreference}
                                </Badge>
                              </div>
                            )}
                          </div>
                          
                          {(followUp.client.goals || followUp.client.challenges) && (
                            <div className="mt-2 pt-2 border-t border-green-200">
                              {followUp.client.goals && (
                                <p className="text-xs text-green-700 mb-1">
                                  <strong>Goals:</strong> {followUp.client.goals.substring(0, 120)}...
                                </p>
                              )}
                              {followUp.client.challenges && (
                                <p className="text-xs text-orange-700">
                                  <strong>Challenges:</strong> {followUp.client.challenges.substring(0, 120)}...
                                </p>
                              )}
                            </div>
                          )}
                        </div>
                      )}

                      <p className="text-gray-700 mb-3">{followUp.description}</p>

                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => onUpdateFollowUp(followUp.id, { status: 'completed' })}
                          className="wellness-button"
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Complete
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onUpdateFollowUp(followUp.id, { status: 'overdue' })}
                          className="wellness-button-secondary"
                        >
                          <AlertTriangle className="w-4 h-4 mr-1" />
                          Mark Overdue
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="overdue" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-red-600">⚠️ Overdue Wellness Actions</CardTitle>
              <CardDescription>
                Follow-ups that need immediate attention with client priorities
              </CardDescription>
            </CardHeader>
            <CardContent>
              {overdueFollowUps.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <CheckCircle className="w-12 h-12 mx-auto mb-4 text-green-300" />
                  <p>Great! No overdue follow-ups</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {overdueFollowUps.slice(0, 10).map(followUp => (
                    <div key={followUp.id} className="border border-red-200 rounded-lg p-4 bg-red-50">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <AlertTriangle className="w-5 h-5 text-red-500" />
                          <div>
                            <h4 className="flex items-center gap-2 text-red-800">
                              {followUp.subject}
                              <Badge variant="destructive" className="text-xs">
                                {followUp.client?.name}
                              </Badge>
                            </h4>
                            <p className="text-sm text-red-600">
                              Due: {followUp.date} • {followUp.type}
                            </p>
                          </div>
                        </div>
                      </div>

                      {followUp.client && (
                        <div className="bg-white rounded-lg p-3 mb-3 border border-red-200">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="text-sm text-red-700">
                              <strong>🚨 Client Priority Info</strong>
                            </h5>
                            {followUp.client.commitmentLevel && parseInt(followUp.client.commitmentLevel) >= 8 && (
                              <Badge className="bg-purple-100 text-purple-800 text-xs">
                                High Commitment Client
                              </Badge>
                            )}
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                            {followUp.client.medicalConditions && (
                              <p className="text-red-700">
                                <strong>Medical:</strong> {followUp.client.medicalConditions.substring(0, 50)}...
                              </p>
                            )}
                            {followUp.client.supportNeeded && (
                              <p className="text-orange-700">
                                <strong>Support Needed:</strong> {followUp.client.supportNeeded.substring(0, 50)}...
                              </p>
                            )}
                          </div>
                        </div>
                      )}

                      <p className="text-red-700 mb-3">{followUp.description}</p>

                      <Button
                        size="sm"
                        className="bg-red-600 hover:bg-red-700 text-white"
                        onClick={() => onUpdateFollowUp(followUp.id, { status: 'completed' })}
                      >
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Complete Now
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="clients" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>👥 Wellness Client Profiles Overview</CardTitle>
              <CardDescription>
                Quick view of client wellness metrics and engagement levels
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {(customers || [])
                  .filter(c => c && c.templateType === 'wellness')
                  .slice(0, 12)
                  .map(client => (
                    <div key={client.id} className="border rounded-lg p-4 bg-gradient-to-br from-green-50 to-blue-50">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                          <span className="text-green-600">{client.name?.charAt(0) || '?'}</span>
                        </div>
                        <div>
                          <h4>{client.name}</h4>
                          <Badge variant={client.status === 'active' ? 'default' : 'secondary'} className="text-xs">
                            {client.status}
                          </Badge>
                        </div>
                      </div>

                      <div className="space-y-2 text-xs">
                        {client.commitmentLevel && (
                          <div className="flex items-center justify-between">
                            <span>Commitment Level</span>
                            <div className="flex items-center gap-1">
                              <Progress 
                                value={parseInt(client.commitmentLevel) * 10} 
                                className="w-16 h-2" 
                              />
                              <span className="text-xs">{client.commitmentLevel}/10</span>
                            </div>
                          </div>
                        )}

                        <div className="grid grid-cols-2 gap-2">
                          {client.stressLevel && (
                            <Badge className={`${getStressColor(client.stressLevel)} text-xs p-1`}>
                              Stress: {client.stressLevel}
                            </Badge>
                          )}
                          {client.activityLevel && (
                            <Badge className={`${getActivityColor(client.activityLevel)} text-xs p-1`}>
                              {client.activityLevel}
                            </Badge>
                          )}
                        </div>

                        <div className="pt-2 border-t">
                          <div className="flex items-center justify-between">
                            <span>Follow-ups</span>
                            <div className="flex gap-1">
                              <Badge variant="outline" className="text-xs px-1">
                                {(client.followUps || []).filter(f => f && f.status === 'pending').length || 0} pending
                              </Badge>
                              <Badge variant="outline" className="text-xs px-1">
                                {(client.followUps || []).filter(f => f && f.status === 'completed').length || 0} done
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}