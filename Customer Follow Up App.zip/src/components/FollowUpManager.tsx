import { useState, useMemo } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Separator } from './ui/separator';
import { 
  ArrowLeft, 
  Calendar, 
  CheckCircle, 
  Clock, 
  AlertTriangle,
  Search,
  User,
  Phone,
  Mail,
  Filter,
  TrendingUp,
  ListChecks
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  city?: string;
  templateType?: string;
  followUpStatus?: string;
  nextFollowUpDate?: string;
}

interface FollowUp {
  id: string;
  customerId: string;
  type: 'call' | 'email' | 'meeting' | 'task';
  subject: string;
  description: string;
  date: string;
  status: 'pending' | 'completed' | 'overdue';
  priority: 'low' | 'medium' | 'high';
  actualStatus?: 'pending' | 'completed' | 'overdue';
  customer?: Customer;
  isLeadItem?: boolean;
}

interface FollowUpManagerProps {
  customers: Customer[];
  followUps: FollowUp[];
  onBack: () => void;
  onUpdateFollowUp: (followUpId: string, updates: Partial<FollowUp>) => void;
  onViewCustomer: (customer: Customer) => void;
  initialFilter?: 'all' | 'pending' | 'overdue' | 'completed';
}

export function FollowUpManager({ 
  customers, 
  followUps, 
  onBack, 
  onUpdateFollowUp,
  onViewCustomer,
  initialFilter = 'all'
}: FollowUpManagerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>(initialFilter);
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  // Calculate actual status based on date
  const getActualStatus = (followUp: FollowUp): 'pending' | 'completed' | 'overdue' => {
    if (followUp.status === 'completed') {
      return 'completed';
    }
    
    if (!followUp.date) {
      return 'pending';
    }
    
    const followUpDate = new Date(followUp.date);
    const today = new Date();
    
    // Validate that we have a valid date
    if (isNaN(followUpDate.getTime())) {
      console.warn('Invalid follow-up date:', followUp.date);
      return 'pending';
    }
    
    // Reset time to start of day for accurate comparison
    today.setHours(0, 0, 0, 0);
    followUpDate.setHours(0, 0, 0, 0);
    
    // If date is in the past (before today), it's overdue
    if (followUpDate.getTime() < today.getTime()) {
      return 'overdue';
    }
    
    // If date is today or in the future, it's pending
    return 'pending';
  };

  // Helper function to determine lead status based on nextFollowUpDate
  const getLeadStatus = (customer: Customer): 'pending' | 'overdue' | null => {
    if (!customer.nextFollowUpDate) return null;
    if (customer.followUpStatus === 'enrolled' || customer.followUpStatus === 'not-interested') {
      return null;
    }
    
    const followUpDate = new Date(customer.nextFollowUpDate);
    const today = new Date();
    
    // Validate that we have a valid date
    if (isNaN(followUpDate.getTime())) {
      console.warn('Invalid next follow-up date for customer:', customer.name, customer.nextFollowUpDate);
      return null;
    }
    
    // Reset time to start of day for accurate comparison
    today.setHours(0, 0, 0, 0);
    followUpDate.setHours(0, 0, 0, 0);
    
    // If date is in the past (before today), it's overdue
    if (followUpDate.getTime() < today.getTime()) {
      return 'overdue';
    }
    
    // If date is today or in the future, it's pending
    return 'pending';
  };

  // Enhance follow-ups with customer data and actual status
  const enhancedFollowUps = useMemo(() => {
    // Regular follow-ups
    const regularFollowUps = followUps.map(followUp => {
      const customer = customers.find(c => c.id === followUp.customerId);
      const actualStatus = getActualStatus(followUp);
      
      return {
        ...followUp,
        actualStatus,
        customer,
        isLeadItem: false
      };
    });
    
    // Add lead items (customers with nextFollowUpDate)
    const leadItems = customers
      .filter(customer => {
        const status = getLeadStatus(customer);
        return status !== null; // Only include leads with pending/overdue dates
      })
      .map(customer => {
        const status = getLeadStatus(customer);
        return {
          id: `lead-${customer.id}`,
          customerId: customer.id,
          type: 'call' as const,
          subject: `Follow up with ${customer.name}`,
          description: customer.nextActionPlan || 'Schedule next follow-up call',
          date: customer.nextFollowUpDate!,
          status: status!,
          actualStatus: status!,
          priority: 'medium' as const,
          customer,
          isLeadItem: true
        };
      });
    
    return [...regularFollowUps, ...leadItems];
  }, [followUps, customers]);

  // Filter follow-ups
  const filteredFollowUps = useMemo(() => {
    return enhancedFollowUps.filter(followUp => {
      // Search filter
      const matchesSearch = 
        followUp.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
        followUp.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        followUp.customer?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        followUp.customer?.phone.includes(searchTerm);
      
      // Status filter
      const matchesStatus = statusFilter === 'all' || followUp.actualStatus === statusFilter;
      
      // Priority filter
      const matchesPriority = priorityFilter === 'all' || followUp.priority === priorityFilter;
      
      // Type filter
      const matchesType = typeFilter === 'all' || followUp.type === typeFilter;
      
      return matchesSearch && matchesStatus && matchesPriority && matchesType;
    }).sort((a, b) => {
      // Sort by date (oldest first for pending/overdue, newest first for completed)
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      
      if (statusFilter === 'completed') {
        return dateB - dateA; // Newest first for completed
      }
      return dateA - dateB; // Oldest first for pending/overdue
    });
  }, [enhancedFollowUps, searchTerm, statusFilter, priorityFilter, typeFilter]);

  // Calculate statistics
  const stats = useMemo(() => {
    const pending = enhancedFollowUps.filter(f => f.actualStatus === 'pending').length;
    const overdue = enhancedFollowUps.filter(f => f.actualStatus === 'overdue').length;
    const completed = enhancedFollowUps.filter(f => f.actualStatus === 'completed').length;
    const total = enhancedFollowUps.length;
    
    return { pending, overdue, completed, total };
  }, [enhancedFollowUps]);

  const handleMarkAsCompleted = async (followUpId: string) => {
    try {
      await onUpdateFollowUp(followUpId, { status: 'completed' });
      toast.success('Follow-up marked as completed', {
        description: 'Status updated successfully'
      });
    } catch (error) {
      console.error('Error updating follow-up:', error);
      toast.error('Failed to update follow-up');
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'overdue':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default:
        return <Clock className="w-4 h-4 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'overdue':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'call':
        return '📞';
      case 'email':
        return '📧';
      case 'meeting':
        return '🤝';
      default:
        return '📋';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const followUpDate = new Date(dateString);
    followUpDate.setHours(0, 0, 0, 0);
    
    const diffTime = followUpDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    if (diffDays === -1) return 'Yesterday';
    if (diffDays < -1) return `${Math.abs(diffDays)} days ago`;
    if (diffDays > 1) return `In ${diffDays} days`;
    
    return date.toLocaleDateString();
  };

  return (
    <div className="min-h-screen wellness-gradient p-4">
      {/* Header */}
      <div className="mb-8">
        <Card className="wellness-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button variant="outline" onClick={onBack} className="wellness-button-secondary">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-full flex items-center justify-center text-white shadow-md">
                    <ListChecks className="w-6 h-6" />
                  </div>
                  <div>
                    <h1 className="text-2xl wellness-text-primary">Follow-Up Manager</h1>
                    <p className="text-[var(--wellness-text-muted)]">Track and manage all follow-ups</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card 
          className={`wellness-card wellness-hover cursor-pointer ${statusFilter === 'all' ? 'ring-2 ring-[var(--wellness-primary)]' : ''}`}
          onClick={() => setStatusFilter('all')}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">📊 Total Follow-ups</p>
                <p className="text-3xl wellness-text-primary">{stats.total}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-500 rounded-xl flex items-center justify-center">
                <ListChecks className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card 
          className={`wellness-card wellness-hover cursor-pointer ${statusFilter === 'pending' ? 'ring-2 ring-amber-500' : ''}`}
          onClick={() => setStatusFilter('pending')}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">⏳ Pending</p>
                <p className="text-3xl text-amber-600">{stats.pending}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-500 rounded-xl flex items-center justify-center">
                <Clock className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card 
          className={`wellness-card wellness-hover cursor-pointer ${statusFilter === 'overdue' ? 'ring-2 ring-red-500' : ''}`}
          onClick={() => setStatusFilter('overdue')}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">🚨 Overdue</p>
                <p className="text-3xl text-red-500">{stats.overdue}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-red-400 to-red-500 rounded-xl flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card 
          className={`wellness-card wellness-hover cursor-pointer ${statusFilter === 'completed' ? 'ring-2 ring-green-500' : ''}`}
          onClick={() => setStatusFilter('completed')}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">✅ Completed</p>
                <p className="text-3xl wellness-text-secondary">{stats.completed}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-secondary)] to-[var(--wellness-accent)] rounded-xl flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="wellness-card mb-8">
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 wellness-text-primary" />
              <Input
                placeholder="🔍 Search follow-ups or leads..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 wellness-focus border-[var(--wellness-primary)] border-opacity-30"
              />
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                <SelectTrigger className="w-full sm:w-40 wellness-focus">
                  <Filter className="w-4 h-4 mr-2 wellness-text-primary" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="wellness-card">
                  <SelectItem value="all">All Priority</SelectItem>
                  <SelectItem value="high">🔴 High</SelectItem>
                  <SelectItem value="medium">🟡 Medium</SelectItem>
                  <SelectItem value="low">🟢 Low</SelectItem>
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-full sm:w-40 wellness-focus">
                  <Filter className="w-4 h-4 mr-2 wellness-text-primary" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="wellness-card">
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="call">📞 Call</SelectItem>
                  <SelectItem value="email">📧 Email</SelectItem>
                  <SelectItem value="meeting">🤝 Meeting</SelectItem>
                  <SelectItem value="task">📋 Task</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Follow-ups List */}
      <Card className="wellness-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="wellness-text-primary">
                {statusFilter === 'all' ? '📊 All Follow-ups' :
                 statusFilter === 'pending' ? '⏳ Pending Follow-ups' :
                 statusFilter === 'overdue' ? '🚨 Overdue Follow-ups' :
                 '✅ Completed Follow-ups'}
              </CardTitle>
              <CardDescription>
                {filteredFollowUps.length} {filteredFollowUps.length === 1 ? 'follow-up' : 'follow-ups'} found
              </CardDescription>
            </div>
            {(statusFilter !== 'all' || searchTerm || priorityFilter !== 'all' || typeFilter !== 'all') && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setStatusFilter('all');
                  setSearchTerm('');
                  setPriorityFilter('all');
                  setTypeFilter('all');
                }}
                className="wellness-button-secondary"
              >
                Clear Filters
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {filteredFollowUps.length === 0 ? (
            <div className="text-center py-12 space-y-4">
              <div className="w-16 h-16 mx-auto bg-[var(--wellness-bg-light)] rounded-full flex items-center justify-center">
                <span className="text-2xl">📋</span>
              </div>
              <div className="space-y-2">
                <p className="text-[var(--wellness-text-muted)]">No follow-ups found</p>
                <p className="text-sm text-[var(--wellness-text-muted)]">
                  {statusFilter !== 'all' || searchTerm || priorityFilter !== 'all' || typeFilter !== 'all'
                    ? 'Try adjusting your filters'
                    : 'Add follow-ups to your leads to track them here'}
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredFollowUps.map((followUp) => (
                <div
                  key={followUp.id}
                  className="p-5 border border-[var(--wellness-primary)] border-opacity-20 rounded-xl wellness-gradient-card"
                >
                  <div className="flex items-start justify-between gap-4">
                    {/* Follow-up Info */}
                    <div className="flex-1 space-y-3">
                      <div className="flex items-start gap-3">
                        <div className="text-2xl">{getTypeIcon(followUp.type)}</div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <h3 className="wellness-text-primary">{followUp.subject}</h3>
                            {followUp.isLeadItem && (
                              <Badge className="bg-purple-100 text-purple-800">
                                📋 Lead Follow-up
                              </Badge>
                            )}
                            <Badge className={getStatusColor(followUp.actualStatus)}>
                              {getStatusIcon(followUp.actualStatus)}
                              <span className="ml-1">
                                {followUp.actualStatus.charAt(0).toUpperCase() + followUp.actualStatus.slice(1)}
                              </span>
                            </Badge>
                            <Badge className={getPriorityColor(followUp.priority)}>
                              {followUp.priority.charAt(0).toUpperCase() + followUp.priority.slice(1)}
                            </Badge>
                          </div>
                          {followUp.description && (
                            <p className="text-sm text-[var(--wellness-text-muted)] mb-2">
                              {followUp.description}
                            </p>
                          )}
                          
                          {/* Customer Info */}
                          {followUp.customer && (
                            <div className="flex items-center gap-4 mt-2 p-3 bg-[var(--wellness-bg-light)] rounded-lg">
                              <div 
                                className="flex items-center gap-2 cursor-pointer hover:underline"
                                onClick={() => onViewCustomer(followUp.customer!)}
                              >
                                <div className="w-8 h-8 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-full flex items-center justify-center text-white text-sm">
                                  {followUp.customer.name.charAt(0)}
                                </div>
                                <div>
                                  <p className="text-sm wellness-text-primary">{followUp.customer.name}</p>
                                  <p className="text-xs text-[var(--wellness-text-muted)]">
                                    {followUp.customer.phone} {followUp.customer.city && `• ${followUp.customer.city}`}
                                  </p>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Date and Actions */}
                    <div className="flex flex-col items-end gap-3">
                      <div className="text-right">
                        <div className="flex items-center gap-2 text-sm text-[var(--wellness-text-muted)]">
                          <Calendar className="w-4 h-4" />
                          <span>{new Date(followUp.date).toLocaleDateString()}</span>
                        </div>
                        <p className={`text-xs ${
                          followUp.actualStatus === 'overdue' ? 'text-red-600' :
                          followUp.actualStatus === 'pending' ? 'text-amber-600' :
                          'text-green-600'
                        }`}>
                          {formatDate(followUp.date)}
                        </p>
                      </div>
                      
                      {followUp.actualStatus !== 'completed' && !followUp.isLeadItem && (
                        <Button
                          size="sm"
                          onClick={() => handleMarkAsCompleted(followUp.id)}
                          className="wellness-button text-sm"
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Mark Complete
                        </Button>
                      )}
                      
                      {followUp.isLeadItem && followUp.customer && (
                        <Button
                          size="sm"
                          onClick={() => onViewCustomer(followUp.customer!)}
                          className="wellness-button text-sm"
                        >
                          <User className="w-4 h-4 mr-1" />
                          Update Lead
                        </Button>
                      )}
                      
                      {!followUp.isLeadItem && followUp.customer && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onViewCustomer(followUp.customer!)}
                          className="wellness-button-secondary text-sm"
                        >
                          <User className="w-4 h-4 mr-1" />
                          View Lead
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
