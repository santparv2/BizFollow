import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { CustomerDetail } from './CustomerDetail';
import { ClientReport } from './ClientReport';
import { AddCustomer } from './AddCustomer';
import { BusinessAnalytics } from './BusinessAnalytics';
import { FollowUpManager } from './FollowUpManager';
import { BackendStatusIndicator } from './BackendStatusIndicator';
import { supabase } from '../utils/supabase';
import { apiClient } from '../utils/api';
import { toast } from 'sonner@2.0.3';
import { 
  Users, 
  Calendar, 
  AlertCircle, 
  CheckCircle, 
  Search, 
  LogOut,
  Filter,
  UserPlus,
  ArrowLeft,
  BarChart3,
  FileText
} from 'lucide-react';

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  status: 'active' | 'inactive' | 'prospect';
  lastContact: string;
  followUps: FollowUp[];
  templateType?: string;
  // Wellness-specific fields
  age?: string;
  gender?: string;
  city?: string;
  weight?: string;
  height?: string;
  medicalConditions?: string;
  medications?: string;
  allergies?: string;
  activityLevel?: string;
  sleepPattern?: string;
  stressLevel?: string;
  goals?: string;
  challenges?: string;
  previousCoaching?: string;
  commitmentLevel?: string;
  supportNeeded?: string;
  communicationPreference?: string;
  additionalInfo?: string;
  // Lead-specific fields
  leadSource?: string;
  interestArea?: string;
  currentConcern?: string;
  followUpDate?: string;
  nextFollowUpDate?: string;
  followUpStatus?: string;
  coachAssignedTo?: string;
  nextActionPlan?: string;
  remarks?: string;
}

interface FollowUp {
  id: string;
  customerId: string;
  type: 'call' | 'email' | 'meeting' | 'task';
  subject: string;
  description: string;
  date: string;
  status: 'pending' | 'completed' | 'overdue';
  priority: 'low' | 'medium' | 'high';
}

interface DashboardProps {
  currentUserId: string;
  accessToken: string;
  onLogout: () => void;
}

export function Dashboard({ currentUserId, accessToken, onLogout }: DashboardProps) {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [allFollowUps, setAllFollowUps] = useState<FollowUp[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [showBusinessAnalytics, setShowBusinessAnalytics] = useState(false);
  const [showClientReport, setShowClientReport] = useState(false);
  const [showFollowUpManager, setShowFollowUpManager] = useState(false);
  const [followUpManagerFilter, setFollowUpManagerFilter] = useState<'all' | 'pending' | 'overdue' | 'completed'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [leadCategoryFilter, setLeadCategoryFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  // Debug current state
  console.log('Dashboard render state:', {
    showAddCustomer,
    showBusinessAnalytics, 
    showClientReport,
    showFollowUpManager,
    selectedCustomer: selectedCustomer?.name
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      apiClient.setAccessToken(accessToken);
      
      // Skip data loading if offline
      if (typeof navigator !== 'undefined' && !navigator.onLine) {
        console.log('ℹ️ Device is offline - using demo mode');
        setCustomers([]);
        setAllFollowUps([]);
        setLoading(false);
        return;
      }
      
      console.log('Starting data load - checking server health...');
      
      // First check if server is healthy
      try {
        await apiClient.healthCheck();
        console.log('✅ Server health check passed');
      } catch (healthError: any) {
        // Check if it's a network error
        if (healthError.name === 'OfflineError' ||
            healthError.message === 'OFFLINE' || 
            healthError.name === 'NetworkError' || 
            healthError.message?.includes('Network unavailable')) {
          setCustomers([]);
          setAllFollowUps([]);
          setLoading(false);
          return;
        }
        // Continue anyway for other errors, might be a CORS issue
        console.log('⚠️ Server health check failed, continuing anyway');
      }
      
      console.log('Loading customers and follow-ups...');
      const [customersResponse, followUpsResponse] = await Promise.all([
        apiClient.getCustomers(),
        apiClient.getAllFollowUps()
      ]);

      console.log('Raw customers response:', customersResponse);
      console.log('Raw follow-ups response:', followUpsResponse);

      const customersData = customersResponse?.customers || [];
      const followUpsData = followUpsResponse?.followUps || [];

      console.log('Processed customers data:', customersData);
      console.log('Processed follow-ups data:', followUpsData);

      // Ensure follow-ups have proper structure and valid dates
      const validFollowUps = followUpsData
        .filter((followUp: any) => followUp && followUp.id && followUp.customerId)
        .map((followUp: any) => ({
          id: followUp.id,
          customerId: followUp.customerId,
          type: followUp.type || 'task',
          subject: followUp.subject || 'Follow-up',
          description: followUp.description || '',
          date: followUp.date || new Date().toISOString().split('T')[0],
          status: followUp.status || 'pending',
          priority: followUp.priority || 'medium',
          outcomes: followUp.outcomes || {},
          createdAt: followUp.createdAt,
          updatedAt: followUp.updatedAt
        }));

      console.log('Validated follow-ups:', validFollowUps);

      // Group follow-ups by customer and ensure data integrity
      const customersWithFollowUps = customersData
        .filter((customer: any) => customer && customer.id && customer.id.trim() !== '')
        .map((customer: any, index: number) => {
          const customerFollowUps = validFollowUps.filter((followUp: any) => 
            followUp.customerId === customer.id
          );
          
          console.log(`Customer ${customer.id} has ${customerFollowUps.length} follow-ups`);
          
          return {
            id: customer.id.trim(),
            name: customer?.name || `Customer ${index + 1}`,
            email: customer?.email || '',
            phone: customer?.phone || '',
            company: customer?.company || undefined,
            status: customer?.status || 'inactive',
            lastContact: customer?.lastContact || '',
            templateType: customer?.templateType || undefined,
            // Preserve all wellness fields
            age: customer?.age,
            gender: customer?.gender,
            city: customer?.city,
            weight: customer?.weight,
            height: customer?.height,
            medicalConditions: customer?.medicalConditions,
            medications: customer?.medications,
            allergies: customer?.allergies,
            activityLevel: customer?.activityLevel,
            sleepPattern: customer?.sleepPattern,
            stressLevel: customer?.stressLevel,
            goals: customer?.goals,
            challenges: customer?.challenges,
            previousCoaching: customer?.previousCoaching,
            commitmentLevel: customer?.commitmentLevel,
            supportNeeded: customer?.supportNeeded,
            communicationPreference: customer?.communicationPreference,
            additionalInfo: customer?.additionalInfo,
            // Preserve all lead-specific fields
            leadSource: customer?.leadSource,
            interestArea: customer?.interestArea,
            currentConcern: customer?.currentConcern,
            followUpDate: customer?.followUpDate,
            nextFollowUpDate: customer?.nextFollowUpDate,
            followUpStatus: customer?.followUpStatus,
            coachAssignedTo: customer?.coachAssignedTo,
            nextActionPlan: customer?.nextActionPlan,
            remarks: customer?.remarks,
            followUps: customerFollowUps
          };
        });

      // Remove any potential duplicates based on ID
      const uniqueCustomers = customersWithFollowUps.filter((customer, index, self) => 
        index === self.findIndex(c => c.id === customer.id)
      );
      
      console.log('Final processed customers:', uniqueCustomers);
      console.log('Total follow-ups loaded:', validFollowUps.length);
      
      setCustomers(uniqueCustomers);
      setAllFollowUps(validFollowUps);
    } catch (error: any) {
      // Check if it's a network error - handle silently
      const isNetworkError = error.name === 'OfflineError' ||
                            error.name === 'NetworkError' || 
                            error.message === 'OFFLINE' ||
                            error.message?.includes('Network unavailable') ||
                            error.message?.includes('Failed to fetch') ||
                            error.name === 'TypeError';
      
      if (!isNetworkError) {
        console.error('❌ Error loading data:', error);
      }
      
      // Set empty arrays as fallback
      setCustomers([]);
      setAllFollowUps([]);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut().catch(() => {
        // Silently ignore network errors during logout
        console.log('ℹ️ Logout - clearing local session');
      });
    } catch (error) {
      // Ignore all logout errors
      console.log('ℹ️ Logout completed with local cleanup');
    }
    onLogout();
  };

  // Helper function to get effective status based on followUpStatus for leads
  const getEffectiveStatus = (customer: Customer): 'active' | 'prospect' | 'inactive' => {
    // For leads, use followUpStatus to determine status
    if (customer.templateType === 'lead' && customer.followUpStatus) {
      switch (customer.followUpStatus) {
        case 'enrolled':
          return 'active';
        case 'not-interested':
          return 'inactive';
        case 'new-lead':
        case 'contacted':
        case 'interested':
        case 'follow-up-pending':
        default:
          return 'prospect';
      }
    }
    // For other types, use the status field
    return customer.status || 'prospect';
  };

  // Helper function to get status display label
  const getStatusLabel = (customer: Customer): string => {
    if (customer.templateType === 'lead' && customer.followUpStatus) {
      switch (customer.followUpStatus) {
        case 'new-lead':
          return '🆕 New Lead';
        case 'contacted':
          return '📞 Contacted';
        case 'interested':
          return '⭐ Interested';
        case 'not-interested':
          return '❌ Not Interested';
        case 'enrolled':
          return '✅ Enrolled';
        case 'follow-up-pending':
          return '⏳ Follow-Up Pending';
        default:
          return '🟡 Prospect';
      }
    }
    // For other types, use standard status
    const status = getEffectiveStatus(customer);
    return status === 'active' ? '🟢 Active' : 
           status === 'prospect' ? '🟡 Prospect' : '⚪ Inactive';
  };

  // Helper function to get status color class
  const getStatusColorClass = (customer: Customer): string => {
    if (customer.templateType === 'lead' && customer.followUpStatus) {
      switch (customer.followUpStatus) {
        case 'enrolled':
          return 'bg-[var(--wellness-primary)] text-white';
        case 'interested':
          return 'bg-green-100 text-green-800';
        case 'contacted':
          return 'bg-blue-100 text-blue-800';
        case 'new-lead':
          return 'bg-purple-100 text-purple-800';
        case 'follow-up-pending':
          return 'bg-amber-100 text-amber-800';
        case 'not-interested':
          return 'bg-gray-100 text-gray-600';
        default:
          return 'bg-amber-100 text-amber-800';
      }
    }
    // For other types, use standard colors
    const status = getEffectiveStatus(customer);
    return status === 'active' 
      ? 'bg-[var(--wellness-primary)] text-white' 
      : status === 'prospect' 
      ? 'bg-amber-100 text-amber-800' 
      : 'bg-gray-100 text-gray-600';
  };

  // Helper function to determine follow-up status based on date
  const getFollowUpStatus = (followUp: FollowUp): 'pending' | 'overdue' | 'completed' => {
    // If explicitly marked as completed, return completed
    if (followUp.status === 'completed') {
      return 'completed';
    }
    
    // If no date, default to pending
    if (!followUp.date) {
      return 'pending';
    }
    
    // Compare the follow-up date with today
    const followUpDate = new Date(followUp.date);
    const today = new Date();
    
    // Validate that we have a valid date
    if (isNaN(followUpDate.getTime())) {
      console.warn('Invalid follow-up date:', followUp.date);
      return 'pending';
    }
    
    // Reset time to start of day for accurate comparison
    today.setHours(0, 0, 0, 0);
    followUpDate.setHours(0, 0, 0, 0);
    
    // If date is in the past (before today), it's overdue
    if (followUpDate.getTime() < today.getTime()) {
      return 'overdue';
    }
    
    // If date is today or in the future, it's pending
    return 'pending';
  };

  // Helper function to determine lead follow-up status based on nextFollowUpDate
  // This checks if a lead has an updated nextFollowUpDate and categorizes it as:
  // - 'pending': nextFollowUpDate is today or in the future (upcoming)
  // - 'overdue': nextFollowUpDate is in the past
  // - 'none': no nextFollowUpDate set, or lead is enrolled/not-interested
  const getLeadFollowUpStatus = (customer: Customer): 'pending' | 'overdue' | 'none' => {
    // Skip if not a lead or no follow-up date set
    if (customer.templateType !== 'lead' || !customer.nextFollowUpDate) {
      return 'none';
    }
    
    // If already enrolled or not interested, skip (these don't need follow-ups)
    if (customer.followUpStatus === 'enrolled' || customer.followUpStatus === 'not-interested') {
      return 'none';
    }
    
    const followUpDate = new Date(customer.nextFollowUpDate);
    const today = new Date();
    
    // Validate that we have a valid date
    if (isNaN(followUpDate.getTime())) {
      console.warn('Invalid next follow-up date for customer:', customer.name, customer.nextFollowUpDate);
      return 'none';
    }
    
    // Reset time to start of day for accurate comparison
    today.setHours(0, 0, 0, 0);
    followUpDate.setHours(0, 0, 0, 0);
    
    // If date is in the past (before today), it's overdue
    if (followUpDate.getTime() < today.getTime()) {
      return 'overdue';
    }
    
    // If date is today or in the future, it's pending (upcoming)
    return 'pending';
  };

  // Calculate statistics based on automatic date detection
  
  // COMPLETED TASKS: Count actual follow-up task records that are marked as completed
  const followUpTasksCompleted = (allFollowUps || []).filter(f => getFollowUpStatus(f) === 'completed').length;
  
  // UPCOMING FOLLOW-UPS: Count leads that have nextFollowUpDate updated/set (and date is today or future)
  // These are leads where the user has set a "Next Follow-Up Date" field
  const leadsPending = customers.filter(c => getLeadFollowUpStatus(c) === 'pending').length;
  
  // OVERDUE FOLLOW-UPS: Count leads with nextFollowUpDate in the past
  const leadsOverdue = customers.filter(c => getLeadFollowUpStatus(c) === 'overdue').length;
  
  // Dashboard Statistics
  const pendingFollowUps = leadsPending; // Upcoming: Leads with nextFollowUpDate set (future/today)
  const overdueFollowUps = leadsOverdue; // Overdue: Leads with nextFollowUpDate in past
  const completedFollowUps = followUpTasksCompleted; // Completed: Follow-up task records marked done
  
  // Total Leads = Upcoming + Overdue + Completed
  const totalLeads = pendingFollowUps + overdueFollowUps + completedFollowUps;
  
  // Debug logging for follow-up categorization
  console.log('Dashboard Stats:', {
    totalCustomersInDB: customers.length,
    leadsWithPendingFollowUpDate: leadsPending,
    leadsWithOverdueFollowUpDate: leadsOverdue,
    completedFollowUpTasks: followUpTasksCompleted,
    totalFollowUpTasks: allFollowUps.length,
    calculatedStats: {
      pending: pendingFollowUps,
      overdue: overdueFollowUps,
      completed: completedFollowUps,
      total: totalLeads,
      formula: `${pendingFollowUps} + ${overdueFollowUps} + ${completedFollowUps} = ${totalLeads}`
    }
  });
  
  // Lead category statistics
  const newLeadsCount = customers.filter(c => c.followUpStatus === 'new-lead').length;
  const interestedLeadsCount = customers.filter(c => c.followUpStatus === 'interested').length;
  const enrolledLeadsCount = customers.filter(c => c.followUpStatus === 'enrolled').length;

  // Filter and sort customers (newest first)
  const filteredCustomers = customers
    .filter(customer => {
      // Ensure we have valid customer data before filtering
      // Leads may not have email, so only require name
      if (!customer || !customer.name) {
        return false;
      }
      
      const matchesSearch = customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           (customer.company && customer.company.toLowerCase().includes(searchTerm.toLowerCase())) ||
                           (customer.email && customer.email.toLowerCase().includes(searchTerm.toLowerCase())) ||
                           (customer.phone && customer.phone.includes(searchTerm)) ||
                           (customer.city && customer.city.toLowerCase().includes(searchTerm.toLowerCase()));
      
      // Use effective status for filtering
      const effectiveStatus = getEffectiveStatus(customer);
      const matchesStatus = statusFilter === 'all' || effectiveStatus === statusFilter;
      
      // Filter by lead category (followUpStatus)
      const matchesLeadCategory = leadCategoryFilter === 'all' || 
                                  customer.followUpStatus === leadCategoryFilter;
      
      return matchesSearch && matchesStatus && matchesLeadCategory;
    })
    .sort((a, b) => {
      // Sort by lastContact date (newest first)
      const dateA = new Date(a.lastContact || '2000-01-01');
      const dateB = new Date(b.lastContact || '2000-01-01');
      return dateB.getTime() - dateA.getTime();
    });

  const handleAddCustomer = async (customerData: any) => {
    try {
      console.log('Adding customer with data:', customerData);
      const response = await apiClient.addCustomer(customerData);
      console.log('Customer added successfully:', response);
      await loadData(); // Refresh data
      setShowAddCustomer(false);
    } catch (error) {
      console.error('Error adding customer:', error);
      // Show a more user-friendly error message
      alert(`Failed to add customer: ${error.message || 'Unknown error'}`);
    }
  };

  const handleAddFollowUp = async (followUpData: Omit<FollowUp, 'id'>) => {
    try {
      console.log('Adding follow-up with data:', followUpData);
      
      // Validate required fields
      if (!followUpData.customerId || !followUpData.type || !followUpData.subject) {
        throw new Error('Missing required follow-up fields');
      }
      
      const response = await apiClient.addFollowUp(followUpData);
      console.log('Follow-up added successfully:', response);
      
      // Force reload data to ensure consistency
      await loadData();
      
      console.log('Data reloaded after adding follow-up');
    } catch (error) {
      console.error('Error adding follow-up:', error);
      // Show a more user-friendly error message
      alert(`Failed to add follow-up: ${error.message || 'Unknown error'}`);
    }
  };

  const handleUpdateFollowUp = async (followUpId: string, updates: Partial<FollowUp>) => {
    try {
      console.log('Updating follow-up:', followUpId, 'with updates:', updates);
      
      // Find the follow-up to get the customer ID
      const followUp = allFollowUps.find(f => f.id === followUpId);
      if (!followUp) {
        console.error('Follow-up not found in allFollowUps array:', followUpId);
        throw new Error('Follow-up not found');
      }
      
      console.log('Found follow-up to update:', followUp);
      
      const response = await apiClient.updateFollowUp(followUp.customerId, followUpId, updates);
      console.log('Follow-up updated successfully:', response);
      
      // Force reload data to ensure consistency
      await loadData();
      
      console.log('Data reloaded after updating follow-up');
    } catch (error) {
      console.error('Error updating follow-up:', error);
      alert(`Failed to update follow-up: ${error.message || 'Unknown error'}`);
    }
  };

  const handleUpdateCustomer = async (customerId: string, updates: Partial<Customer>) => {
    try {
      console.log('Updating customer:', customerId, 'with updates:', updates);
      
      const response = await apiClient.updateCustomer(customerId, updates);
      console.log('Customer updated successfully:', response);
      
      // Update selectedCustomer if it's the one being updated
      if (selectedCustomer && selectedCustomer.id === customerId) {
        setSelectedCustomer({ ...selectedCustomer, ...updates });
      }
      
      // Force reload data to ensure consistency
      await loadData();
      
      console.log('Data reloaded after updating customer');
    } catch (error) {
      // Check if customer was deleted (404 error)
      if (error.message?.includes('not found') || error.message?.includes('deleted') || error.message?.includes('404')) {
        console.log('Customer no longer exists, clearing from view and refreshing data');
        
        toast.info('Lead no longer exists', {
          description: 'Refreshing data...'
        });
        
        // Clear selected customer
        if (selectedCustomer && selectedCustomer.id === customerId) {
          setSelectedCustomer(null);
        }
        
        // Reload data to sync
        await loadData();
      } else {
        console.error('Error updating customer:', error);
        toast.error('Failed to update lead', {
          description: error.message || 'An error occurred'
        });
      }
    }
  };

  const handleDeleteCustomer = async (customerId: string) => {
    // Find customer name for toast message
    const customer = customers.find(c => c.id === customerId);
    const customerName = customer?.name || 'Lead';
    
    try {
      console.log('Deleting customer:', customerId);
      
      // Try to delete via API first
      try {
        const response = await apiClient.deleteCustomer(customerId);
        console.log('Customer deleted via API:', response);
        
        // Clear selected customer if it's the one being deleted
        if (selectedCustomer && selectedCustomer.id === customerId) {
          setSelectedCustomer(null);
        }
        
        // Show success message
        if (response?.wasAlreadyDeleted) {
          toast.success(`${customerName} removed`, {
            description: 'Lead data synchronized'
          });
        } else {
          toast.success(`${customerName} deleted successfully`, {
            description: 'Lead and all associated data removed'
          });
        }
        
        // Reload data
        await loadData();
        console.log('Data reloaded after deleting customer');
        
      } catch (apiError) {
        // If server is unreachable, try direct Supabase delete as fallback
        if (apiError.message === 'SERVER_UNREACHABLE') {
          console.log('API server unreachable, attempting direct database delete...');
          
          // Delete follow-ups first
          const { error: followUpsError } = await supabase
            .from('followups')
            .delete()
            .eq('customerId', customerId);
          
          if (followUpsError) {
            console.error('Error deleting follow-ups:', followUpsError);
          }
          
          // Delete customer
          const { error: customerError } = await supabase
            .from('customers')
            .delete()
            .eq('id', customerId);
          
          if (customerError) {
            console.error('Error deleting customer from database:', customerError);
            throw new Error('Failed to delete from database');
          }
          
          // Clear selected customer
          if (selectedCustomer && selectedCustomer.id === customerId) {
            setSelectedCustomer(null);
          }
          
          toast.success(`${customerName} deleted successfully`, {
            description: 'Deleted directly from database (API server offline)'
          });
          
          // Reload data
          await loadData();
          console.log('Data reloaded after direct database delete');
        } else {
          throw apiError;
        }
      }
    } catch (error) {
      console.error('Error deleting customer:', error);
      
      // Clear selected customer if it's the one being deleted
      if (selectedCustomer && selectedCustomer.id === customerId) {
        setSelectedCustomer(null);
      }
      
      toast.error('Failed to delete lead', {
        description: error.message || 'Please try again or contact support'
      });
      
      // Reload data anyway to ensure UI is in sync
      await loadData();
    }
  };

  // Handler functions for navigation
  const handleShowAddCustomer = () => {
    console.log('Add Customer button clicked - setting showAddCustomer to true');
    setShowAddCustomer(true);
  };

  const handleShowBusinessAnalytics = () => {
    console.log('Business Analytics button clicked - setting showBusinessAnalytics to true');
    setShowBusinessAnalytics(true);
  };

  const handleShowClientReport = () => {
    console.log('Client Reports button clicked - setting showClientReport to true');
    setShowClientReport(true);
  };

  const handleShowFollowUpManager = (filter: 'all' | 'pending' | 'overdue' | 'completed' = 'all') => {
    console.log('Follow-up Manager clicked with filter:', filter);
    setFollowUpManagerFilter(filter);
    setShowFollowUpManager(true);
  };

  // Early returns for different views
  if (selectedCustomer) {
    return (
      <CustomerDetail
        customer={selectedCustomer}
        onBack={() => setSelectedCustomer(null)}
        onAddFollowUp={handleAddFollowUp}
        onUpdateFollowUp={handleUpdateFollowUp}
        onUpdateCustomer={handleUpdateCustomer}
        onDeleteCustomer={handleDeleteCustomer}
      />
    );
  }

  if (showAddCustomer) {
    return (
      <AddCustomer
        onAdd={handleAddCustomer}
        onCancel={() => setShowAddCustomer(false)}
      />
    );
  }

  if (showBusinessAnalytics) {
    return (
      <div className="min-h-screen wellness-gradient p-4">
        {/* Header */}
        <div className="mb-6 flex items-center gap-4">
          <Button variant="outline" onClick={() => setShowBusinessAnalytics(false)} className="wellness-button-secondary">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        <BusinessAnalytics 
          customers={customers} 
          followUps={allFollowUps} 
          onUpdateFollowUp={handleUpdateFollowUp}
        />
      </div>
    );
  }

  if (showClientReport) {
    return (
      <ClientReport
        customers={customers}
        onBack={() => setShowClientReport(false)}
      />
    );
  }

  if (showFollowUpManager) {
    return (
      <FollowUpManager
        customers={customers}
        followUps={allFollowUps}
        onBack={() => setShowFollowUpManager(false)}
        onUpdateFollowUp={handleUpdateFollowUp}
        onViewCustomer={setSelectedCustomer}
        initialFilter={followUpManagerFilter}
      />
    );
  }

  return (
    <div className="min-h-screen wellness-gradient p-4">
      {/* Header */}
      <div className="mb-8">
        <div className="wellness-card p-6">
          <div className="flex justify-between items-center">
            <div className="space-y-1">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-full flex items-center justify-center text-white text-xl">
                  📋
                </div>
                <div>
                  <div className="flex items-center gap-3">
                    <h1 className="text-2xl wellness-text-primary">BizFollow Dashboard</h1>
                    <BackendStatusIndicator />
                  </div>
                  <p className="text-[var(--wellness-text-muted)]">Welcome back, <span className="wellness-text-primary">{currentUserId}</span> 💼</p>
                </div>
              </div>
            </div>
            <Button variant="outline" onClick={handleLogout} className="wellness-button-secondary">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="wellness-card wellness-hover cursor-pointer">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">🎯 Total Leads</p>
                <p className="text-3xl wellness-text-primary">{totalLeads}</p>
                <p className="text-xs text-[var(--wellness-text-muted)] mt-1">
                  {pendingFollowUps > 0 && `${pendingFollowUps} upcoming`}
                  {pendingFollowUps > 0 && (overdueFollowUps > 0 || completedFollowUps > 0) && ' • '}
                  {overdueFollowUps > 0 && `${overdueFollowUps} overdue`}
                  {overdueFollowUps > 0 && completedFollowUps > 0 && ' • '}
                  {completedFollowUps > 0 && `${completedFollowUps} done`}
                  {totalLeads === 0 && 'No leads yet'}
                </p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="wellness-card wellness-hover cursor-pointer">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">⏳ Upcoming Follow-ups</p>
                <p className="text-3xl text-amber-600">{pendingFollowUps}</p>
                <p className="text-xs text-[var(--wellness-text-muted)] mt-1">Leads with scheduled dates</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-500 rounded-xl flex items-center justify-center">
                <Calendar className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="wellness-card wellness-hover cursor-pointer" onClick={() => handleShowFollowUpManager('overdue')}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">🔴 Overdue Follow-ups</p>
                <p className="text-3xl text-red-600">{overdueFollowUps}</p>
                <p className="text-xs text-[var(--wellness-text-muted)] mt-1">Leads past follow-up date</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-red-400 to-red-500 rounded-xl flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="wellness-card wellness-hover cursor-pointer" onClick={() => handleShowFollowUpManager('completed')}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">✅ Completed Tasks</p>
                <p className="text-3xl text-green-600">{completedFollowUps}</p>
                <p className="text-xs text-[var(--wellness-text-muted)] mt-1">Finished follow-up tasks</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-secondary)] to-[var(--wellness-accent)] rounded-xl flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Hint for clickable cards */}
      <div className="mb-4 text-center">
        <p className="text-sm text-[var(--wellness-text-muted)]">
          💡 <span className="wellness-text-primary">Tip:</span> Click on the follow-up cards above to view and manage them
        </p>
      </div>

      {/* Search and Filters */}
      <Card className="wellness-card mb-8">
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row gap-4 items-stretch lg:items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 wellness-text-primary" />
              <Input
                placeholder="🔍 Search leads..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 wellness-focus border-[var(--wellness-primary)] border-opacity-30"
              />
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <Select value={leadCategoryFilter} onValueChange={setLeadCategoryFilter}>
                <SelectTrigger className="w-full sm:w-56 wellness-focus">
                  <Filter className="w-4 h-4 mr-2 wellness-text-primary" />
                  <SelectValue placeholder="Lead Category" />
                </SelectTrigger>
                <SelectContent className="wellness-card">
                  <SelectItem value="all">✨ All Categories</SelectItem>
                  <SelectItem value="new-lead">🆕 New Lead</SelectItem>
                  <SelectItem value="contacted">📞 Contacted</SelectItem>
                  <SelectItem value="interested">⭐ Interested</SelectItem>
                  <SelectItem value="not-interested">❌ Not Interested</SelectItem>
                  <SelectItem value="enrolled">✅ Enrolled</SelectItem>
                  <SelectItem value="follow-up-pending">⏳ Follow-Up Pending</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-48 wellness-focus">
                  <Filter className="w-4 h-4 mr-2 wellness-text-primary" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="wellness-card">
                  <SelectItem value="all">✨ All Status</SelectItem>
                  <SelectItem value="active">✅ Active/Enrolled</SelectItem>
                  <SelectItem value="prospect">🟡 Prospect/Leads</SelectItem>
                  <SelectItem value="inactive">⚪ Inactive/Not Interested</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex flex-col sm:flex-row gap-3">
                <Button 
                  onClick={handleShowAddCustomer}
                  className="wellness-button-secondary whitespace-nowrap"
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  🎯 Add Lead
                </Button>
                <Button 
                  onClick={handleShowBusinessAnalytics}
                  className="wellness-button whitespace-nowrap"
                >
                  <BarChart3 className="w-4 h-4 mr-2" />
                  📊 Lead Analytics
                </Button>
                <Button 
                  onClick={handleShowClientReport}
                  className="wellness-button-secondary whitespace-nowrap"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  📄 Lead Reports
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lead List */}
      <Card className="wellness-card">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-lg flex items-center justify-center">
              <span className="text-white text-lg">🎯</span>
            </div>
            <div className="flex-1">
              <CardTitle className="wellness-text-primary">Lead Tracking</CardTitle>
              <CardDescription>
                {filteredCustomers.length} {filteredCustomers.length === 1 ? 'lead' : 'leads'} found • Sorted by most recent
              </CardDescription>
            </div>
            {(leadCategoryFilter !== 'all' || statusFilter !== 'all' || searchTerm) && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setLeadCategoryFilter('all');
                  setStatusFilter('all');
                  setSearchTerm('');
                }}
                className="wellness-button-secondary"
              >
                Clear Filters
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-12">
              <div className="w-12 h-12 mx-auto mb-4">
                <div className="w-12 h-12 border-4 border-[var(--wellness-primary)] border-t-transparent rounded-full animate-spin"></div>
              </div>
              <p className="text-[var(--wellness-text-muted)]">Loading your leads...</p>
            </div>
          ) : filteredCustomers.length === 0 ? (
            <div className="text-center py-12 space-y-4">
              <div className="w-16 h-16 mx-auto bg-[var(--wellness-bg-light)] rounded-full flex items-center justify-center">
                <span className="text-2xl">🎯</span>
              </div>
              <div className="space-y-2">
                <p className="text-[var(--wellness-text-muted)]">
                  {(leadCategoryFilter !== 'all' || statusFilter !== 'all' || searchTerm) 
                    ? 'No leads match your filters' 
                    : 'No leads found'}
                </p>
                <p className="text-sm text-[var(--wellness-text-muted)]">
                  {(leadCategoryFilter !== 'all' || statusFilter !== 'all' || searchTerm)
                    ? 'Try adjusting your filters or search terms'
                    : 'Start your lead tracking journey by adding your first lead'}
                </p>
              </div>
              {(leadCategoryFilter !== 'all' || statusFilter !== 'all' || searchTerm) ? (
                <Button 
                  onClick={() => {
                    setLeadCategoryFilter('all');
                    setStatusFilter('all');
                    setSearchTerm('');
                  }} 
                  className="wellness-button-secondary"
                >
                  Clear All Filters
                </Button>
              ) : (
                <Button onClick={handleShowAddCustomer} className="wellness-button">
                  <UserPlus className="w-4 h-4 mr-2" />
                  🎯 Add Your First Lead
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {filteredCustomers.map(customer => (
              <div
                key={customer.id}
                className="flex items-center justify-between p-5 border border-[var(--wellness-primary)] border-opacity-20 rounded-xl wellness-hover cursor-pointer wellness-gradient-card"
                onClick={() => setSelectedCustomer(customer)}
              >
                <div className="flex-1">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-full flex items-center justify-center text-white shadow-md">
                      <span className="text-lg">{customer.name?.charAt(0) || '?'}</span>
                    </div>
                    <div>
                      <h3 className="wellness-text-primary">{customer.name || 'Unknown'}</h3>
                      <p className="text-sm text-[var(--wellness-text-muted)] flex items-center gap-1">
                        {customer.city ? `📍 ${customer.city}` : '🎯 Lead'}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-6">
                  {customer.nextFollowUpDate && (
                    <div className="text-right">
                      <p className="text-xs text-[var(--wellness-text-muted)] mb-1">📆 Next Follow-Up</p>
                      <p className="text-sm text-green-700">{customer.nextFollowUpDate}</p>
                    </div>
                  )}
                  <div className="text-right">
                    <p className="text-xs text-[var(--wellness-text-muted)] mb-1">📅 Last Contact</p>
                    <p className="text-sm wellness-text-primary">{customer.lastContact || 'Never'}</p>
                  </div>
                  
                  <Badge className={getStatusColorClass(customer)}>
                    {getStatusLabel(customer)}
                  </Badge>
                  
                  <div className="text-right">
                    <p className="text-xs text-[var(--wellness-text-muted)] mb-1">📋 Follow-ups</p>
                    <div className="flex gap-1">
                      {(customer.followUps || []).filter(f => f?.status === 'pending').length > 0 && (
                        <Badge className="text-xs bg-amber-100 text-amber-800">
                          {(customer.followUps || []).filter(f => f?.status === 'pending').length} pending
                        </Badge>
                      )}
                      {(customer.followUps || []).filter(f => f?.status === 'overdue').length > 0 && (
                        <Badge variant="destructive" className="text-xs">
                          {(customer.followUps || []).filter(f => f?.status === 'overdue').length} overdue
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}