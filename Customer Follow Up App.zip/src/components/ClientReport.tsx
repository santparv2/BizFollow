import { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  FileText, 
  Download, 
  Printer, 
  ArrowLeft, 
  User, 
  Mail, 
  Phone, 
  Building2,
  Calendar,
  CheckCircle,
  AlertCircle,
  Clock,
  TrendingUp,
  Target,
  Activity,
  BarChart3,
  FileDown
} from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  status: 'active' | 'inactive' | 'prospect';
  lastContact: string;
  followUps: FollowUp[];
  templateType?: string;
  // Business/Wellness fields
  age?: string;
  gender?: string;
  city?: string;
  weight?: string;
  height?: string;
  medicalConditions?: string;
  medications?: string;
  allergies?: string;
  activityLevel?: string;
  sleepPattern?: string;
  stressLevel?: string;
  goals?: string;
  challenges?: string;
  previousCoaching?: string;
  commitmentLevel?: string;
  supportNeeded?: string;
  communicationPreference?: string;
  additionalInfo?: string;
}

interface FollowUp {
  id: string;
  customerId: string;
  type: 'call' | 'email' | 'meeting' | 'task';
  subject: string;
  description: string;
  date: string;
  status: 'pending' | 'completed' | 'overdue';
  priority: 'low' | 'medium' | 'high';
}

interface ClientReportProps {
  customers: Customer[];
  onBack: () => void;
}

export function ClientReport({ customers, onBack }: ClientReportProps) {
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('all');
  const [reportType, setReportType] = useState<'summary' | 'detailed' | 'analytics'>('summary');
  const [isExportingPDF, setIsExportingPDF] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  const selectedCustomer = customers.find(c => c.id === selectedCustomerId);
  const isAllCustomers = selectedCustomerId === 'all';

  // Calculate overall statistics
  const calculateStats = (customersToAnalyze: Customer[]) => {
    const allFollowUps = customersToAnalyze.flatMap(c => c.followUps || []);
    const totalFollowUps = allFollowUps.length;
    const completed = allFollowUps.filter(f => f.status === 'completed').length;
    const pending = allFollowUps.filter(f => f.status === 'pending').length;
    const overdue = allFollowUps.filter(f => f.status === 'overdue').length;
    const completionRate = totalFollowUps > 0 ? (completed / totalFollowUps * 100).toFixed(1) : '0';
    
    const activeCustomers = customersToAnalyze.filter(c => c.status === 'active').length;
    const prospectCustomers = customersToAnalyze.filter(c => c.status === 'prospect').length;
    const inactiveCustomers = customersToAnalyze.filter(c => c.status === 'inactive').length;

    return {
      totalCustomers: customersToAnalyze.length,
      totalFollowUps,
      completed,
      pending,
      overdue,
      completionRate,
      activeCustomers,
      prospectCustomers,
      inactiveCustomers
    };
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    const reportData = isAllCustomers ? customers : [selectedCustomer!];
    const stats = calculateStats(reportData);
    
    let csvContent = "Client Report\n\n";
    csvContent += `Generated on: ${new Date().toLocaleDateString()}\n`;
    csvContent += `Report Type: ${reportType}\n`;
    csvContent += `Scope: ${isAllCustomers ? 'All Clients' : selectedCustomer?.name}\n\n`;
    
    csvContent += "SUMMARY STATISTICS\n";
    csvContent += `Total Clients: ${stats.totalCustomers}\n`;
    csvContent += `Active Clients: ${stats.activeCustomers}\n`;
    csvContent += `Prospect Clients: ${stats.prospectCustomers}\n`;
    csvContent += `Inactive Clients: ${stats.inactiveCustomers}\n`;
    csvContent += `Total Follow-ups: ${stats.totalFollowUps}\n`;
    csvContent += `Completed: ${stats.completed}\n`;
    csvContent += `Pending: ${stats.pending}\n`;
    csvContent += `Overdue: ${stats.overdue}\n`;
    csvContent += `Completion Rate: ${stats.completionRate}%\n\n`;

    if (reportType === 'detailed') {
      csvContent += "DETAILED CLIENT INFORMATION\n";
      reportData.forEach(customer => {
        csvContent += `\nClient: ${customer.name}\n`;
        csvContent += `Email: ${customer.email}\n`;
        csvContent += `Phone: ${customer.phone}\n`;
        csvContent += `Company: ${customer.company || 'N/A'}\n`;
        csvContent += `Status: ${customer.status}\n`;
        csvContent += `Last Contact: ${customer.lastContact}\n`;
        
        if (customer.goals) csvContent += `Goals: ${customer.goals}\n`;
        if (customer.challenges) csvContent += `Challenges: ${customer.challenges}\n`;
        if (customer.commitmentLevel) csvContent += `Commitment Level: ${customer.commitmentLevel}\n`;
        
        csvContent += `Follow-ups:\n`;
        (customer.followUps || []).forEach(followUp => {
          csvContent += `  - ${followUp.subject} (${followUp.type}) - ${followUp.status} - ${followUp.date}\n`;
        });
      });
    }

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bizfollow-report-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const generateTextBasedPDF = async () => {
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pageWidth = 210;
    const pageHeight = 297;
    const margin = 20;
    const contentWidth = pageWidth - (margin * 2);
    let currentY = margin;
    
    const addText = (text: string, x: number, y: number, options?: any) => {
      if (y > pageHeight - margin) {
        pdf.addPage();
        currentY = margin;
        y = currentY;
      }
      pdf.text(text, x, y, options);
      return y;
    };
    
    const addLine = (height: number = 5) => {
      currentY += height;
      if (currentY > pageHeight - margin) {
        pdf.addPage();
        currentY = margin;
      }
    };
    
    // Header
    pdf.setFontSize(20);
    pdf.setFont('helvetica', 'bold');
    currentY = addText('📋 BizFollow Client Report', margin, currentY);
    addLine(10);
    
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'normal');
    currentY = addText(`Generated: ${new Date().toLocaleDateString()}`, margin, currentY);
    currentY = addText(`Scope: ${isAllCustomers ? 'All Clients' : selectedCustomer?.name}`, margin, currentY + 5);
    addLine(15);
    
    // Statistics
    pdf.setFontSize(16);
    pdf.setFont('helvetica', 'bold');
    currentY = addText('Summary Statistics', margin, currentY);
    addLine(8);
    
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'normal');
    currentY = addText(`Total Clients: ${stats.totalCustomers}`, margin, currentY);
    currentY = addText(`Active: ${stats.activeCustomers} | Prospects: ${stats.prospectCustomers} | Inactive: ${stats.inactiveCustomers}`, margin, currentY + 5);
    currentY = addText(`Total Follow-ups: ${stats.totalFollowUps}`, margin, currentY + 5);
    currentY = addText(`Completed: ${stats.completed} | Pending: ${stats.pending} | Overdue: ${stats.overdue}`, margin, currentY + 5);
    currentY = addText(`Completion Rate: ${stats.completionRate}%`, margin, currentY + 5);
    addLine(15);
    
    // Client Details (if detailed report)
    if (reportType === 'detailed' && reportData.length > 0) {
      pdf.setFontSize(16);
      pdf.setFont('helvetica', 'bold');
      currentY = addText('Client Details', margin, currentY);
      addLine(8);
      
      reportData.forEach((customer, index) => {
        if (currentY > pageHeight - 60) {
          pdf.addPage();
          currentY = margin;
        }
        
        pdf.setFontSize(14);
        pdf.setFont('helvetica', 'bold');
        currentY = addText(`${index + 1}. ${customer.name}`, margin, currentY);
        addLine(5);
        
        pdf.setFontSize(10);
        pdf.setFont('helvetica', 'normal');
        currentY = addText(`Email: ${customer.email}`, margin + 5, currentY);
        currentY = addText(`Phone: ${customer.phone}`, margin + 5, currentY + 4);
        if (customer.company) currentY = addText(`Company: ${customer.company}`, margin + 5, currentY + 4);
        currentY = addText(`Status: ${customer.status}`, margin + 5, currentY + 4);
        currentY = addText(`Follow-ups: ${(customer.followUps || []).length}`, margin + 5, currentY + 4);
        addLine(10);
      });
    }
    
    // Generate filename and save
    const clientName = isAllCustomers ? 'all-clients' : selectedCustomer?.name.toLowerCase().replace(/\s+/g, '-') || 'report';
    const filename = `bizfollow-report-${clientName}-${new Date().toISOString().split('T')[0]}.pdf`;
    pdf.save(filename);
  };

  const handleExportPDF = async () => {
    if (!reportRef.current) return;
    
    try {
      setIsExportingPDF(true);
      
      // Create a clone of the report content for PDF generation
      const reportClone = reportRef.current.cloneNode(true) as HTMLElement;
      
      // Create a temporary container with PDF-optimized styles
      const tempContainer = document.createElement('div');
      tempContainer.className = 'pdf-export-container';
      tempContainer.style.position = 'absolute';
      tempContainer.style.left = '-9999px';
      tempContainer.style.top = '0';
      tempContainer.style.width = '794px'; // A4 width in pixels
      tempContainer.style.minHeight = '1123px'; // A4 height in pixels
      tempContainer.style.backgroundColor = '#ffffff';
      tempContainer.style.color = '#0f2927';
      tempContainer.style.padding = '40px';
      tempContainer.style.fontFamily = 'Arial, sans-serif';
      tempContainer.style.fontSize = '14px';
      tempContainer.style.lineHeight = '1.5';
      tempContainer.style.borderRadius = '0';
      tempContainer.style.boxShadow = 'none';
      
      // Hide interactive elements
      const elementsToHide = reportClone.querySelectorAll('.print\\:hidden, [class*="print:hidden"]');
      elementsToHide.forEach(el => {
        (el as HTMLElement).style.display = 'none';
      });
      
      // Show print-only elements
      const elementsToShow = reportClone.querySelectorAll('.print\\:block, [class*="print:block"]');
      elementsToShow.forEach(el => {
        (el as HTMLElement).style.display = 'block';
      });
      
      // Remove gradients and complex backgrounds, replace CSS variables with hex values
      const allElements = reportClone.querySelectorAll('*');
      allElements.forEach(el => {
        const element = el as HTMLElement;
        
        // Replace CSS variables with fixed hex values for PDF compatibility
        element.style.background = 'white';
        element.style.backgroundColor = 'white';
        element.style.boxShadow = 'none';
        element.style.border = element.classList.contains('wellness-card') ? '1px solid #e5e7eb' : 'none';
        
        // Replace wellness colors with hex values
        if (element.style.color?.includes('var(')) {
          element.style.color = '#0f2927'; // Default text color
        }
        
        // Handle wellness-specific classes
        if (element.classList.contains('wellness-text-primary')) {
          element.style.color = '#16a085';
        }
        if (element.classList.contains('wellness-text-secondary')) {
          element.style.color = '#2dd4bf';
        }
        if (element.classList.contains('text-[var(--wellness-text-muted)]')) {
          element.style.color = '#475569';
        }
        
        // Handle background gradients
        if (element.classList.contains('bg-gradient-to-br')) {
          if (element.classList.contains('from-green-400')) {
            element.style.background = '#4ade80';
          } else if (element.classList.contains('from-amber-400')) {
            element.style.background = '#fbbf24';
          } else if (element.classList.contains('from-red-400')) {
            element.style.background = '#f87171';
          } else if (element.classList.contains('from-blue-400')) {
            element.style.background = '#60a5fa';
          } else if (element.classList.contains('from-purple-400')) {
            element.style.background = '#a78bfa';
          } else {
            element.style.background = '#16a085'; // Default wellness primary
          }
        }
      });
      
      tempContainer.appendChild(reportClone);
      document.body.appendChild(tempContainer);
      
      // Wait a moment for styles to apply
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // Convert SVG elements to images for better PDF compatibility
      const svgElements = tempContainer.querySelectorAll('svg');
      for (const svg of svgElements) {
        try {
          const svgElement = svg as SVGElement;
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          if (ctx) {
            const svgData = new XMLSerializer().serializeToString(svgElement);
            const img = new Image();
            const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
            const url = URL.createObjectURL(svgBlob);
            
            await new Promise((resolve) => {
              img.onload = () => {
                canvas.width = svgElement.clientWidth || 300;
                canvas.height = svgElement.clientHeight || 200;
                ctx.drawImage(img, 0, 0);
                URL.revokeObjectURL(url);
                resolve(null);
              };
              img.onerror = () => resolve(null);
              img.src = url;
            });
            
            // Replace SVG with canvas
            if (svgElement.parentNode) {
              svgElement.parentNode.replaceChild(canvas, svgElement);
            }
          }
        } catch (error) {
          console.warn('Failed to convert SVG to canvas:', error);
        }
      }
      
      // Generate canvas from the styled clone
      const canvas = await html2canvas(tempContainer, {
        scale: 1.5,
        useCORS: true,
        allowTaint: true,
        logging: false,
        backgroundColor: '#ffffff',
        ignoreElements: (element) => {
          return element.tagName === 'BUTTON' || 
                 element.classList.contains('print:hidden') ||
                 element.style.display === 'none';
        }
      });
      
      // Remove temporary container
      document.body.removeChild(tempContainer);
      
      // Create PDF
      const imgData = canvas.toDataURL('image/png', 0.95);
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = 210; // A4 width in mm
      const pdfHeight = 297; // A4 height in mm
      const imgWidth = pdfWidth - 20; // Leave 10mm margins
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      let heightLeft = imgHeight;
      let position = 10; // 10mm top margin
      
      // Add first page
      pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight);
      heightLeft -= (pdfHeight - 20); // Account for margins
      
      // Add additional pages if needed
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight + 10; // 10mm top margin
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight);
        heightLeft -= (pdfHeight - 20);
      }
      
      // Generate filename
      const clientName = isAllCustomers ? 'all-clients' : selectedCustomer?.name.toLowerCase().replace(/\s+/g, '-') || 'report';
      const filename = `bizfollow-report-${clientName}-${new Date().toISOString().split('T')[0]}.pdf`;
      
      // Download PDF
      pdf.save(filename);
      
    } catch (error) {
      console.error('Error generating PDF:', error);
      
      // Fallback to text-based PDF if html2canvas fails
      try {
        console.log('Attempting fallback text-based PDF generation...');
        await generateTextBasedPDF();
      } catch (fallbackError) {
        console.error('Fallback PDF generation also failed:', fallbackError);
        alert('Failed to generate PDF. Please try the CSV export instead or contact support.');
      }
    } finally {
      setIsExportingPDF(false);
    }
  };

  const reportData = isAllCustomers ? customers : [selectedCustomer!];
  const stats = calculateStats(reportData);

  return (
    <div ref={reportRef} className="min-h-screen wellness-gradient p-4 print:p-0 print:bg-white">
      {/* Header - Hidden in print */}
      <div className="mb-8 print:hidden">
        <div className="wellness-card p-6">
          <div className="flex justify-between items-center">
            <div className="space-y-1">
              <div className="flex items-center gap-3">
                <Button variant="outline" onClick={onBack} className="wellness-button-secondary">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
                <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-full flex items-center justify-center text-white text-xl">
                  📊
                </div>
                <div>
                  <h1 className="text-2xl wellness-text-primary">Client Reports</h1>
                  <p className="text-[var(--wellness-text-muted)]">Generate comprehensive client progress reports</p>
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              <Button onClick={handlePrint} variant="outline" className="wellness-button-secondary">
                <Printer className="w-4 h-4 mr-2" />
                Print Report
              </Button>
              <Button 
                onClick={handleExportPDF} 
                disabled={isExportingPDF}
                className="wellness-button"
                title="Enhanced PDF export with fallback support"
              >
                {isExportingPDF ? (
                  <>
                    <div className="w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Generating PDF...
                  </>
                ) : (
                  <>
                    <FileDown className="w-4 h-4 mr-2" />
                    Export PDF ✨
                  </>
                )}
              </Button>
              <Button onClick={handleExportCSV} variant="outline" className="wellness-button-secondary">
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Report Controls - Hidden in print */}
      <Card className="wellness-card mb-8 print:hidden">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4 items-center">
            <div className="flex-1">
              <label className="text-sm wellness-text-primary mb-2 block">Select Client</label>
              <Select value={selectedCustomerId} onValueChange={setSelectedCustomerId}>
                <SelectTrigger className="wellness-focus">
                  <User className="w-4 h-4 mr-2 wellness-text-primary" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="wellness-card">
                  <SelectItem value="all">📊 All Clients</SelectItem>
                  {customers.map(customer => (
                    <SelectItem key={customer.id} value={customer.id}>
                      {customer.name} ({customer.company || 'Individual'})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1">
              <label className="text-sm wellness-text-primary mb-2 block">Report Type</label>
              <Select value={reportType} onValueChange={(value: 'summary' | 'detailed' | 'analytics') => setReportType(value)}>
                <SelectTrigger className="wellness-focus">
                  <FileText className="w-4 h-4 mr-2 wellness-text-primary" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="wellness-card">
                  <SelectItem value="summary">📋 Summary Report</SelectItem>
                  <SelectItem value="detailed">📄 Detailed Report</SelectItem>
                  <SelectItem value="analytics">📈 Analytics Report</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Report Header - Shown in print */}
      <div className="hidden print:block mb-8 text-center">
        <h1 className="text-3xl font-bold text-[var(--wellness-primary)] mb-2">📋 BizFollow Client Report</h1>
        <p className="text-[var(--wellness-text-muted)]">
          Generated on {new Date().toLocaleDateString()} • {isAllCustomers ? 'All Clients' : selectedCustomer?.name}
        </p>
      </div>

      {/* Statistics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="wellness-card wellness-hover print:shadow-none">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">Total Clients</p>
                <p className="text-3xl wellness-text-primary">{stats.totalCustomers}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-xl flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="wellness-card wellness-hover print:shadow-none">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">Follow-ups</p>
                <p className="text-3xl wellness-text-primary">{stats.totalFollowUps}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-500 rounded-xl flex items-center justify-center">
                <Activity className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="wellness-card wellness-hover print:shadow-none">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">Completion Rate</p>
                <p className="text-3xl wellness-text-secondary">{stats.completionRate}%</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-secondary)] to-[var(--wellness-accent)] rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="wellness-card wellness-hover print:shadow-none">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--wellness-text-muted)] mb-1">Active Clients</p>
                <p className="text-3xl text-green-600">{stats.activeCustomers}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-green-500 rounded-xl flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Follow-up Status Breakdown */}
      <Card className="wellness-card mb-8 print:shadow-none">
        <CardHeader>
          <CardTitle className="wellness-text-primary flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Follow-up Status Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-[var(--wellness-bg-light)] rounded-lg">
              <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-[var(--wellness-secondary)] to-[var(--wellness-accent)] rounded-full flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="wellness-text-primary text-xl mb-1">{stats.completed}</h3>
              <p className="text-[var(--wellness-text-muted)]">✅ Completed</p>
            </div>
            <div className="text-center p-4 bg-amber-50 rounded-lg">
              <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-amber-400 to-amber-500 rounded-full flex items-center justify-center">
                <Clock className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-amber-700 text-xl mb-1">{stats.pending}</h3>
              <p className="text-amber-600">⏳ Pending</p>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-red-400 to-red-500 rounded-full flex items-center justify-center">
                <AlertCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-red-700 text-xl mb-1">{stats.overdue}</h3>
              <p className="text-red-600">🚨 Overdue</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Client Status Distribution */}
      <Card className="wellness-card mb-8 print:shadow-none">
        <CardHeader>
          <CardTitle className="wellness-text-primary flex items-center gap-2">
            <Target className="w-5 h-5" />
            Client Status Distribution
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-green-400 to-green-500 rounded-full flex items-center justify-center text-white text-xl">
                🟢
              </div>
              <h3 className="text-green-700 text-xl mb-1">{stats.activeCustomers}</h3>
              <p className="text-green-600">Active Clients</p>
            </div>
            <div className="text-center p-4 bg-amber-50 rounded-lg">
              <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-amber-400 to-amber-500 rounded-full flex items-center justify-center text-white text-xl">
                🟡
              </div>
              <h3 className="text-amber-700 text-xl mb-1">{stats.prospectCustomers}</h3>
              <p className="text-amber-600">Prospects</p>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-gray-400 to-gray-500 rounded-full flex items-center justify-center text-white text-xl">
                ⚪
              </div>
              <h3 className="text-gray-700 text-xl mb-1">{stats.inactiveCustomers}</h3>
              <p className="text-gray-600">Inactive</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Client Information */}
      {(reportType === 'detailed' || reportType === 'analytics') && (
        <div className="space-y-6">
          {reportData.map(customer => (
            <Card key={customer.id} className="wellness-card print:shadow-none print:break-inside-avoid">
              <CardHeader>
                <CardTitle className="wellness-text-primary flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-full flex items-center justify-center text-white">
                    {customer.name.charAt(0)}
                  </div>
                  {customer.name}
                  <Badge className={
                    customer.status === 'active' ? 'bg-[var(--wellness-primary)] text-white' :
                    customer.status === 'prospect' ? 'bg-amber-100 text-amber-800' :
                    'bg-gray-100 text-gray-600'
                  }>
                    {customer.status === 'active' ? '🟢 Active' :
                     customer.status === 'prospect' ? '🟡 Prospect' : '⚪ Inactive'}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Contact Information */}
                <div>
                  <h4 className="wellness-text-primary mb-3 flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Contact Information
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 wellness-text-primary" />
                      <span>{customer.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 wellness-text-primary" />
                      <span>{customer.phone}</span>
                    </div>
                    {customer.company && (
                      <div className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 wellness-text-primary" />
                        <span>{customer.company}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 wellness-text-primary" />
                      <span>Last Contact: {customer.lastContact || 'Never'}</span>
                    </div>
                  </div>
                </div>

                {/* Business Goals & Challenges */}
                {(customer.goals || customer.challenges || customer.commitmentLevel) && (
                  <div>
                    <h4 className="wellness-text-primary mb-3 flex items-center gap-2">
                      <Target className="w-4 h-4" />
                      Business Profile
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      {customer.goals && (
                        <div>
                          <strong className="wellness-text-primary">Goals:</strong>
                          <p className="text-[var(--wellness-text-muted)] mt-1">{customer.goals}</p>
                        </div>
                      )}
                      {customer.challenges && (
                        <div>
                          <strong className="wellness-text-primary">Challenges:</strong>
                          <p className="text-[var(--wellness-text-muted)] mt-1">{customer.challenges}</p>
                        </div>
                      )}
                      {customer.commitmentLevel && (
                        <div>
                          <strong className="wellness-text-primary">Commitment Level:</strong>
                          <p className="text-[var(--wellness-text-muted)] mt-1">{customer.commitmentLevel}</p>
                        </div>
                      )}
                      {customer.supportNeeded && (
                        <div>
                          <strong className="wellness-text-primary">Support Needed:</strong>
                          <p className="text-[var(--wellness-text-muted)] mt-1">{customer.supportNeeded}</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Follow-up History */}
                <div>
                  <h4 className="wellness-text-primary mb-3 flex items-center gap-2">
                    <Activity className="w-4 h-4" />
                    Follow-up History ({(customer.followUps || []).length} total)
                  </h4>
                  {(customer.followUps || []).length === 0 ? (
                    <p className="text-[var(--wellness-text-muted)] text-sm">No follow-ups recorded yet</p>
                  ) : (
                    <div className="space-y-3">
                      {customer.followUps.slice(0, reportType === 'analytics' ? 3 : undefined).map(followUp => (
                        <div key={followUp.id} className="flex items-center justify-between p-3 bg-[var(--wellness-bg-light)] rounded-lg">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-1">
                              <Badge variant="outline" className="text-xs">
                                {followUp.type === 'call' ? '📞 Call' :
                                 followUp.type === 'email' ? '📧 Email' :
                                 followUp.type === 'meeting' ? '🤝 Meeting' : '📋 Task'}
                              </Badge>
                              <span className="text-sm wellness-text-primary">{followUp.subject}</span>
                            </div>
                            <p className="text-xs text-[var(--wellness-text-muted)]">{followUp.description}</p>
                          </div>
                          <div className="text-right text-xs text-[var(--wellness-text-muted)]">
                            <p>{followUp.date}</p>
                            <Badge className={
                              followUp.status === 'completed' ? 'bg-[var(--wellness-secondary)] text-white' :
                              followUp.status === 'pending' ? 'bg-amber-100 text-amber-800' :
                              'bg-red-100 text-red-800'
                            }>
                              {followUp.status === 'completed' ? '✅' :
                               followUp.status === 'pending' ? '⏳' : '🚨'} {followUp.status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                      {reportType === 'analytics' && customer.followUps.length > 3 && (
                        <p className="text-xs text-[var(--wellness-text-muted)] text-center">
                          ... and {customer.followUps.length - 3} more follow-ups
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Footer - Shown in print */}
      <div className="hidden print:block mt-12 pt-8 border-t border-[var(--wellness-primary)] border-opacity-20 text-center text-sm text-[var(--wellness-text-muted)]">
        <p>© 2024 BizFollow - Business Client Follow-up Management System</p>
        <p>Generated by BizFollow Dashboard • Confidential Business Report</p>
      </div>
    </div>
  );
}