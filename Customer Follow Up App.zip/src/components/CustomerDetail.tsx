import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { FollowUpOutcomes, FollowUpOutcomesSummary } from './FollowUpOutcomes';
import { EditCustomer } from './EditCustomer';
import { toast } from 'sonner@2.0.3';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "./ui/alert-dialog";
import { 
  ArrowLeft, 
  Phone, 
  Mail, 
  Building, 
  Calendar,
  Plus,
  CheckCircle,
  Clock,
  AlertTriangle,
  Settings,
  Target,
  Brain,
  Activity,
  X,
  Trash2,
  Edit
} from 'lucide-react';

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  status: 'active' | 'inactive' | 'prospect';
  lastContact: string;
  followUps: FollowUp[];
  templateType?: string;
  // Contact information
  position?: string;
  department?: string;
  // Company information
  industry?: string;
  companySize?: string;
  website?: string;
  location?: string;
  // Business details
  businessGoals?: string;
  currentChallenges?: string;
  projectScope?: string;
  timeline?: string;
  budget?: string;
  decisionMakers?: string;
  // Engagement preferences
  engagementLevel?: string;
  communicationPreference?: string;
  meetingFrequency?: string;
  preferredContactTime?: string;
  additionalInfo?: string;
  // Legacy wellness fields (for backward compatibility)
  age?: string;
  gender?: string;
  city?: string;
  weight?: string;
  height?: string;
  medicalConditions?: string;
  medications?: string;
  allergies?: string;
  activityLevel?: string;
  sleepPattern?: string;
  stressLevel?: string;
  goals?: string;
  challenges?: string;
  previousCoaching?: string;
  commitmentLevel?: string;
  supportNeeded?: string;
  // Lead-specific fields
  leadSource?: string;
  interestArea?: string;
  currentConcern?: string;
  followUpDate?: string;
  nextFollowUpDate?: string;
  followUpStatus?: string;
  coachAssignedTo?: string;
  nextActionPlan?: string;
  remarks?: string;
}

interface FollowUp {
  id: string;
  customerId: string;
  type: 'call' | 'email' | 'meeting' | 'task';
  subject: string;
  description: string;
  date: string;
  status: 'pending' | 'completed' | 'overdue';
  priority: 'low' | 'medium' | 'high';
  outcomes?: {
    goalProgress?: string;
    stressChange?: string;
    energyLevel?: string;
    sleepQuality?: string;
    nutritionCompliance?: string;
    nextSteps?: string;
    clientMood?: string;
    challenges?: string;
    wins?: string;
    actionItems?: string;
  };
}

interface CustomerDetailProps {
  customer: Customer;
  onBack: () => void;
  onAddFollowUp: (followUpData: Omit<FollowUp, 'id'>) => void;
  onUpdateFollowUp: (followUpId: string, updates: Partial<FollowUp>) => void;
  onUpdateCustomer?: (customerId: string, updates: Partial<Customer>) => void;
  onDeleteCustomer?: (customerId: string) => void;
}

export function CustomerDetail({ customer, onBack, onAddFollowUp, onUpdateFollowUp, onUpdateCustomer, onDeleteCustomer }: CustomerDetailProps) {
  const [showOutcomes, setShowOutcomes] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditMode, setShowEditMode] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [formData, setFormData] = useState({
    type: '' as FollowUp['type'],
    subject: '',
    description: '',
    date: '',
    priority: 'medium' as FollowUp['priority'],
    leadCategory: customer.followUpStatus || 'new-lead'
  });

  // Update leadCategory when form is opened
  useEffect(() => {
    if (showAddForm) {
      setFormData(prev => ({
        ...prev,
        leadCategory: customer.followUpStatus || 'new-lead'
      }));
    }
  }, [showAddForm, customer.followUpStatus]);

  // Helper function to get status display label
  const getStatusLabel = (): string => {
    if (customer.templateType === 'lead' && customer.followUpStatus) {
      switch (customer.followUpStatus) {
        case 'new-lead':
          return '🆕 New Lead';
        case 'contacted':
          return '📞 Contacted';
        case 'interested':
          return '⭐ Interested';
        case 'not-interested':
          return '❌ Not Interested';
        case 'enrolled':
          return '✅ Enrolled';
        case 'follow-up-pending':
          return '⏳ Follow-Up Pending';
        default:
          return '🟡 Prospect';
      }
    }
    // For other types, use standard status
    return customer.status === 'active' ? '🟢 Active' : 
           customer.status === 'prospect' ? '🟡 Prospect' : '⚪ Inactive';
  };

  // Helper function to get status color class
  const getStatusColorClass = (): string => {
    if (customer.templateType === 'lead' && customer.followUpStatus) {
      switch (customer.followUpStatus) {
        case 'enrolled':
          return 'bg-[var(--wellness-primary)] text-white';
        case 'interested':
          return 'bg-green-100 text-green-800';
        case 'contacted':
          return 'bg-blue-100 text-blue-800';
        case 'new-lead':
          return 'bg-purple-100 text-purple-800';
        case 'follow-up-pending':
          return 'bg-amber-100 text-amber-800';
        case 'not-interested':
          return 'bg-gray-100 text-gray-600';
        default:
          return 'bg-amber-100 text-amber-800';
      }
    }
    // For other types, use standard colors
    return customer.status === 'active' 
      ? 'bg-[var(--wellness-primary)] text-white' 
      : customer.status === 'prospect' 
      ? 'bg-amber-100 text-amber-800' 
      : 'bg-gray-100 text-gray-600';
  };

  const handleStatusChange = (followUpId: string, newStatus: FollowUp['status']) => {
    onUpdateFollowUp(followUpId, { status: newStatus });
  };

  const handleCompleteWithOutcomes = (followUpId: string) => {
    setShowOutcomes(followUpId);
  };

  const handleUpdateOutcomes = (followUpId: string, updates: any) => {
    onUpdateFollowUp(followUpId, updates);
    setShowOutcomes(null);
  };

  const handleSubmitFollowUp = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.type || !formData.subject || !formData.date) {
      return;
    }

    // Update customer's lead category if changed and callback exists
    if (customer.templateType === 'lead' && formData.leadCategory !== customer.followUpStatus && onUpdateCustomer) {
      onUpdateCustomer(customer.id, { followUpStatus: formData.leadCategory });
    }

    onAddFollowUp({
      customerId: customer.id,
      type: formData.type,
      subject: formData.subject,
      description: formData.description,
      date: formData.date,
      priority: formData.priority,
      status: 'pending'
    });

    // Reset form
    setFormData({
      type: '' as FollowUp['type'],
      subject: '',
      description: '',
      date: '',
      priority: 'medium' as FollowUp['priority'],
      leadCategory: customer.followUpStatus || 'new-lead'
    });
    setShowAddForm(false);
  };

  const handleFormChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'overdue':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default:
        return <Clock className="w-4 h-4 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'overdue':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'call':
        return '📞';
      case 'email':
        return '📧';
      case 'meeting':
        return '🤝';
      default:
        return '📋';
    }
  };

  // Show edit mode if selected
  if (showEditMode && onUpdateCustomer) {
    return (
      <EditCustomer
        customer={customer}
        onUpdate={onUpdateCustomer}
        onCancel={() => setShowEditMode(false)}
      />
    );
  }

  // Show edit mode if selected
  if (showEditMode && onUpdateCustomer) {
    return (
      <EditCustomer
        customer={customer}
        onUpdate={onUpdateCustomer}
        onCancel={() => setShowEditMode(false)}
      />
    );
  }

  // Show outcomes form if selected
  if (showOutcomes) {
    const followUp = customer.followUps.find(f => f.id === showOutcomes);
    if (followUp) {
      return (
        <FollowUpOutcomes
          followUp={followUp}
          customer={customer}
          onUpdateOutcomes={handleUpdateOutcomes}
          onClose={() => setShowOutcomes(null)}
        />
      );
    }
  }

  const getCommitmentColor = (level: string) => {
    const num = parseInt(level || '0');
    if (num >= 8) return 'text-green-600 bg-green-100';
    if (num >= 6) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getStressColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getActivityColor = (level: string) => {
    switch (level) {
      case 'active': return 'text-green-600 bg-green-100';
      case 'moderate': return 'text-blue-600 bg-blue-100';
      case 'sedentary': return 'text-orange-600 bg-orange-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen wellness-gradient p-4">
      {/* Header */}
      <div className="mb-8">
        <Card className="wellness-card">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <Button variant="outline" onClick={onBack} className="wellness-button-secondary">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
              
              {onUpdateCustomer && customer.templateType === 'lead' && (
                <Button 
                  variant="outline" 
                  onClick={() => setShowEditMode(true)}
                  className="border-blue-300 text-blue-600 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-400"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Lead
                </Button>
              )}
              
              {onDeleteCustomer && (
                <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
                  <AlertDialogTrigger asChild>
                    <Button 
                      variant="outline" 
                      className="border-red-300 text-red-600 hover:bg-red-50 hover:text-red-700 hover:border-red-400"
                      onClick={() => setShowDeleteDialog(true)}
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete Lead
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle className="flex items-center gap-2 text-red-600">
                        <AlertTriangle className="w-5 h-5" />
                        Delete Lead Confirmation
                      </AlertDialogTitle>
                      <AlertDialogDescription asChild>
                        <div>
                          <p className="mb-4">
                            Are you sure you want to delete <strong>{customer.name}</strong>?
                          </p>
                          <p className="mb-2">This action will permanently remove:</p>
                          <ul className="list-disc ml-6 mb-4 space-y-1">
                            <li>All lead information</li>
                            <li>All follow-up records ({customer.followUps?.length || 0} follow-ups)</li>
                            <li>All notes and remarks</li>
                          </ul>
                          <p className="text-red-600 font-semibold">This action cannot be undone.</p>
                        </div>
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
                      <AlertDialogAction 
                        onClick={async (e) => {
                          e.preventDefault();
                          setIsDeleting(true);
                          try {
                            await onDeleteCustomer(customer.id);
                            setShowDeleteDialog(false);
                            onBack();
                          } catch (error) {
                            console.error('Delete failed:', error);
                            toast.error('Failed to delete lead', {
                              description: 'Please try again'
                            });
                          } finally {
                            setIsDeleting(false);
                          }
                        }}
                        className="bg-red-600 hover:bg-red-700 text-white"
                        disabled={isDeleting}
                      >
                        {isDeleting ? (
                          <>
                            <div className="w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            Deleting...
                          </>
                        ) : (
                          <>
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete Permanently
                          </>
                        )}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
              
              <div className="flex-1 flex items-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-full flex items-center justify-center text-white text-xl shadow-lg">
                  {customer.name.charAt(0)}
                </div>
                <div>
                  <h1 className="text-2xl wellness-text-primary">💼 {customer.name}</h1>
                  <div className="space-y-1">
                    <p className="text-[var(--wellness-text-muted)] flex items-center gap-1">
                      {customer.templateType === 'business' ? (
                        <>🏢 {customer.company || 'Business Client'}</>
                      ) : customer.templateType === 'wellness' ? (
                        <>🌿 Wellness Coaching Client</>
                      ) : customer.templateType === 'lead' ? (
                        <>🎯 Lead - {customer.interestArea ? customer.interestArea.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) : 'New Lead'}</>
                      ) : (
                        <>{customer.company || 'Client'}</>
                      )}
                    </p>
                    {customer.position && (
                      <p className="text-sm text-[var(--wellness-text-muted)]">
                        {customer.position}{customer.department && ` • ${customer.department}`}
                      </p>
                    )}
                  </div>
                </div>
              </div>
              <Button onClick={() => setShowAddForm(true)} className="wellness-button">
                <Plus className="w-4 h-4 mr-2" />
                📋 Add Follow-up
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Customer Information */}
        <div className="lg:col-span-1">
          <Card className="wellness-card">
            <CardHeader>
              <CardTitle className="wellness-text-primary flex items-center gap-2">
                <div className="w-6 h-6 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-lg flex items-center justify-center">
                  <span className="text-white text-sm">🎯</span>
                </div>
                Lead Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-full flex items-center justify-center shadow-md">
                  <span className="text-white text-lg">{customer.name.charAt(0)}</span>
                </div>
                <div>
                  <h3 className="wellness-text-primary">{customer.name}</h3>
                  <Badge className={getStatusColorClass()}>
                    {getStatusLabel()}
                  </Badge>
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Building className="w-4 h-4 wellness-text-primary" />
                  <span className="text-[var(--wellness-text)]">
                    {customer.city ? `📍 ${customer.city}` : '🎯 Lead'}
                  </span>
                </div>
                {customer.email && (
                  <div className="flex items-center gap-3">
                    <Mail className="w-4 h-4 wellness-text-primary" />
                    <a href={`mailto:${customer.email}`} className="wellness-text-primary hover:underline">
                      {customer.email}
                    </a>
                  </div>
                )}
                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4 wellness-text-primary" />
                  <a href={`tel:${customer.phone}`} className="wellness-text-primary hover:underline">
                    {customer.phone}
                  </a>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="w-4 h-4 wellness-text-primary" />
                  <span className="text-[var(--wellness-text)]">📅 Last contact: {customer.lastContact}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Business Context */}
          {customer.templateType === 'business' && (
            <Card className="wellness-card mt-4">
              <CardHeader>
                <CardTitle className="wellness-text-primary flex items-center gap-2">
                  <div className="w-6 h-6 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-lg flex items-center justify-center">
                    <Target className="w-3 h-3 text-white" />
                  </div>
                  💼 Business Profile
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {customer.engagementLevel && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Engagement Level</span>
                    <Badge className={getCommitmentColor(customer.engagementLevel)}>
                      {customer.engagementLevel}/10
                    </Badge>
                  </div>
                )}
                
                <div className="grid grid-cols-1 gap-2">
                  {customer.industry && (
                    <Badge className="bg-blue-100 text-blue-800 text-xs p-2">
                      🏭 {customer.industry}
                    </Badge>
                  )}
                  {customer.companySize && (
                    <Badge className="bg-purple-100 text-purple-800 text-xs p-2">
                      👥 {customer.companySize}
                    </Badge>
                  )}
                  {customer.timeline && (
                    <Badge className="bg-green-100 text-green-800 text-xs p-2">
                      ⏰ {customer.timeline}
                    </Badge>
                  )}
                  {customer.budget && (
                    <Badge className="bg-yellow-100 text-yellow-800 text-xs p-2">
                      💰 {customer.budget}
                    </Badge>
                  )}
                </div>

                {customer.businessGoals && (
                  <div className="pt-2 border-t">
                    <p className="text-xs text-gray-600 mb-1"><strong>Business Goals:</strong></p>
                    <p className="text-xs text-gray-700">{customer.businessGoals.substring(0, 150)}...</p>
                  </div>
                )}

                {customer.currentChallenges && (
                  <div>
                    <p className="text-xs text-gray-600 mb-1"><strong>Current Challenges:</strong></p>
                    <p className="text-xs text-orange-700">{customer.currentChallenges.substring(0, 150)}...</p>
                  </div>
                )}

                {customer.projectScope && (
                  <div>
                    <p className="text-xs text-gray-600 mb-1"><strong>Project Scope:</strong></p>
                    <p className="text-xs text-gray-700">{customer.projectScope.substring(0, 150)}...</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Wellness Context */}
          {customer.templateType === 'wellness' && (
            <Card className="wellness-card mt-4">
              <CardHeader>
                <CardTitle className="wellness-text-primary flex items-center gap-2">
                  <div className="w-6 h-6 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-lg flex items-center justify-center">
                    <Target className="w-3 h-3 text-white" />
                  </div>
                  🧘‍♀️ Wellness Profile
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {customer.commitmentLevel && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Commitment Level</span>
                    <Badge className={getCommitmentColor(customer.commitmentLevel)}>
                      {customer.commitmentLevel}/10
                    </Badge>
                  </div>
                )}
                
                <div className="grid grid-cols-2 gap-2">
                  {customer.stressLevel && (
                    <Badge className={`${getStressColor(customer.stressLevel)} text-xs p-2`}>
                      <Brain className="w-3 h-3 mr-1" />
                      Stress: {customer.stressLevel}
                    </Badge>
                  )}
                  {customer.activityLevel && (
                    <Badge className={`${getActivityColor(customer.activityLevel)} text-xs p-2`}>
                      <Activity className="w-3 h-3 mr-1" />
                      {customer.activityLevel}
                    </Badge>
                  )}
                </div>

                {customer.goals && (
                  <div className="pt-2 border-t">
                    <p className="text-xs text-gray-600 mb-1"><strong>Goals:</strong></p>
                    <p className="text-xs text-gray-700">{customer.goals.substring(0, 150)}...</p>
                  </div>
                )}

                {customer.challenges && (
                  <div>
                    <p className="text-xs text-gray-600 mb-1"><strong>Challenges:</strong></p>
                    <p className="text-xs text-orange-700">{customer.challenges.substring(0, 150)}...</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Lead Profile */}
          {customer.templateType === 'lead' && (
            <Card className="wellness-card mt-4">
              <CardHeader>
                <CardTitle className="wellness-text-primary flex items-center gap-2">
                  <div className="w-6 h-6 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-lg flex items-center justify-center">
                    <Target className="w-3 h-3 text-white" />
                  </div>
                  🎯 Lead Profile
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-2">
                  {customer.leadSource && (
                    <Badge className="bg-blue-100 text-blue-800 text-xs p-2">
                      📱 Source: {customer.leadSource.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </Badge>
                  )}
                  {customer.interestArea && (
                    <Badge className="bg-purple-100 text-purple-800 text-xs p-2">
                      💡 Interest: {customer.interestArea.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </Badge>
                  )}
                  {customer.followUpStatus && (
                    <Badge className="bg-green-100 text-green-800 text-xs p-2">
                      📊 Status: {customer.followUpStatus.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </Badge>
                  )}
                  {customer.coachAssignedTo && (
                    <Badge className="bg-orange-100 text-orange-800 text-xs p-2">
                      👤 Coach: {customer.coachAssignedTo}
                    </Badge>
                  )}
                </div>

                {customer.currentConcern && (
                  <div className="pt-2 border-t">
                    <p className="text-xs text-gray-600 mb-1"><strong>Health Concern:</strong></p>
                    <p className="text-xs text-gray-700">{customer.currentConcern}</p>
                  </div>
                )}

                {customer.nextActionPlan && (
                  <div>
                    <p className="text-xs text-gray-600 mb-1"><strong>Next Action Plan:</strong></p>
                    <p className="text-xs text-green-700">{customer.nextActionPlan}</p>
                  </div>
                )}

                {customer.nextFollowUpDate && (
                  <div>
                    <p className="text-xs text-gray-600 mb-1"><strong>Next Follow-up:</strong></p>
                    <p className="text-xs text-blue-700">📅 {customer.nextFollowUpDate}</p>
                  </div>
                )}

                {customer.remarks && (
                  <div>
                    <p className="text-xs text-gray-600 mb-1"><strong>Notes:</strong></p>
                    <p className="text-xs text-gray-700">{customer.remarks}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Quick Stats */}
          <Card className="wellness-card mt-4">
            <CardHeader>
              <CardTitle className="wellness-text-primary flex items-center gap-2">
                <div className="w-6 h-6 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-lg flex items-center justify-center">
                  <span className="text-white text-sm">📊</span>
                </div>
                Follow-up Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl text-yellow-600">
                    {customer.followUps.filter(f => f.status === 'pending').length}
                  </div>
                  <div className="text-sm text-gray-600">Pending</div>
                </div>
                <div>
                  <div className="text-2xl text-red-600">
                    {customer.followUps.filter(f => f.status === 'overdue').length}
                  </div>
                  <div className="text-sm text-gray-600">Overdue</div>
                </div>
                <div>
                  <div className="text-2xl text-green-600">
                    {customer.followUps.filter(f => f.status === 'completed').length}
                  </div>
                  <div className="text-sm text-gray-600">Completed</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Follow-ups */}
        <div className="lg:col-span-2">
          <Card className="wellness-card">
            <CardHeader>
              <CardTitle className="wellness-text-primary flex items-center gap-2">
                <div className="w-6 h-6 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-lg flex items-center justify-center">
                  <span className="text-white text-sm">📋</span>
                </div>
                Follow-up History
              </CardTitle>
              <CardDescription>
                {customer.templateType === 'business' 
                  ? 'Track all business interactions and upcoming meetings for this client'
                  : 'Track all wellness coaching interactions and upcoming sessions for this client'
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Inline Add Follow-up Form */}
                {showAddForm && (
                  <Card className="border-2 wellness-bg-light border-[var(--wellness-primary)] border-opacity-50 wellness-shadow-lg">
                    <CardHeader>
                      <div className="flex justify-between items-center">
                        <CardTitle className="wellness-text-primary text-lg flex items-center gap-2">
                          <div className="w-6 h-6 bg-gradient-to-br from-[var(--wellness-primary)] to-[var(--wellness-secondary)] rounded-lg flex items-center justify-center">
                            <span className="text-white text-sm">📋</span>
                          </div>
                          {customer.templateType === 'business' ? 'New Business Follow-up' : 'New Wellness Follow-up'}
                        </CardTitle>
                        <Button variant="ghost" size="sm" onClick={() => setShowAddForm(false)} className="wellness-text-primary hover:bg-[var(--wellness-bg-light)]">
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handleSubmitFollowUp} className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {/* Type Selection */}
                          <div className="space-y-2">
                            <Label htmlFor="type">Interaction Type *</Label>
                            <Select value={formData.type} onValueChange={(value: FollowUp['type']) => handleFormChange('type', value)}>
                              <SelectTrigger className="wellness-focus">
                                <SelectValue placeholder="Select type" />
                              </SelectTrigger>
                              <SelectContent className="wellness-card">
                                {customer.templateType === 'business' ? (
                                  <>
                                    <SelectItem value="call">📞 Business Call</SelectItem>
                                    <SelectItem value="email">📧 Follow-up Email</SelectItem>
                                    <SelectItem value="meeting">🤝 Client Meeting</SelectItem>
                                    <SelectItem value="task">📋 Action Item</SelectItem>
                                  </>
                                ) : (
                                  <>
                                    <SelectItem value="call">📞 Coaching Call</SelectItem>
                                    <SelectItem value="email">📧 Wellness Check-in</SelectItem>
                                    <SelectItem value="meeting">🧘‍♀️ In-Person Session</SelectItem>
                                    <SelectItem value="task">📋 Wellness Task</SelectItem>
                                  </>
                                )}
                              </SelectContent>
                            </Select>
                          </div>

                          {/* Date */}
                          <div className="space-y-2">
                            <Label htmlFor="date">Scheduled Date *</Label>
                            <Input
                              id="date"
                              type="date"
                              min={new Date().toISOString().split('T')[0]}
                              value={formData.date}
                              onChange={(e) => handleFormChange('date', e.target.value)}
                              required
                            />
                          </div>
                        </div>

                        {/* Subject */}
                        <div className="space-y-2">
                          <Label htmlFor="subject">Subject *</Label>
                          <Input
                            id="subject"
                            type="text"
                            placeholder={customer.templateType === 'business' 
                              ? "e.g., Project status review, Contract discussion" 
                              : "e.g., Weekly progress check, Nutrition goal review"}
                            value={formData.subject}
                            onChange={(e) => handleFormChange('subject', e.target.value)}
                            required
                          />
                        </div>

                        {/* Priority */}
                        <div className="space-y-2">
                          <Label htmlFor="priority">Priority</Label>
                          <Select value={formData.priority} onValueChange={(value: FollowUp['priority']) => handleFormChange('priority', value)}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="low">🟢 Low Priority</SelectItem>
                              <SelectItem value="medium">🟡 Medium Priority</SelectItem>
                              <SelectItem value="high">🔴 High Priority</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {/* Lead Category - Only show for leads */}
                        {customer.templateType === 'lead' && (
                          <div className="space-y-2">
                            <Label htmlFor="leadCategory">Update Lead Category</Label>
                            <Select value={formData.leadCategory} onValueChange={(value) => handleFormChange('leadCategory', value)}>
                              <SelectTrigger className="wellness-focus">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="wellness-card">
                                <SelectItem value="new-lead">🆕 New Lead</SelectItem>
                                <SelectItem value="contacted">📞 Contacted</SelectItem>
                                <SelectItem value="interested">⭐ Interested</SelectItem>
                                <SelectItem value="not-interested">❌ Not Interested</SelectItem>
                                <SelectItem value="enrolled">✅ Enrolled</SelectItem>
                                <SelectItem value="follow-up-pending">⏳ Follow-Up Pending</SelectItem>
                              </SelectContent>
                            </Select>
                            <p className="text-xs text-[var(--wellness-text-muted)]">
                              Change the lead's status when adding this follow-up
                            </p>
                          </div>
                        )}

                        {/* Description */}
                        <div className="space-y-2">
                          <Label htmlFor="description">{customer.templateType === 'business' ? 'Notes & Meeting Focus' : 'Notes & Coaching Focus'}</Label>
                          <Textarea
                            id="description"
                            placeholder={customer.templateType === 'business' 
                              ? "e.g., Discuss project milestones, review deliverables, address concerns..."
                              : "e.g., Review fitness progress, discuss stress management techniques..."}
                            value={formData.description}
                            onChange={(e) => handleFormChange('description', e.target.value)}
                            rows={3}
                          />
                        </div>

                        {/* Action Buttons */}
                        <div className="flex gap-3 pt-2">
                          <Button type="submit" className="flex-1">
                            📋 Schedule Follow-up
                          </Button>
                          <Button type="button" variant="outline" onClick={() => setShowAddForm(false)}>
                            Cancel
                          </Button>
                        </div>
                      </form>
                    </CardContent>
                  </Card>
                )}

                {customer.followUps.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <p>No wellness follow-ups yet</p>
                    <Button className="mt-4" onClick={() => setShowAddForm(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      🌿 Add First Wellness Follow-up
                    </Button>
                  </div>
                ) : (
                  customer.followUps
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                    .map(followUp => (
                      <div key={followUp.id} className="p-4 border rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">{getTypeIcon(followUp.type)}</span>
                            <div>
                              <h4>{followUp.subject}</h4>
                              <p className="text-sm text-gray-600 capitalize">
                                {followUp.type} • {followUp.date}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className={getPriorityColor(followUp.priority)}>
                              {followUp.priority} priority
                            </Badge>
                            <div className="flex items-center gap-1">
                              {getStatusIcon(followUp.status)}
                              <Badge className={getStatusColor(followUp.status)}>
                                {followUp.status}
                              </Badge>
                            </div>
                          </div>
                        </div>

                        <p className="text-gray-700 mb-3">{followUp.description}</p>

                        {followUp.status === 'pending' && (
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleStatusChange(followUp.id, 'completed')}
                            >
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Mark Complete
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleStatusChange(followUp.id, 'overdue')}
                            >
                              <AlertTriangle className="w-4 h-4 mr-1" />
                              Mark Overdue
                            </Button>
                          </div>
                        )}

                        {followUp.status === 'overdue' && (
                          <Button
                            size="sm"
                            onClick={() => handleStatusChange(followUp.id, 'completed')}
                          >
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Mark Complete
                          </Button>
                        )}
                      </div>
                    ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}