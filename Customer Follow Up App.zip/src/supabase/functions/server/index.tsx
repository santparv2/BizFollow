/**
 * BizFollow Backend API Server
 * 
 * IMPORTANT: After making changes to this file, you MUST redeploy the edge function
 * for the changes to take effect in production.
 * 
 * Recent updates:
 * - Made DELETE /customers/:id endpoint idempotent (always returns 200, even if customer doesn't exist)
 * - Made PUT /customers/:id endpoint more fault-tolerant (returns 200 with warning if customer not found)
 * - Added comprehensive error logging throughout
 */

import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowHeaders: ['Content-Type', 'Authorization'],
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
}));

app.use('*', logger(console.log));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Health check
app.get('/make-server-b8fc68da/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Debug endpoint to test KV store
app.get('/make-server-b8fc68da/debug', async (c) => {
  try {
    console.log('Debug endpoint called');
    const testKey = 'debug-test-' + Date.now();
    const testValue = { message: 'test data', timestamp: new Date().toISOString() };
    
    console.log('Testing KV store set operation');
    await kv.set(testKey, testValue);
    
    console.log('Testing KV store get operation');
    const retrieved = await kv.get(testKey);
    
    console.log('Testing KV store getByPrefix operation');
    const prefixResults = await kv.getByPrefix('debug-test-');
    
    console.log('Cleaning up test data');
    await kv.del(testKey);
    
    return c.json({ 
      success: true, 
      testResults: {
        stored: testValue,
        retrieved: retrieved,
        prefixResults: prefixResults
      }
    });
  } catch (error) {
    console.log('Debug endpoint error:', error);
    return c.json({ 
      success: false, 
      error: error.message || error,
      stack: error.stack 
    }, 500);
  }
});

// User signup
app.post('/make-server-b8fc68da/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json();

    if (!email || !password || !name) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log(`Error creating user: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ user: data.user });
  } catch (error) {
    console.log(`Server error during signup: ${error}`);
    return c.json({ error: 'Server error during signup' }, 500);
  }
});

// Get customers for authenticated user
app.get('/make-server-b8fc68da/customers', async (c) => {
  try {
    console.log('Received request to get customers');
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    console.log('Access token:', accessToken ? 'Present' : 'Missing');
    
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    console.log('Auth user:', user?.id || 'No user');
    console.log('Auth error:', authError || 'No error');
    
    if (!user?.id || authError) {
      console.log('Authorization failed');
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const prefix = `customers:${user.id}:`;
    console.log('Searching for customers with prefix:', prefix);
    
    const customers = await kv.getByPrefix(prefix);
    console.log('Raw customers from KV store:', customers);
    
    // The getByPrefix returns the values directly, not wrapped in an object
    const customerList = Array.isArray(customers) ? customers : [];
    console.log('Processed customer list:', customerList);
    
    return c.json({ customers: customerList });
  } catch (error) {
    console.log(`Error fetching customers: ${error}`);
    console.log('Error stack:', error.stack);
    return c.json({ error: `Error fetching customers: ${error.message || error}` }, 500);
  }
});

// Add customer
app.post('/make-server-b8fc68da/customers', async (c) => {
  try {
    console.log('Received request to add customer');
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    console.log('Access token:', accessToken ? 'Present' : 'Missing');
    
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    console.log('Auth user:', user?.id || 'No user');
    console.log('Auth error:', authError || 'No error');
    
    if (!user?.id || authError) {
      console.log('Authorization failed');
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const customerData = await c.req.json();
    console.log('Customer data received:', customerData);
    
    const customerId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const customer = {
      id: customerId,
      ...customerData,
      followUps: [],
      createdAt: new Date().toISOString(),
      userId: user.id
    };

    console.log('Saving customer with key:', `customers:${user.id}:${customerId}`);
    console.log('Customer object to save:', customer);
    
    await kv.set(`customers:${user.id}:${customerId}`, customer);
    console.log('Customer saved successfully');
    
    return c.json({ customer });
  } catch (error) {
    console.log(`Error adding customer: ${error}`);
    console.log('Error stack:', error.stack);
    return c.json({ error: `Error adding customer: ${error.message || error}` }, 500);
  }
});

// Update customer
app.put('/make-server-b8fc68da/customers/:id', async (c) => {
  try {
    console.log('Received request to update customer');
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || authError) {
      console.log('Authorization failed');
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const customerId = c.req.param('id');
    const updates = await c.req.json();
    console.log('Updating customer:', customerId);
    console.log('Updates:', updates);
    
    const customerKey = `customers:${user.id}:${customerId}`;
    const existingCustomer = await kv.get(customerKey);
    
    if (!existingCustomer) {
      console.log('Customer not found:', customerKey);
      // Return a 200 with a warning instead of 404
      // This makes the operation more fault-tolerant
      return c.json({ 
        warning: 'Customer not found - may have been deleted',
        customer: null 
      }, 200);
    }

    const updatedCustomer = {
      ...existingCustomer,
      ...updates,
      id: customerId, // Ensure ID is preserved
      userId: user.id, // Ensure userId is preserved
      updatedAt: new Date().toISOString()
    };

    await kv.set(customerKey, updatedCustomer);
    console.log('Customer updated successfully');
    return c.json({ customer: updatedCustomer });
  } catch (error) {
    console.log(`Error updating customer: ${error}`);
    console.log('Error stack:', error.stack);
    return c.json({ error: `Error updating customer: ${error.message || error}` }, 500);
  }
});

// Delete customer
app.delete('/make-server-b8fc68da/customers/:id', async (c) => {
  try {
    console.log('Received request to delete customer');
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || authError) {
      console.log('Authorization failed');
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const customerId = c.req.param('id');
    const customerKey = `customers:${user.id}:${customerId}`;
    console.log('Deleting customer ID:', customerId);
    console.log('Customer key:', customerKey);
    
    // Delete all follow-ups for this customer (whether customer exists or not)
    const followUpPrefix = `followups:${user.id}:${customerId}:`;
    const followUps = await kv.getByPrefix(followUpPrefix);
    console.log(`Found ${followUps.length} follow-ups to delete`);
    
    for (const followUp of followUps) {
      if (followUp.id) {
        const followUpKey = `followups:${user.id}:${customerId}:${followUp.id}`;
        await kv.del(followUpKey);
        console.log(`Deleted follow-up: ${followUpKey}`);
      }
    }

    // Delete the customer (this is idempotent - no error if already deleted)
    await kv.del(customerKey);
    console.log(`Deleted customer: ${customerKey}`);
    
    return c.json({ 
      success: true, 
      message: 'Customer and all related data deleted successfully' 
    });
  } catch (error) {
    console.log(`Error deleting customer: ${error}`);
    console.log('Error stack:', error.stack);
    return c.json({ error: `Error deleting customer: ${error.message || error}` }, 500);
  }
});

// Get follow-ups for a customer
app.get('/make-server-b8fc68da/customers/:id/followups', async (c) => {
  try {
    console.log('Received request to get customer follow-ups');
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || authError) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const customerId = c.req.param('id');
    console.log('Getting follow-ups for customer:', customerId);
    
    const prefix = `followups:${user.id}:${customerId}:`;
    console.log('Searching with prefix:', prefix);
    
    const followUps = await kv.getByPrefix(prefix);
    console.log('Raw follow-ups found:', followUps);
    
    // getByPrefix already returns the values directly, no need to map item.value
    const followUpList = Array.isArray(followUps) ? followUps : [];
    console.log('Processed follow-up list:', followUpList);
    
    return c.json({ followUps: followUpList });
  } catch (error) {
    console.log(`Error fetching follow-ups: ${error}`);
    console.log('Error stack:', error.stack);
    return c.json({ error: `Error fetching follow-ups: ${error.message || error}` }, 500);
  }
});

// Add follow-up
app.post('/make-server-b8fc68da/followups', async (c) => {
  try {
    console.log('Received request to add follow-up');
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    console.log('Access token:', accessToken ? 'Present' : 'Missing');
    
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    console.log('Auth user:', user?.id || 'No user');
    console.log('Auth error:', authError || 'No error');
    
    if (!user?.id || authError) {
      console.log('Authorization failed');
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const followUpData = await c.req.json();
    console.log('Follow-up data received:', followUpData);
    
    // Validate required fields
    if (!followUpData.customerId || !followUpData.type || !followUpData.subject) {
      console.log('Missing required fields in follow-up data');
      return c.json({ error: 'Missing required fields: customerId, type, and subject are required' }, 400);
    }

    const followUpId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const followUp = {
      id: followUpId,
      customerId: followUpData.customerId,
      type: followUpData.type,
      subject: followUpData.subject,
      description: followUpData.description || '',
      date: followUpData.date || new Date().toISOString().split('T')[0],
      status: followUpData.status || 'pending',
      priority: followUpData.priority || 'medium',
      outcomes: followUpData.outcomes || {},
      createdAt: new Date().toISOString(),
      userId: user.id
    };

    console.log('Saving follow-up with key:', `followups:${user.id}:${followUpData.customerId}:${followUpId}`);
    console.log('Follow-up object to save:', followUp);

    await kv.set(`followups:${user.id}:${followUpData.customerId}:${followUpId}`, followUp);
    console.log('Follow-up saved successfully');
    
    // Update customer's lastContact date
    console.log('Updating customer lastContact date');
    const customer = await kv.get(`customers:${user.id}:${followUpData.customerId}`);
    if (customer) {
      console.log('Found customer to update:', customer.name);
      const updatedCustomer = {
        ...customer,
        lastContact: new Date().toISOString().split('T')[0],
        updatedAt: new Date().toISOString()
      };
      await kv.set(`customers:${user.id}:${followUpData.customerId}`, updatedCustomer);
      console.log('Customer lastContact updated successfully');
    } else {
      console.log('Customer not found for follow-up:', followUpData.customerId);
    }

    return c.json({ followUp });
  } catch (error) {
    console.log(`Error adding follow-up: ${error}`);
    console.log('Error stack:', error.stack);
    return c.json({ error: `Error adding follow-up: ${error.message || error}` }, 500);
  }
});

// Update follow-up
app.put('/make-server-b8fc68da/followups/:customerId/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || authError) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const customerId = c.req.param('customerId');
    const followUpId = c.req.param('id');
    const updates = await c.req.json();
    
    const existingFollowUp = await kv.get(`followups:${user.id}:${customerId}:${followUpId}`);
    if (!existingFollowUp) {
      return c.json({ error: 'Follow-up not found' }, 404);
    }

    const updatedFollowUp = {
      ...existingFollowUp,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    await kv.set(`followups:${user.id}:${customerId}:${followUpId}`, updatedFollowUp);
    return c.json({ followUp: updatedFollowUp });
  } catch (error) {
    console.log(`Error updating follow-up: ${error}`);
    return c.json({ error: 'Error updating follow-up' }, 500);
  }
});

// Get all follow-ups for user (dashboard overview)
app.get('/make-server-b8fc68da/followups', async (c) => {
  try {
    console.log('Received request to get all follow-ups');
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    console.log('Access token:', accessToken ? 'Present' : 'Missing');
    
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    console.log('Auth user:', user?.id || 'No user');
    console.log('Auth error:', authError || 'No error');
    
    if (!user?.id || authError) {
      console.log('Authorization failed');
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const prefix = `followups:${user.id}:`;
    console.log('Searching for follow-ups with prefix:', prefix);
    
    const followUps = await kv.getByPrefix(prefix);
    console.log('Raw follow-ups from KV store:', followUps);
    
    // getByPrefix already returns the values directly, no need to map item.value
    const followUpList = Array.isArray(followUps) ? followUps : [];
    console.log('Processed follow-up list:', followUpList);
    
    return c.json({ followUps: followUpList });
  } catch (error) {
    console.log(`Error fetching all follow-ups: ${error}`);
    console.log('Error stack:', error.stack);
    return c.json({ error: `Error fetching follow-ups: ${error.message || error}` }, 500);
  }
});

Deno.serve(app.fetch);