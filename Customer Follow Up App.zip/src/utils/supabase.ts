// Initialize global error suppression FIRST
import './error-suppression';

import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from './supabase/info';

// Comprehensive error suppression for network errors
if (typeof window !== 'undefined') {
  // Suppress unhandled promise rejections for network errors
  const originalRejectionHandler = window.onunhandledrejection;
  window.onunhandledrejection = function(event: PromiseRejectionEvent) {
    // Silently ignore network-related rejections
    const reason = event.reason;
    if (reason?.name === 'OfflineError' ||
        reason?.name === 'NetworkError' || 
        reason?.name === 'TypeError' ||
        reason?.message === 'OFFLINE' ||
        reason?.message?.includes('Network unavailable') ||
        reason?.message?.includes('Failed to fetch') ||
        reason?.message?.includes('fetch')) {
      event.preventDefault();
      return;
    }
    // Call original handler for other errors
    if (originalRejectionHandler) {
      originalRejectionHandler.call(window, event);
    }
  };

  // Also suppress regular error events for network errors
  const originalErrorHandler = window.onerror;
  window.onerror = function(message, source, lineno, colno, error) {
    if (error?.name === 'OfflineError' ||
        error?.name === 'NetworkError' || 
        error?.name === 'TypeError' ||
        error?.message === 'OFFLINE' ||
        message?.toString().includes('Network unavailable') ||
        message?.toString().includes('Failed to fetch')) {
      return true; // Prevent default error handling
    }
    // Call original handler for other errors
    if (originalErrorHandler) {
      return originalErrorHandler.call(window, message, source, lineno, colno, error);
    }
    return false;
  };
}

// Create Supabase client with enhanced error handling
export const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey,
  {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
    },
    global: {
      fetch: async (url, options = {}) => {
        // Check if browser is offline before attempting fetch
        if (typeof navigator !== 'undefined' && !navigator.onLine) {
          const offlineError = new Error('OFFLINE');
          offlineError.name = 'OfflineError';
          throw offlineError;
        }

        try {
          return await fetch(url, options);
        } catch (error: any) {
          // Transform all network errors to OfflineError
          if (error.name === 'OfflineError' ||
              error.message === 'OFFLINE' ||
              error.message?.includes('Failed to fetch') || 
              error.message?.includes('fetch') ||
              error.name === 'TypeError' ||
              error.name === 'NetworkError') {
            const offlineError = new Error('OFFLINE');
            offlineError.name = 'OfflineError';
            throw offlineError;
          }
          throw error;
        }
      },
    },
  }
);