import { projectId, publicAnonKey } from './supabase/info';

const BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-b8fc68da`;

class ApiClient {
  private accessToken: string | null = null;

  setAccessToken(token: string | null) {
    this.accessToken = token;
  }

  private async request(endpoint: string, options: RequestInit = {}, suppressErrorLog = false) {
    // For authenticated endpoints, ensure we have a user access token
    const isAuthRequired = endpoint !== '/health' && endpoint !== '/debug' && !endpoint.includes('/signup');
    
    if (isAuthRequired && !this.accessToken) {
      console.error('No access token available for authenticated request');
      throw new Error('Authentication required - please log in');
    }

    // Check if browser is offline before attempting fetch
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      const offlineError = new Error('OFFLINE');
      offlineError.name = 'OfflineError';
      throw offlineError;
    }

    const headers = {
      'Content-Type': 'application/json',
      ...(this.accessToken ? { 'Authorization': `Bearer ${this.accessToken}` } : {}),
      ...options.headers,
    };

    console.log(`Making API request to: ${BASE_URL}${endpoint}`);
    console.log(`Using authorization:`, this.accessToken ? 'User token' : 'No token');

    try {
      const response = await fetch(`${BASE_URL}${endpoint}`, {
        ...options,
        headers,
      }).catch((fetchError) => {
        // Handle fetch errors more gracefully - transform to OfflineError
        if (fetchError.name === 'OfflineError' ||
            fetchError.message === 'OFFLINE' ||
            fetchError.message?.includes('Failed to fetch') || 
            fetchError.name === 'TypeError' ||
            fetchError.name === 'NetworkError') {
          const offlineError = new Error('OFFLINE');
          offlineError.name = 'OfflineError';
          throw offlineError;
        }
        throw fetchError;
      });

      console.log(`API Response status: ${response.status}`);

      if (!response.ok) {
        const errorData = await response.text();
        
        // Don't log 404 errors as errors if suppressed (they're often expected)
        if (response.status === 404 && suppressErrorLog) {
          console.log(`Resource not found (404) - this may be expected: ${endpoint}`);
        } else {
          console.error(`API Error ${response.status}: ${errorData}`);
        }
        
        throw new Error(`API Error: ${response.status} - ${errorData}`);
      }

      const data = await response.json();
      console.log(`API Response data:`, data);
      return data;
    } catch (error: any) {
      // Don't log as error if it's a suppressed 404
      if (suppressErrorLog && error.message?.includes('404')) {
        console.log(`Request completed with expected 404 for ${endpoint}`);
      } else {
        // Only log as error if it's not a network connectivity issue
        const isNetworkError = error.name === 'OfflineError' ||
                              error.name === 'NetworkError' ||
                              error.message === 'OFFLINE' ||
                              error.message?.includes('Failed to fetch') || 
                              error.name === 'TypeError';
        if (isNetworkError) {
          // Don't log network errors at all
        } else {
          console.error(`❌ Request failed for ${endpoint}:`, error.message || error);
        }
      }
      throw error;
    }
  }

  // Health check
  async healthCheck() {
    try {
      return await this.request('/health');
    } catch (error: any) {
      // Suppress health check errors silently
      if (error.name === 'OfflineError' ||
          error.name === 'NetworkError' || 
          error.message === 'OFFLINE' ||
          error.message?.includes('Network unavailable')) {
        throw new Error('OFFLINE');
      }
      throw error;
    }
  }

  // Debug endpoint
  async debug() {
    return this.request('/debug');
  }

  // Auth methods
  async signup(email: string, password: string, name: string) {
    return this.request('/signup', {
      method: 'POST',
      body: JSON.stringify({ email, password, name }),
    });
  }

  // Customer methods
  async getCustomers() {
    return this.request('/customers');
  }

  async addCustomer(customerData: any) {
    return this.request('/customers', {
      method: 'POST',
      body: JSON.stringify(customerData),
    });
  }

  async updateCustomer(customerId: string, updates: any) {
    try {
      // Suppress 404 error logging since it's expected when customer is deleted
      const result = await this.request(`/customers/${customerId}`, {
        method: 'PUT',
        body: JSON.stringify(updates),
      }, true); // Suppress error logs for 404
      
      // Check if the response indicates customer was not found
      if (result.warning && result.customer === null) {
        console.log('Customer not found during update (may have been deleted):', customerId);
        throw new Error('Customer not found - may have been deleted');
      }
      
      return result;
    } catch (error) {
      // If it's a 404, provide a more helpful error message
      if (error.message?.includes('404')) {
        throw new Error('Customer not found - may have been deleted');
      }
      throw error;
    }
  }

  async deleteCustomer(customerId: string) {
    try {
      // Suppress 404 error logging since it's expected when customer is already deleted
      return await this.request(`/customers/${customerId}`, {
        method: 'DELETE',
      }, true); // Suppress error logs for 404
    } catch (error) {
      // If it's a 404, treat it as already deleted (idempotent delete)
      if (error.message?.includes('404')) {
        console.log('Customer already deleted:', customerId);
        return { success: true, message: 'Customer already deleted', wasAlreadyDeleted: true };
      }
      
      // If it's a network error (Failed to fetch), indicate server is unreachable
      if (error.message?.includes('Failed to fetch') || error.name === 'TypeError') {
        console.error('Network error during delete - server may be unreachable:', error);
        throw new Error('SERVER_UNREACHABLE');
      }
      
      throw error;
    }
  }

  // Follow-up methods
  async getCustomerFollowUps(customerId: string) {
    return this.request(`/customers/${customerId}/followups`);
  }

  async addFollowUp(followUpData: any) {
    return this.request('/followups', {
      method: 'POST',
      body: JSON.stringify(followUpData),
    });
  }

  async updateFollowUp(customerId: string, followUpId: string, updates: any) {
    return this.request(`/followups/${customerId}/${followUpId}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }

  async getAllFollowUps() {
    return this.request('/followups');
  }
}

export const apiClient = new ApiClient();