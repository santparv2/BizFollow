// AGGRESSIVE ERROR SUPPRESSION - Must load before everything else
// This file intercepts and suppresses all network-related errors globally

if (typeof window !== 'undefined') {
  // Override console.log to suppress network errors
  const originalConsoleLog = console.log;
  console.log = function(...args: any[]) {
    const logString = args.join(' ');
    if (logString.includes('OfflineError') ||
        logString.includes('OFFLINE') ||
        logString.includes('NetworkError') ||
        logString.includes('Network unavailable') ||
        logString.includes('Failed to fetch')) {
      // Silently ignore - don't log anything
      return;
    }
    originalConsoleLog.apply(console, args);
  };

  // Override console.error to suppress network errors
  const originalConsoleError = console.error;
  console.error = function(...args: any[]) {
    const errorString = args.join(' ');
    if (errorString.includes('OfflineError') ||
        errorString.includes('OFFLINE') ||
        errorString.includes('NetworkError') ||
        errorString.includes('Network unavailable') ||
        errorString.includes('Failed to fetch') ||
        errorString.includes('TypeError: Failed to fetch')) {
      // Silently ignore - don't log anything
      return;
    }
    originalConsoleError.apply(console, args);
  };

  // Override console.warn for network warnings
  const originalConsoleWarn = console.warn;
  console.warn = function(...args: any[]) {
    const warnString = args.join(' ');
    if (warnString.includes('OfflineError') ||
        warnString.includes('OFFLINE') ||
        warnString.includes('NetworkError') ||
        warnString.includes('Network unavailable') ||
        warnString.includes('Failed to fetch')) {
      // Silently ignore
      return;
    }
    originalConsoleWarn.apply(console, args);
  };

  // Suppress unhandled promise rejections for network errors
  window.addEventListener('unhandledrejection', function(event) {
    const reason = event.reason;
    if (reason?.name === 'OfflineError' ||
        reason?.name === 'NetworkError' || 
        reason?.name === 'TypeError' ||
        reason?.message === 'OFFLINE' ||
        reason?.message?.includes('Network unavailable') ||
        reason?.message?.includes('Failed to fetch') ||
        reason?.message?.includes('fetch')) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      return;
    }
  }, true);

  // Suppress regular error events for network errors
  window.addEventListener('error', function(event) {
    const error = event.error;
    const message = event.message;
    if (error?.name === 'OfflineError' ||
        error?.name === 'NetworkError' || 
        error?.name === 'TypeError' ||
        error?.message === 'OFFLINE' ||
        message === 'OFFLINE' ||
        message?.includes('OfflineError') ||
        message?.includes('Network unavailable') ||
        message?.includes('Failed to fetch') ||
        message?.includes('NetworkError')) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      return true;
    }
  }, true);

  // Override fetch to never throw NetworkError
  const originalFetch = window.fetch;
  window.fetch = async function(...args: any[]) {
    // Check offline first
    if (!navigator.onLine) {
      const error = new Error('OFFLINE');
      error.name = 'OfflineError';
      throw error;
    }

    try {
      return await originalFetch.apply(window, args);
    } catch (error: any) {
      // Transform all fetch errors to a clean error type
      if (error.message?.includes('Failed to fetch') || 
          error.name === 'TypeError' ||
          error.name === 'NetworkError') {
        const cleanError = new Error('OFFLINE');
        cleanError.name = 'OfflineError';
        throw cleanError;
      }
      throw error;
    }
  };
}

// Export a noop for import purposes
export const errorSuppressionInitialized = true;
