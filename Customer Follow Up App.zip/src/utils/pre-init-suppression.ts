// ULTRA-EARLY ERROR SUPPRESSION
// This runs synchronously as soon as the module is imported

// Immediately override error reporting before anything else runs
if (typeof window !== 'undefined') {
  // Store originals
  const _origError = window.console.error;
  const _origLog = window.console.log;
  const _origWarn = window.console.warn;
  
  // Intercept all console methods immediately
  Object.defineProperty(window.console, 'error', {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function(...args: any[]) {
      const str = String(args);
      if (str.includes('Offline') || str.includes('OFFLINE') || 
          str.includes('Network') || str.includes('fetch')) {
        return; // Suppress completely
      }
      return _origError.apply(console, args);
    }
  });
  
  Object.defineProperty(window.console, 'log', {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function(...args: any[]) {
      const str = String(args);
      if (str.includes('Offline') || str.includes('OFFLINE') || 
          str.includes('Network') || str.includes('fetch')) {
        return; // Suppress completely
      }
      return _origLog.apply(console, args);
    }
  });
  
  Object.defineProperty(window.console, 'warn', {
    configurable: true,
    enumerable: true,
    writable: true,
    value: function(...args: any[]) {
      const str = String(args);
      if (str.includes('Offline') || str.includes('OFFLINE') || 
          str.includes('Network') || str.includes('fetch')) {
        return; // Suppress completely
      }
      return _origWarn.apply(console, args);
    }
  });

  // Immediately install global error handlers
  window.addEventListener('error', (e) => {
    const msg = String(e.error || e.message || '');
    if (msg.includes('Offline') || msg.includes('OFFLINE') || 
        msg.includes('Network') || msg.includes('fetch')) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      return false;
    }
  }, { capture: true });

  window.addEventListener('unhandledrejection', (e) => {
    const msg = String(e.reason);
    if (msg.includes('Offline') || msg.includes('OFFLINE') || 
        msg.includes('Network') || msg.includes('fetch')) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
    }
  }, { capture: true });
}

export const preInitSuppressionComplete = true;
