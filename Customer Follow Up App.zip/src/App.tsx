// Initialize error suppression FIRST before any other imports
import './utils/pre-init-suppression';

import { useState, useEffect } from 'react';
import { LoginForm } from './components/LoginForm';
import { Dashboard } from './components/Dashboard';
import { supabase } from './utils/supabase';
import { apiClient } from './utils/api';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(true);

  // Global error handler to suppress network errors
  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      if (event.error?.name === 'OfflineError' ||
          event.error?.name === 'NetworkError' || 
          event.error?.message === 'OFFLINE' ||
          event.error?.message?.includes('Network unavailable') ||
          event.message === 'OFFLINE' ||
          event.message?.includes('OfflineError') ||
          event.message?.includes('Network unavailable')) {
        event.preventDefault();
        // Don't log anything
      }
    };

    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);

  useEffect(() => {
    // Quick connectivity check
    const checkConnectivity = async () => {
      try {
        // Fast connectivity test - just check if we're online
        const online = navigator.onLine;
        setIsOnline(online);
        
        if (!online) {
          console.log('ℹ️ Device is offline - skipping session check');
          setLoading(false);
          return;
        }
      } catch (error) {
        console.log('ℹ️ Connectivity check failed - proceeding offline');
        setIsOnline(false);
        setLoading(false);
        return;
      }
    };

    // Monitor online/offline status
    const handleOnline = () => {
      console.log('ℹ️ Device came online');
      setIsOnline(true);
    };
    
    const handleOffline = () => {
      console.log('ℹ️ Device went offline');
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Check connectivity and session
    checkConnectivity().then(() => {
      if (navigator.onLine) {
        checkSession();
      }
    });

    // Listen for auth state changes only if online
    let subscription: any;
    if (navigator.onLine) {
      try {
        const { data } = supabase.auth.onAuthStateChange(
          async (event, session) => {
            console.log('Auth state change:', event, session?.user?.id);
            
            if (session?.access_token && session?.user) {
              setAccessToken(session.access_token);
              setCurrentUser(session.user.user_metadata?.name || session.user.email || 'User');
              apiClient.setAccessToken(session.access_token);
            } else {
              setCurrentUser(null);
              setAccessToken(null);
              apiClient.setAccessToken(null);
            }
            
            setLoading(false);
          }
        );
        subscription = data.subscription;
      } catch (error: any) {
        // Handle auth listener setup errors silently
        console.log('ℹ️ Auth listener setup skipped');
        setLoading(false);
      }
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if (subscription) {
        subscription.unsubscribe();
      }
    };
  }, []);

  const checkSession = async () => {
    // Skip if offline
    if (!navigator.onLine) {
      console.log('ℹ️ Offline - skipping session check');
      setLoading(false);
      return;
    }

    try {
      console.log('Checking existing session...');
      
      // Add timeout to prevent hanging on network issues
      const sessionPromise = supabase.auth.getSession();
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Session check timeout')), 2000)
      );
      
      const { data: { session }, error } = await Promise.race([sessionPromise, timeoutPromise]) as any;
      
      if (error) {
        // Check if it's a network error - handle silently
        const isNetworkError = error.name === 'OfflineError' ||
                              error.message === 'OFFLINE' ||
                              error.message?.includes('Network unavailable') || 
                              error.message?.includes('Failed to fetch') ||
                              error.name === 'NetworkError' ||
                              error.name === 'TypeError';
        
        if (isNetworkError) {
          setIsOnline(false);
          setLoading(false);
          return;
        }
        
        console.log('Session check complete - no active session');
        setLoading(false);
        return;
      }
      
      if (session?.access_token && session?.user) {
        console.log('✅ Valid session found');
        setAccessToken(session.access_token);
        setCurrentUser(session.user.user_metadata?.name || session.user.email || 'User');
        apiClient.setAccessToken(session.access_token);
      } else {
        console.log('No active session');
      }
    } catch (error: any) {
      // Check if it's a network/timeout error - handle silently
      const isNetworkError = error.name === 'OfflineError' ||
                            error.message === 'OFFLINE' ||
                            error.message?.includes('timeout') ||
                            error.message?.includes('Network unavailable') || 
                            error.message?.includes('Failed to fetch') ||
                            error.name === 'NetworkError' ||
                            error.name === 'TypeError';
      
      if (isNetworkError) {
        setIsOnline(false);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = (userId: string, token: string) => {
    setCurrentUser(userId);
    setAccessToken(token);
    apiClient.setAccessToken(token);
  };

  const handleLogout = async () => {
    try {
      console.log('Logging out user...');
      await supabase.auth.signOut().catch(() => {
        // Silently ignore network errors during logout
        console.log('ℹ️ Logout - clearing local session only');
      });
      setCurrentUser(null);
      setAccessToken(null);
      apiClient.setAccessToken(null);
    } catch (error: any) {
      // Check if it's a network error - handle silently
      const isNetworkError = error.name === 'OfflineError' ||
                            error.name === 'NetworkError' || 
                            error.message === 'OFFLINE' ||
                            error.message?.includes('Network unavailable');
      
      if (!isNetworkError) {
        console.log('Logout error (non-network):', error);
      }
      
      // Always clear local state
      setCurrentUser(null);
      setAccessToken(null);
      apiClient.setAccessToken(null);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center wellness-gradient">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 mx-auto">
            <div className="w-16 h-16 border-4 border-[var(--wellness-primary)] border-t-transparent rounded-full animate-spin"></div>
          </div>
          <div className="space-y-2">
            <h2 className="text-xl wellness-text-primary">📋 BizFollow</h2>
            <p className="text-[var(--wellness-text-muted)]">Loading your lead tracking dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!currentUser || !accessToken) {
    return (
      <>
        <LoginForm onLogin={handleLogin} />
        <Toaster />
      </>
    );
  }

  return (
    <>
      <Dashboard currentUserId={currentUser} accessToken={accessToken} onLogout={handleLogout} />
      <Toaster />
    </>
  );
}