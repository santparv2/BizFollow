# BizFollow Login Credentials

## 🚀 Quick Access

You can access BizFollow in three ways:

---

## 1️⃣ Quick Login (Recommended)

**Click the "⚡ Quick Login (Test Account)" button** on the login page.

This will automatically:
- Log you in with the test account
- Create the test account if it doesn't exist yet
- Take you straight to the dashboard

---

## 2️⃣ Manual Login

Use these credentials to login manually:

```
Email:    test@bizfollow.com
Password: test123456
```

### How to use:
1. Go to the login page
2. Click the "🔑 Login" tab
3. Enter the email and password above
4. Click "Sign In"

---

## 3️⃣ Demo Mode

**Best for exploring without authentication**

Click the "🚀 Try Demo Mode" button to:
- Access the app instantly without login
- Explore all features
- Use temporary data (not saved to backend)

⚠️ **Note:** Demo mode data is not persistent and will be lost on refresh.

---

## 🆕 Create Your Own Account

Want your own account with persistent data?

1. Click the "📊 Sign Up" tab
2. Enter your details:
   - Full Name
   - Email
   - Password (min 6 characters)
3. Click "Create Account"
4. You'll be automatically logged in

---

## 🔒 Backend Integration

All accounts and data are stored securely in:
- **Supabase Auth** - User authentication
- **Supabase KV Store** - Customer and follow-up data

✅ **Your data persists** across sessions when using real login (not demo mode)

---

## 🎯 Quick Start Guide

### For Testing:
1. Click "⚡ Quick Login (Test Account)"
2. Start adding customers and follow-ups
3. All data saved to backend

### For Production Use:
1. Create your own account via "Sign Up"
2. Login with your credentials
3. Your data is isolated and secure

### For Demo/Exploration:
1. Click "🚀 Try Demo Mode"
2. Explore all features
3. No account needed

---

## 📱 Features Available After Login

Once logged in (with test account or your own), you can:

- ✅ Add new leads with comprehensive intake form
- ✅ Track follow-ups (calls, meetings, tasks)
- ✅ View business analytics with interactive charts
- ✅ Generate PDF client reports
- ✅ Manage customer details and status
- ✅ Search and filter leads by category
- ✅ View dashboard statistics
- ✅ All data persisted to Supabase backend

---

## 🛠️ Troubleshooting

### Login not working?

1. **Check the credentials** are exactly:
   - Email: `test@bizfollow.com`
   - Password: `test123456`

2. **Use Quick Login** instead - it handles everything automatically

3. **Try Demo Mode** if you just want to explore

4. **Run Diagnostics** - Use the "🔧 Login Diagnostics" tool on the login page

5. **Check Console** - Press F12 and look for detailed error logs

### First time login fails?

- The test account might not exist yet
- Use "Quick Login" - it will create the account automatically
- Or create your own account via "Sign Up"

---

## 📊 Backend Status

Look for the **Backend Status Indicator** on the Dashboard:

- 🟢 **Backend Connected** - All data is being saved
- 🟡 **Checking...** - Verifying connection
- 🔴 **Offline** - No backend connection

---

## 🔐 Security Notes

- Test account is shared (for demonstration purposes)
- Create your own account for private data
- All passwords are encrypted
- Data is isolated per user account
- No PII should be stored in this demo environment

---

## 📖 Additional Resources

- See `/BACKEND_DATA_FLOW.md` for technical details on data storage
- See `/ERROR_HANDLING_SUMMARY.md` for error handling information
- See `/DEPLOYMENT_NOTES.md` for deployment instructions

---

**Happy tracking with BizFollow! 📋💼**
